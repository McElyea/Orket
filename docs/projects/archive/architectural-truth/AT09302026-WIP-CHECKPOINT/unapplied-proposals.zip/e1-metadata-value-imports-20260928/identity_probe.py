"""Root-owned cold-child metadata controls; no provider request or process launch."""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
SOURCE = "orket.runtime.config.provider_truth_table"
LEGACY_SOURCE = "orket.runtime.provider_truth_table"
CONSUMERS = {"capability_fallback_hierarchy": "orket.runtime.policy.capability_fallback_hierarchy",
             "model_profile_bios": "orket.runtime.config.model_profile_bios"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def value_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def origin(module, expected):
    path = Path(module.__file__).resolve()
    assert path == (ROOT / (expected.replace(".", "/") + ".py")).resolve() and path.is_relative_to(ROOT)
    return {"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path)}


def input_hashes(receipt, phase):
    expected = dict(receipt["source_hashes"])
    if phase == "candidate":
        for relative in receipt["parity"]:
            expected[relative] = sha(HERE / "candidate" / relative)
    actual = {path: sha(ROOT / path) for path in expected}
    assert actual == expected, [p for p in actual if actual[p] != expected[p]]
    return actual


def refusal(name, validator, payload):
    damaged = deepcopy(payload)
    if name == "capability_fallback_hierarchy":
        assert damaged["fallback_hierarchy"]["streaming"][0]["provider"] == "ollama"
        damaged["fallback_hierarchy"]["streaming"][0]["state"] = "unsupported"
        error = "E_CAPABILITY_FALLBACK_STATE_DRIFT:streaming:ollama"
    else:
        assert any(row["provider"] == "lmstudio" for row in damaged["profiles"])
        damaged["profiles"] = [row for row in damaged["profiles"] if row["provider"] != "lmstudio"]
        error = "E_MODEL_PROFILE_BIOS_PROVIDER_SET_MISMATCH"
    before = deepcopy(damaged)
    try:
        validator(damaged)
    except ValueError as exc:
        assert exc.args == (error,), exc.args
    else:
        raise AssertionError("existing metadata refusal was lost")
    assert damaged == before
    return error


def local_value_control(name, consumer, source, truth):
    original = source.provider_truth_table_snapshot
    replacement = deepcopy(truth)
    row = next(row for row in replacement["providers"] if row["provider"] == "ollama")
    if name == "capability_fallback_hierarchy":
        row["capabilities"]["metadata_probe_capability"] = "supported"
    else:
        row["capabilities"]["repair_tolerance"] = "conditional"
    calls = []

    def local_snapshot():
        calls.append("consumer-snapshot")
        return deepcopy(replacement)

    try:
        consumer.provider_truth_table_snapshot = local_snapshot
        assert source.provider_truth_table_snapshot is original
        snapshot = getattr(consumer, name + "_snapshot")()
        if name == "capability_fallback_hierarchy":
            assert snapshot["fallback_hierarchy"]["metadata_probe_capability"] == [{"provider": "ollama", "state": "supported"}]
        else:
            assert next(row for row in snapshot["profiles"] if row["provider"] == "ollama")["repair_tolerance"] == "conditional"
        snapshot_calls = len(calls)
        assert snapshot_calls > 0
        result = getattr(consumer, "validate_" + name)(snapshot)
        assert len(calls) > snapshot_calls
    finally:
        consumer.provider_truth_table_snapshot = original
    assert original() == truth
    return {"snapshot_calls": snapshot_calls, "validator_calls": len(calls) - snapshot_calls,
            "changed_local_declaration_observed": True, "canonical_declaration_unchanged": True,
            "payload_sha256": value_sha(snapshot), "validation_sha256": value_sha(result)}


def probe(name, source):
    canonical = CONSUMERS[name]
    consumer = importlib.import_module(canonical)
    assert importlib.import_module("orket.runtime." + name) is consumer
    original = source.provider_truth_table_snapshot
    assert consumer.provider_truth_table_snapshot is original
    truth = deepcopy(original())
    snapshot = getattr(consumer, name + "_snapshot")
    validator = getattr(consumer, "validate_" + name)
    payload = snapshot()
    before = deepcopy(payload)
    result = validator(payload)
    assert payload == before
    rejected = refusal(name, validator, payload)

    def source_patch():
        raise AssertionError("post-import source patch retargeted consumer-local snapshot")

    try:
        source.provider_truth_table_snapshot = source_patch
        assert consumer.provider_truth_table_snapshot is original
        assert snapshot() == payload and validator(payload) == result
        assert refusal(name, validator, payload) == rejected
    finally:
        source.provider_truth_table_snapshot = original
    local = local_value_control(name, consumer, source, truth)
    assert original() == truth and payload == before
    return {"consumer": canonical, "origin": origin(consumer, canonical), "legacy_module_identity": True,
            "captured_function_identity": True, "source_patch_does_not_retarget_capture": True,
            "original_payload_sha256": value_sha(payload), "validation_sha256": value_sha(result),
            "exact_refusal": rejected, "supplied_payload_not_mutated": True, "local_value_control": local}


def main():
    from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

    receipt = json.loads((HERE / "receipt.json").read_text(encoding="utf-8"))
    choices = [SOURCE, LEGACY_SOURCE, *CONSUMERS.values(), *("orket.runtime." + n for n in CONSUMERS)]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("baseline", "candidate"), required=True)
    parser.add_argument("--first", choices=choices, required=True)
    parser.add_argument("--out", type=Path, default=HERE / "identity-observation.json")
    args = parser.parse_args()
    output = args.out.resolve()
    assert output.is_relative_to(ROOT)
    bound = input_hashes(receipt, args.phase)
    assert not any(n == "orket" or n.startswith("orket.") for n in sys.modules)
    importlib.import_module(args.first)
    present = [name for name in choices if name in sys.modules]
    source = importlib.import_module(SOURCE)
    assert importlib.import_module(LEGACY_SOURCE) is source
    rows = [probe(name, source) for name in CONSUMERS]
    assert input_hashes(receipt, args.phase) == bound
    payload = {"proof_kind": "executed_import_binding_and_static_metadata_value_controls", "phase": args.phase,
               "first_requested_import": args.first, "selected_modules_present_after_first_import": present,
               "root_initialization_may_preload_consumers": True, "canonical_source": origin(source, SOURCE),
               "source_hashes": bound, "source_inputs_unchanged": True, "rows": rows,
               "native_process_owner": "required from parent campaign", "provider_runtime_proof": False,
               "capability_truth_verified_against_live_provider": False, "artifact_publication_proof": False}
    write_payload_with_diff_ledger(output, payload)
    print(json.dumps({"phase": args.phase, "first": args.first, "consumer_controls": len(rows)}, sort_keys=True))


if __name__ == "__main__":
    main()
