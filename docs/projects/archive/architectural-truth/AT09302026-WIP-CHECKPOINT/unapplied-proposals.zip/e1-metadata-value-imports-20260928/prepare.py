"""Prepare two static declaration consumers without executing or importing product code."""
from __future__ import annotations

import ast
import difflib
import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
PRODUCTS = ("orket/runtime/policy/capability_fallback_hierarchy.py", "orket/runtime/config/model_profile_bios.py")
SOURCE = "orket/runtime/config/provider_truth_table.py"
LEGACY = "orket/runtime/provider_truth_table.py"
LOG = ".tmp/goal-20260928-tool-roots-epic-native-mypy.log"
DEPENDENCY = "model/core/contracts/dependency_direction_policy.json"
SELECTORS = [
    "tests/runtime/test_runtime_subpackage_boundaries.py",
    "tests/runtime/test_capability_fallback_hierarchy.py",
    "tests/runtime/test_model_profile_bios.py",
    "tests/runtime/test_runtime_truth_drift_checker.py",
    "tests/scripts/test_check_capability_fallback_hierarchy.py",
    "tests/scripts/test_check_model_profile_bios.py",
    "tests/runtime/test_run_start_artifacts.py",
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, source):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(source, encoding="utf-8", newline="\n")


def dump(node):
    return ast.dump(node, include_attributes=False)


def candidate(relative, before):
    old = "from orket.runtime.provider_truth_table import provider_truth_table_snapshot\n"
    assert before.count(old) == 1
    if "/policy/" in relative:
        new = "from orket.runtime.config import provider_truth_table as _provider_truth_table\n"
        after = before.replace(old, new, 1)
        anchor = "_FALLBACK_ELIGIBLE_STATES ="
        added = "# Preserve the existing consumer-local snapshot binding.\n"
        added += "provider_truth_table_snapshot = _provider_truth_table.provider_truth_table_snapshot\n\n"
        assert after.count(anchor) == 1
        return after.replace(anchor, added + anchor, 1)
    return before.replace(old, "from orket.runtime.config.provider_truth_table import provider_truth_table_snapshot\n", 1)


def verify(relative, before, after):
    old, new = ast.parse(before), ast.parse(after)
    old_nodes = [n for n in old.body if not isinstance(n, ast.ImportFrom) or n.module != "orket.runtime.provider_truth_table"]
    remaining, captures, imports = [], [], []
    for node in new.body:
        if isinstance(node, ast.ImportFrom) and node.module in {"orket.runtime.config", "orket.runtime.config.provider_truth_table"}:
            imports.append(node)
            continue
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "provider_truth_table_snapshot" for t in node.targets):
            captures.append(node)
            continue
        remaining.append(node)
    assert list(map(dump, old_nodes)) == list(map(dump, remaining))
    assert [ast.get_source_segment(before, n) for n in old_nodes] == [ast.get_source_segment(after, n) for n in remaining]
    assert len(imports) == 1
    if "/policy/" in relative:
        assert ast.unparse(imports[0]) == "from orket.runtime.config import provider_truth_table as _provider_truth_table"
        assert len(captures) == 1 and ast.unparse(captures[0]) == "provider_truth_table_snapshot = _provider_truth_table.provider_truth_table_snapshot"
    else:
        assert ast.unparse(imports[0]) == "from orket.runtime.config.provider_truth_table import provider_truth_table_snapshot"
        assert captures == []
    assert not any(isinstance(n, ast.Name) and n.id == "_provider_truth_table" for n in ast.walk(old))
    assert len(after.splitlines()) < 400
    return {"before_lines": len(before.splitlines()), "after_lines": len(after.splitlines()),
            "original_ast_exact_under_import_capture_substitution": True, "original_source_segments_exact": True,
            "capture_method": "public-module-and-assignment" if captures else "direct-same-domain-import"}


def ruff(relative, source):
    argv = [sys.executable, "-m", "ruff", "check", "--no-cache", "--stdin-filename", str(ROOT / relative), "-"]
    result = subprocess.run(argv, cwd=ROOT, input=source, text=True, capture_output=True, check=False)
    log = HERE / (Path(relative).stem + "-ruff.log")
    write(log, result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
    return {"argv": argv, "exit_code": result.returncode, "log_sha256": sha(log)}


def source_binding():
    paths = {*PRODUCTS, SOURCE, LEGACY, LOG, DEPENDENCY, "pyproject.toml", "orket/runtime/__init__.py",
             "orket/runtime/policy/__init__.py", "orket/runtime/config/__init__.py", *SELECTORS,
             "orket/runtime/capability_fallback_hierarchy.py", "orket/runtime/model_profile_bios.py",
             "scripts/governance/check_capability_fallback_hierarchy.py", "scripts/governance/check_model_profile_bios.py"}
    return {p: sha(ROOT / p) for p in sorted(paths)}


def main():
    from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

    parity, checks, chunks = {}, {}, []
    for relative in PRODUCTS:
        path, baseline = ROOT / relative, HERE / "baseline" / relative
        if baseline.exists():
            assert baseline.read_bytes() == path.read_bytes(), relative
        else:
            baseline.parent.mkdir(parents=True, exist_ok=True)
            baseline.write_bytes(path.read_bytes())
        before = path.read_text(encoding="utf-8")
        after = candidate(relative, before)
        write(HERE / "candidate" / relative, after)
        parity[relative], checks[relative] = verify(relative, before, after), ruff(relative, after)
        chunks.append(f"diff --git a/{relative} b/{relative}\n")
        chunks.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="a/" + relative, tofile="b/" + relative))
    write(HERE / "candidate.patch", "".join(chunks))
    result = subprocess.run(["git", "apply", "--check", "--whitespace=error", str(HERE / "candidate.patch")], cwd=ROOT, text=True, capture_output=True, check=False)
    write(HERE / "apply-check.log", result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    package = ast.parse((ROOT / "orket/runtime/config/__init__.py").read_text(encoding="utf-8"))
    exports = next(ast.literal_eval(n.value) for n in package.body if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == "__all__" for t in n.targets))
    assert "provider_truth_table" in exports
    policy = json.loads((ROOT / DEPENDENCY).read_text(encoding="utf-8"))
    assert policy["classifications"]["orket.runtime"] == "application"
    assert ["application", "application"] in policy["allowed_edges"]
    diagnostics = [line for line in (ROOT / LOG).read_text(encoding="utf-8-sig").splitlines()
                   if any(line.startswith(p.replace("/", "\\") + ":") for p in PRODUCTS) and ": error:" in line]
    assert len(diagnostics) == 2
    write(HERE / "SELECTORS.txt", "\n".join(SELECTORS) + "\n")
    first = ["orket.runtime.config.provider_truth_table", "orket.runtime.provider_truth_table"]
    first.extend(p.removesuffix(".py").replace("/", ".") for p in PRODUCTS)
    first.extend("orket.runtime." + Path(p).stem for p in PRODUCTS)
    write(HERE / "FIRST_IMPORTS.txt", "\n".join(first) + "\n")
    receipt = {"proof_kind": "structural_only", "tracked_writes": False, "runtime_executed": False,
               "product_imports": False, "collection_executed": False, "mypy_executed": False,
               "parity": parity, "checks": checks, "source_hashes": source_binding(),
               "retained_diagnostics": diagnostics, "target_diagnostics": 2, "observed_removed_diagnostics": None,
               "git_apply_check_exit": result.returncode, "existing_public_module_declared": True,
               "dependency_exception_added": False, "selectors": SELECTORS,
               "artifacts": {p.relative_to(HERE).as_posix(): sha(p) for p in HERE.rglob("*")
                             if p.is_file() and p.name != "receipt.json"}}
    write_payload_with_diff_ledger(HERE / "receipt.json", receipt)
    print(json.dumps({"parity": parity, "bindings": len(receipt["source_hashes"]), "receipt_sha256": sha(HERE / "receipt.json")}, sort_keys=True))


if __name__ == "__main__":
    main()
