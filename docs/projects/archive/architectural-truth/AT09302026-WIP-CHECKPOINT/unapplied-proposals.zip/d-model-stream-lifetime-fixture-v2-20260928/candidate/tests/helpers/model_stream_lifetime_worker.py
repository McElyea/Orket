"""Isolated public turns with physical HTTP/native effects and pre-teardown ownership observations."""
from __future__ import annotations

import asyncio
import hashlib
import sys
import threading
from pathlib import Path

import psutil
import pytest

import orket
from orket.adapters.execution import owned_io
from orket.application.interactions.commit import CommitOrchestrator
from orket.application.interactions.manager import InteractionManager
from orket.core.contracts.logging_inputs import LoggingInputs
from orket.logging import bind_logging, prepare_logging
from orket.streaming import StreamBus, model_provider
from orket.workloads import model_stream_v1 as workload
from orket.workloads import run_builtin_workload
from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger
from tests.helpers.model_stream_input_controls import input_values
from tests.helpers.model_stream_input_worker import complete_interaction
from tests.helpers.model_stream_lifetime_controls import (
    configured_server,
    install_async_exit,
    install_native_exit,
    install_provider_observer,
    readback,
    state_for,
    wait_observed,
)
from tests.helpers.model_stream_protocol_controls import install_context_observer, install_supplied_provider
from tests.helpers.sdk_observation_controls import public_caller


def release(state):
    state["native_release"].set()
    state["close_release"].set()
    state["watch_release"].set()
    state["next_chunk"].set()


async def interrupt_external_waiter(state, active):
    waiter = state["waiter"] = asyncio.create_task(asyncio.wait_for(active, .02))
    loop = asyncio.get_running_loop()
    started = loop.time()
    while active.cancelling() == 0 and not active.done() and loop.time() - started < 2:
        await asyncio.wait({waiter}, timeout=.005)
    assert active.cancelling() == 1, "external deadline did not interrupt the held stream turn"
    waiter.cancel("external stream waiter abandoned")
    started = loop.time()
    while not waiter.done() and active.cancelling() < 2 and loop.time() - started < 2:
        await asyncio.wait({waiter}, timeout=.005)
    assert waiter.done() or active.cancelling() >= 2, "external waiter cancellation was not observed"


async def settle_external_waiter(state, result, before):
    if "waiter" not in state:
        return None
    waiter = state["waiter"]
    await asyncio.wait_for(asyncio.gather(waiter, return_exceptions=True), 5)
    if before["external_waiter_done"]:
        assert waiter.cancelled(), "an abandoned external waiter must retain its cancellation"
        return "cancelled"
    assert not waiter.cancelled(), "a retained wrapper should observe the captured stream outcome"
    assert waiter.result() is result, "retained wrapper lost the exact public turn outcome"
    return "same_outcome"


async def before_release(state, active):
    case = state["case"]
    if case == "borrowed":
        return await readback(state, active, name="before-release")
    if ":context:" in case:
        await wait_observed(state["first_token"])
        await state["cancel_turn"]()
        state["next_chunk"].set()
    gate = state["native_entered"] if case.startswith(("native", "fallback")) else (
        state["watch_entered"] if case.startswith("watch") else state["close_entered"])
    await wait_observed(gate, active)
    if ":deadline:" in case:
        await asyncio.sleep(1.15)
    elif ":abandoned:" in case:
        await interrupt_external_waiter(state, active)
    elif ":repeat:" in case:
        active.cancel("first stream caller interruption")
        await asyncio.sleep(.03)
        active.cancel("second stream caller interruption")
        await asyncio.sleep(.03)
    if case.startswith("stream") and gate.is_set():
        await wait_observed(state["peer_eof"])
    data = await readback(state, active, name="before-release")
    assert gate.is_set(), "public turn returned without entering its retained cleanup"
    assert not data["parent_done"] and not data["consumer_done"], data
    if ":context:" not in case:
        assert not data["watcher_done"], "watcher was released before the actual turn cleanup settled"
    if case.startswith(("native", "fallback")):
        assert data["native_effect"] and not data["native_finished"]
        assert state["native_thread"] != threading.get_ident()
        posts = [body for first, body in data["requests"] if first.startswith("POST ")]
        assert len(posts) == (2 if case.startswith("fallback") else 1)
    if case.startswith("stream"):
        assert data["peer_eof"] and not data["close_finished"]
        if ":context:" in case:
            assert data["cancel_calls"], "real interaction cancellation did not signal the provider"
    if case.startswith(("generator", "watch")):
        assert not data["cleanup_effect"], "fixture finalizer completed before its explicit release"
    return data


def assert_result(state, result, events, artifact):
    case, failure = state["case"], state["failure"]
    if case.startswith(("generator", "watch")) and failure is not None:
        assert result is failure and result.__cause__.args == ("original stream failure cause",)
    elif ":context:" in case:
        assert result == {"post_finalize_wait_ms": 0, "request_cancel_turn": 1}
        assert not any(intent["ref"] == "model_stream_v1" for intent in artifact["intents"])
    elif ":repeat:" in case:
        # At the arbitrary provider boundary, the shared owner's first caller
        # interruption outranks a provider CancelledError, including a native one.
        assert type(result) is asyncio.CancelledError and result.args == ("first stream caller interruption",)
    elif ":abandoned:" in case:
        assert type(result) is asyncio.CancelledError and result.args == ()
    elif ":deadline:" in case or failure is not None:
        assert result == {"post_finalize_wait_ms": 0, "request_cancel_turn": 1}
        refs = [intent["ref"] for intent in artifact["intents"]]
        expected = "provider_turn_timeout:1.0s" if ":deadline:" in case else str(failure)
        assert any(ref == "fail_closed:provider_error:" + expected for ref in refs)
    else:
        assert result == {"post_finalize_wait_ms": 0}
        assert any(intent["ref"] == "model_stream_v1" for intent in artifact["intents"])
    if isinstance(result, BaseException):
        assert not any(intent["ref"] == "model_stream_v1" for intent in artifact["intents"])
    fail_closed = any(intent["ref"].startswith("fail_closed:") for intent in artifact["intents"])
    assert events[-1]["payload"]["commit_outcome"] == ("fail_closed" if fail_closed else "ok")
    if case.startswith(("native", "fallback")):
        assert state["native_finished"].is_set() and state["native_client"].is_closed and state["close_calls"] == 1
    if case.startswith("stream"):
        assert state["close_finished"].is_set() and state["async_client"].is_closed and state["peer_eof"].is_set()
    if case.startswith("generator"):
        assert state["close_finished"].is_set() and state["iterator"].ag_frame is None
    if case.startswith("watch"):
        assert state["watch_finished"].is_set() and state["watch_calls"] == 1
    if case == "borrowed":
        assert not state.get("borrowed_close_called", False)
    assert not state["expired"]


async def fixture_cleanup(state, active, manager):
    release(state)
    await asyncio.wait_for(asyncio.gather(active, return_exceptions=True), 10)
    if state["native_entered"].is_set():
        assert await asyncio.to_thread(state["native_finished"].wait, 5)
    iterator = state.get("iterator")
    if getattr(iterator, "ag_frame", None) is not None:
        # Emergency unchanged-source fixture cleanup is deliberately after the
        # independent before/after observations and never counted as product work.
        await public_caller(iterator.aclose())
    watcher = state.get("watcher")
    if watcher is not None:
        await asyncio.wait_for(asyncio.gather(watcher, return_exceptions=True), 5)
    if "waiter" in state:
        await asyncio.gather(state["waiter"], return_exceptions=True)
    await manager.aclose()


async def observe(state, monkeypatch):
    root, case = state["root"], state["case"]
    install_provider_observer(monkeypatch, state)
    if case.startswith(("native", "fallback")):
        install_native_exit(monkeypatch, state)
    if case.startswith("stream"):
        install_async_exit(monkeypatch, state)
    manager = InteractionManager(stream_enabled=True, bus=StreamBus(), project_root=root,
                                 commit_orchestrator=CommitOrchestrator(project_root=root))
    async with configured_server(monkeypatch, state):
        if case.startswith("generator") or case == "borrowed":
            install_supplied_provider(monkeypatch, state)
        if ":deadline:" in case:
            monkeypatch.setenv("ORKET_MODEL_STREAM_TURN_TIMEOUT_S", "1")
        input_config, turn_params = input_values("control")
        if case.startswith("stream"):
            input_config["max_tokens"] = 2 if ":context:" in case else 1
        session_id = await manager.start({})
        queue = await manager.bus.subscribe(session_id)
        turn_id = await manager.begin_turn(session_id, input_config, turn_params)
        context = await manager.create_context(session_id, turn_id)
        state["cancel_turn"] = lambda: manager.cancel(turn_id)
        install_context_observer(context, state)
        active = asyncio.create_task(public_caller(run_builtin_workload(workload_id="model_stream_v1",
            input_config=input_config, turn_params=turn_params, interaction_context=context)))
        try:
            before = await before_release(state, active)
            release(state)
            result = await asyncio.wait_for(active, 8)
            waiter_terminal = await settle_external_waiter(state, result, before)
            after = await readback(state, active, name="after-operation-before-fixture-teardown")
            assert after["consumer_done"] and after["watcher_done"]
            assert after["provider_cancel_slots"] in {None, 0}
            events, artifact = await complete_interaction(manager, session_id, turn_id, queue, result, root)
            await asyncio.to_thread(write_payload_with_diff_ledger, root / "stream-outcome.json", {
                "case": case, "outcome_type": type(result).__name__, "exact_failure": result is state["failure"],
                "events": events, "commit": artifact, "before": before, "after": after, "external_waiter_terminal": waiter_terminal})
            assert_result(state, result, events, artifact)
            return {"case": case, "ownership_verified": True,
                "external_waiter_disposition": before["external_waiter_disposition"],
                "external_waiter_terminal": waiter_terminal, "observed_path": "fallback" if case.startswith("fallback")
                else "primary", "observed_result": "success" if not isinstance(result, BaseException) and
                not result.get("request_cancel_turn", 0) else "failure", "outcome_type": type(result).__name__,
                "concrete_cleanup_identity": state["failure"] is not None and case.startswith(("generator", "watch")),
                "provider_cancel_policy": "first-caller" if case == "native:repeat:CancelledError" else None}
        finally:
            await fixture_cleanup(state, active, manager)


async def exercise(root, case):
    state = state_for(root, case)
    prepared = await prepare_logging(LoggingInputs(root, timezone_name="MST"))
    with pytest.MonkeyPatch.context() as monkeypatch, bind_logging(prepared):
        return await observe(state, monkeypatch)


def source_identity(module):
    return {"path": str(Path(module.__file__).resolve()),
            "sha256": hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()}


def main():
    root = Path(sys.argv[1]).resolve()
    result = asyncio.run(exercise(root, sys.argv[2]))
    process = psutil.Process()
    result.update(interpreter=sys.executable, prefix=sys.prefix, origin=str(Path(orket.__file__).resolve()),
        owner_origin=str(Path(owned_io.__file__).resolve()), owner_sha256=source_identity(owned_io)["sha256"],
        process_identity={"pid": process.pid, "create_time": process.create_time()},
        workload_source=source_identity(workload), provider_source=source_identity(model_provider))
    write_payload_with_diff_ledger(root / "result.json", result)


if __name__ == "__main__":
    main()
