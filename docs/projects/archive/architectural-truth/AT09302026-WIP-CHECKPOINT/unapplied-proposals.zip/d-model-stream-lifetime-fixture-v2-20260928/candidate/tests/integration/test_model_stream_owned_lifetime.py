"""Integration: actual public turns retain physical HTTP/native and supplied finalizer work."""
from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path

import pytest

from orket.streaming import model_provider
from orket.workloads import model_stream_v1 as workload
from tests.integration.test_logging_preparation_lifetime import run_worker

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]
WORKER = Path(__file__).resolve().parents[1] / "helpers/model_stream_lifetime_worker.py"
CASES = ["native:none:success", "native:repeat:success", "native:deadline:success", "native:abandoned:success",
    "native:repeat:CancelledError", "native:none:OSError", "fallback:repeat:success", "stream:max:success", "stream:context:success",
    "generator:repeat:success", "generator:repeat:OSError", "generator:repeat:CancelledError",
    "generator:none:SystemExit", "watch:repeat:success", "watch:repeat:OSError",
    "watch:repeat:CancelledError", "watch:none:SystemExit", "watch:none:KeyboardInterrupt", "borrowed"]


@pytest.mark.parametrize("case", CASES)
async def test_model_stream_retains_owned_turn_work(tmp_path, case, record_property):
    data = await run_worker(tmp_path, WORKER, [case], record_property)
    assert data["case"] == case and data["ownership_verified"]
    assert data["observed_path"] == ("fallback" if case.startswith("fallback") else "primary")
    for module, key in ((workload, "workload_source"), (model_provider, "provider_source")):
        expected = await asyncio.to_thread(lambda module=module: {"path": str(Path(module.__file__).resolve()),
            "sha256": hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()})
        assert data[key] == expected
    if case == "native:repeat:CancelledError":
        assert data["provider_cancel_policy"] == "first-caller"
    if case == "native:abandoned:success":
        assert data["external_waiter_disposition"] in {"abandoned", "retained"}
        expected_terminal = "cancelled" if data["external_waiter_disposition"] == "abandoned" else "same_outcome"
        assert data["external_waiter_terminal"] == expected_terminal
