"""Static V2 proof: reverse only the waiter correction and preserve frozen V1 bytes."""
from __future__ import annotations

import ast
import copy
import difflib
import hashlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
V1 = ROOT / ".tmp/d-model-stream-lifetime-20260928"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / ".tmp/e2-orchestrator-review-20260928"))
import candidate_tools as c
from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

PATHS = ["tests/helpers/model_stream_lifetime_controls.py", "tests/helpers/model_stream_protocol_controls.py",
         "tests/helpers/model_stream_lifetime_worker.py", "tests/integration/test_model_stream_owned_lifetime.py"]
V1_PROOFS = {"READINESS.md": "9ccd09e4b197cee029aac7b7c8c84e01f8eba1aa20a3ad3854ff655a0689b59a",
    "receipt.json": "a51e3676d7219ef038877fb43eefc23c96454a9e96fffe49e53bb9744369eba5",
    "product.patch": "326f33afae816085f57a775a2426bd1cad6b59016e51fd37696000ee15c8cf91",
    "opening.patch": "91afc469e500c27ca2b3233d7a115233587d79da90ae2dc336faf66d9df36f03",
    "authority.patch": "6fef4eff1f937681390250d0e19bf052386f5ba2ec62e592c0ff75aa64e6fcbf"}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parsed(tree, rel):
    return ast.parse((HERE / tree / rel).read_text())


def dump(node):
    return ast.dump(node, include_attributes=False)


def strip_fields(tree, keys):
    count = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.Dict):
            retained = [(key, value) for key, value in zip(node.keys, node.values, strict=True)
                        if not (isinstance(key, ast.Constant) and key.value in keys)]
            count += len(node.keys) - len(retained)
            node.keys, node.values = [x[0] for x in retained], [x[1] for x in retained]
    return count


def restore(rel):
    old, new = [parsed(tree, rel) for tree in ("baseline", "candidate")]
    if rel == PATHS[0]:
        assert strip_fields(new, {"external_waiter_disposition", "caller_cancel_count"}) == 2
    elif rel == PATHS[2]:
        new.body = [n for n in new.body if getattr(n, "name", None) not in {
            "interrupt_external_waiter", "settle_external_waiter"}]
        branch = lambda tree: next(n for n in ast.walk(tree) if isinstance(n, ast.If) and
                                  dump(n.test) == dump(ast.parse('":abandoned:" in case', mode="eval").body))
        branch(new).body = copy.deepcopy(branch(old).body)
        observe = next(n for n in new.body if getattr(n, "name", None) == "observe")
        removed = 0
        for node in ast.walk(observe):
            if isinstance(node, ast.Try):
                retained = [n for n in node.body if not (isinstance(n, ast.Assign) and
                    isinstance(n.targets[0], ast.Name) and n.targets[0].id == "waiter_terminal")]
                removed += len(node.body) - len(retained)
                node.body = retained
        assert removed == 1
        assert strip_fields(new, {"external_waiter_terminal", "external_waiter_disposition"}) == 3
    elif rel == PATHS[3]:
        test = next(n for n in new.body if getattr(n, "name", None) == "test_model_stream_retains_owned_turn_work")
        final = test.body.pop()
        assert isinstance(final, ast.If) and dump(final.test) == dump(
            ast.parse('case == "native:abandoned:success"', mode="eval").body)
    assert dump(old) == dump(new), "unapproved executable/marker/assertion change: " + rel


def review():
    for name, expected in V1_PROOFS.items():
        assert digest(V1 / name) == expected, "V1 proof mutated: " + name
    for rel in PATHS:
        assert (HERE / "baseline" / rel).read_bytes() == (V1 / "opening" / rel).read_bytes()
        restore(rel)
    assert (HERE / "candidate" / PATHS[1]).read_bytes() == (V1 / "opening" / PATHS[1]).read_bytes()
    measurements = []
    for rel in PATHS:
        path, tree = HERE / "candidate" / rel, parsed("candidate", rel)
        lines = len(path.read_text().splitlines())
        largest = max(n.end_lineno - n.lineno + 1 for n in ast.walk(tree)
                      if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
        assert lines <= 400 and largest <= 70
        measurements.append({"path": rel, "sha256": digest(path), "lines": lines, "largest_function": largest})
    cases = ast.literal_eval(next(n.value for n in parsed("candidate", PATHS[-1]).body
                                 if isinstance(n, ast.Assign) and n.targets[0].id == "CASES"))
    assert len(cases) == len(set(cases)) == 19
    c.STAGE = HERE
    c.emit_patch(PATHS, "amendment.patch")
    parts = []
    for rel in PATHS:
        text = (HERE / "candidate" / rel).read_text()
        parts.append(f"diff --git a/{rel} b/{rel}\nnew file mode 100644\n")
        parts.extend(difflib.unified_diff([], text.splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + rel))
    (HERE / "opening-v2.patch").write_text("".join(parts), encoding="utf-8", newline="\n")
    payload = {"proof_kind": "structural_only", "runtime_executed": False, "collection_executed": False,
        "product_imports_executed": False, "mypy_executed": False, "tracked_writes": False,
        "whole_ast_reversal": True, "original_timeout_002_retained": True,
        "original_native_effect_and_ownership_assertions_retained": True,
        "original_19_case_identities_and_markers_retained": True, "v1_proofs_unchanged": V1_PROOFS,
        "baseline_hashes": {p: digest(HERE / "baseline" / p) for p in PATHS}, "measurements": measurements,
        "support_hashes": {p: digest(ROOT / p) for p in ["tests/helpers/tool_runtime_controls.py",
            "tests/helpers/tool_runtime_worker.py", "pyproject.toml"]},
        "patch_hashes": {p: digest(HERE / p) for p in ["amendment.patch", "opening-v2.patch"]}}
    write_payload_with_diff_ledger(HERE / "receipt.json", payload)
    print(payload)


if __name__ == "__main__":
    review()
