"""Preserve V1, produce a separate version-neutral external-waiter observation fixture."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
V1 = ROOT / ".tmp/d-model-stream-lifetime-20260928"
sys.path.insert(0, str(ROOT / ".tmp/e2-orchestrator-review-20260928"))
import candidate_tools as c

c.STAGE = HERE
paths = ["tests/helpers/model_stream_lifetime_controls.py", "tests/helpers/model_stream_protocol_controls.py",
         "tests/helpers/model_stream_lifetime_worker.py", "tests/integration/test_model_stream_owned_lifetime.py"]
for rel in paths:
    data = (V1 / "opening" / rel).read_bytes()
    baseline = HERE / "baseline" / rel
    baseline.parent.mkdir(parents=True, exist_ok=True)
    if baseline.exists():
        assert baseline.read_bytes() == data
    else:
        baseline.write_bytes(data)
    c.write(rel, data.decode(), tree="candidate")

rel = paths[2]
text = (HERE / "candidate" / rel).read_text()
old = '''        state["waiter"] = asyncio.create_task(asyncio.wait_for(active, .02))
        await asyncio.sleep(.05)
        state["waiter"].cancel("external stream waiter abandoned")
        await asyncio.sleep(.03)
        assert state["waiter"].done(), "external wait_for did not release its own waiter"'''
assert old in text
text = text.replace(old, '''        await interrupt_external_waiter(state, active)''')
marker = "async def before_release(state, active):"
text = text.replace(marker, '''async def interrupt_external_waiter(state, active):
    waiter = state["waiter"] = asyncio.create_task(asyncio.wait_for(active, .02))
    loop = asyncio.get_running_loop()
    started = loop.time()
    while active.cancelling() == 0 and not active.done() and loop.time() - started < 2:
        await asyncio.wait({waiter}, timeout=.005)
    assert active.cancelling() == 1, "external deadline did not interrupt the held stream turn"
    waiter.cancel("external stream waiter abandoned")
    started = loop.time()
    while not waiter.done() and active.cancelling() < 2 and loop.time() - started < 2:
        await asyncio.wait({waiter}, timeout=.005)
    assert waiter.done() or active.cancelling() >= 2, "external waiter cancellation was not observed"


async def settle_external_waiter(state, result, before):
    if "waiter" not in state:
        return None
    waiter = state["waiter"]
    await asyncio.wait_for(asyncio.gather(waiter, return_exceptions=True), 5)
    if before["external_waiter_done"]:
        assert waiter.cancelled(), "an abandoned external waiter must retain its cancellation"
        return "cancelled"
    assert not waiter.cancelled(), "a retained wrapper should observe the captured stream outcome"
    assert waiter.result() is result, "retained wrapper lost the exact public turn outcome"
    return "same_outcome"


''' + marker)
text = text.replace('            result = await asyncio.wait_for(active, 8)\n',
    '            result = await asyncio.wait_for(active, 8)\n            waiter_terminal = await settle_external_waiter(state, result, before)\n')
text = text.replace('"events": events, "commit": artifact, "before": before, "after": after}',
    '"events": events, "commit": artifact, "before": before, "after": after, "external_waiter_terminal": waiter_terminal}')
text = text.replace('return {"case": case, "ownership_verified": True,',
    'return {"case": case, "ownership_verified": True,\n                "external_waiter_disposition": before["external_waiter_disposition"],\n                "external_waiter_terminal": waiter_terminal,')
c.write(rel, text)

rel = paths[0]
text = (HERE / "candidate" / rel).read_text()
text = text.replace('        "external_waiter_done": state["waiter"].done() if "waiter" in state else None,',
    '''        "external_waiter_done": state["waiter"].done() if "waiter" in state else None,
        "external_waiter_disposition": ("abandoned" if state["waiter"].done() else "retained")
            if "waiter" in state else None,
        "caller_cancel_count": active.cancelling(),''')
c.write(rel, text)

rel = paths[3]
text = (HERE / "candidate" / rel).read_text()
text += '''    if case == "native:abandoned:success":
        assert data["external_waiter_disposition"] in {"abandoned", "retained"}
        expected_terminal = "cancelled" if data["external_waiter_disposition"] == "abandoned" else "same_outcome"
        assert data["external_waiter_terminal"] == expected_terminal
'''
c.write(rel, text)
