# Orchestrator direct composition E2 candidate

Prepared under `.tmp/e2-orchestrator-direct-composition-20260928` only. No tracked
files, runtime/product imports, pytest collection, Mypy, commit or push occurred.
This is a bounded proposal and structural proof, not runtime acceptance.

## What changes

Two product files remove seven redundant ops functions by composing their canonical
services in the already-existing Orchestrator methods. The cut includes dependency
reading, guard extraction/validation, executor dispatch, and failure-handler setup
plus its two small governance message policies. No new product module, class,
coordinator, proxy, owner clone or compatibility export is introduced. This is not
moving orchestration into another oversized helper: canonical services still own
all behavior and effects, and the instance facade owns its own selected composition.

Ops: 478 → 396 lines, largest function 67. Facade: 361 → 389, largest *changed*
function 13. Combined product size: 839 → 785, a net reduction of 54 lines.
Function definitions across the two modules: 38 → 31. AST Any-name references:
88 → 60; no Any, cast or ignore broadening occurs. All class method names remain
and no public method is added. The existing facade constructor remains 73 lines,
AST-identical; do not report all E2 function debt closed.

The former catch-all facade shims use the concrete parameter shapes from the old
ops functions. Valid calls, instance monkeypatch seams, ordered field selection,
canonical effect calls, errors and return policy remain. Private inspect.signature
output and an invalid call's TypeError frame/text can change. Public Orchestrator
export/constructor and all other facade methods stay exact.

## Selection timing and imports

- Dependency context selects current instance cards at the same method invocation.
- Guard validation selects current loop policy; extraction uses the same canonical
  guard payload function. No extra validation or copying is introduced.
- Dispatch calls the supplied executor's current execute_turn with exact positional
  order and system_prompt keyword. The existing instance dispatch seam is retained.
- Failure-handler construction still evaluates workspace, report clock, cards,
  evaluator and bound transition method in the same order before its first await.
  Both message-policy lambdas retain late instance lookup when the handler calls
  them after publication/transition. No prebuilt handler is cached on the facade.

Four effect/policy aliases move from the private ops import owner to the facade;
the actual source modules/functions/classes are unchanged. Calls remain captured
imports, so monkeypatching the canonical source after import does not rebind the
consumer. The test helper migrates its dependency alias patch to the facade; its
separate read_card_dispatch_snapshot patch remains in ops. One direct integration
caller now invokes Orchestrator._build_dependency_context unbound with the exact
same minimal repository-bearing fixture and issue. Every assertion and all real
SQLite/evidence setup remain unchanged. No other repository direct callers or
patches of the removed ops functions were found. No active doc exposes them as an
external import contract; no compatibility aliases are retained.

The facade also imports canonical ToolBox/TurnExecutor and schema/domain type
names used by concrete signatures. Source module initialization order is not
asserted identical: some dependencies can initialize earlier in facade import.
Reviewed moved service modules contain definitions/imports and existing constants;
no new top-level native work, registration or back-edge was added. The independent
cold probe remains necessary before/after alongside runtime proof. Never present
cold import success as live orchestration success.

## What was checked

`review.py` proves all seven relocated function bodies/signatures exactly match
former ops definitions after removing only self:Any. Every remaining ops function,
every other facade method, constructor and non-import module statement is exact.
The two consumer ASTs restore exactly after the explicit alias/caller migration;
all existing assertions are identical. Module/function sizes and unchanged 73-line
constructor debt are recorded. Baseline/support/proposed bytes and four patches
are hash-bound in `receipt.json`.

Canonical scoped Ruff passes. Combined git apply --check --whitespace=error-all
passes. All declared existing selector files exist. No runtime, collection or Mypy
was performed; no typing-error reduction or dependency-gate success is claimed.

## Root proof plan

1. Apply opening.patch only and run the one new failure-phase integration control
   against the unchanged 478-line ops base. It delegates actual FailureReportService
   publication before its barrier, then replaces the facade's evaluator, clock,
   transition method and late message methods. Required observations are the real
   closed report, original selected clock/evaluator/bound transition, current late
   message callbacks, real blocked card and one governance transition history row.
   It uses the corrected existing entry/task waiter so a real task error is exposed
   instead of silently becoming a barrier timeout. No model inference is claimed.
2. Run the unchanged existing selection in SELECTORS.txt (37 selectors total).
   This includes real dependency evidence, guard input admission, retry/control
   plane, turn and epic phase controls, context, real tool/provider cleanup and
   the supplied-provider public engine pipeline. Reuse fresh exact baseline proof
   only where root's case/source bindings establish it; do not infer equivalence.
3. Root-schedule cold_import_probe.py twice before product with --phase before,
   once --order facade-first and once --order canonical-first, using the explicit source PYTHONPATH and each with distinct
   --out path. Use the existing owned native supervisor/readback rather than a
   blind shell timeout. The probe checks public export and all four canonical
   alias identities plus independent source/local rebinding; it writes a canonical
   diff-ledger report. It is prepared but was not executed here.
4. Apply product.patch plus consumers.patch and reviewed authority.patch. Repeat
   identical source identities and both cold orders with --phase after. Retain
   failure and before artifacts, freeze/readback exact inputs, run canonical typing
   and dependency gates. Supported installed/Linux/provider cells stay explicit.

Use worktree-local TEMP/TMP and ORKET_DISABLE_SANDBOX=1. Root schedules all runtime
work; no competing native workload or global coverage overwrite is authorized here.

## Files and remaining limits

Proposed product:
- orket/application/workflows/orchestrator_ops.py
- orket/application/workflows/orchestrator.py

Consumer migrations:
- tests/helpers/card_dispatch.py
- tests/integration/test_card_dependency_acceptance.py

Opening and authority:
- tests/integration/test_orchestrator_failure_phase_composition.py
- docs/architecture/CONTRACT_DELTA_ORCHESTRATOR_DIRECT_COMPOSITION_E2_2026-09-28.md

Shared architecture/plan updates remain root-owned. There is no new cancellation,
input capture, acceptance, replay, policy or provider behavior in this cut. Existing
service size, shared lifetime, borrowed inputs, facade constructor size and global
acceptance debt outside this cut remain open. Current version remains 0.6.114.
