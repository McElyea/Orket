
import json
from types import SimpleNamespace

import pytest

from orket.application.services import orchestrator_runtime_policy as orchestrator_policy
from orket.application.services import orchestrator_team_policy
from orket.application.services.dependency_manager import DependencyValidationError
from orket.application.services.deployment_planner import DeploymentValidationError
from orket.application.services.guard_agent import GuardAgent
from orket.application.services.runtime_policy_inputs import ArchitecturePolicySnapshot
from orket.application.services.runtime_verifier import build_runtime_guard_contract
from orket.application.services.scaffolder import ScaffoldValidationError
from orket.application.services.skill_adapter import synthesize_role_tool_profile_bindings
from orket.application.workflows.orchestrator import Orchestrator
from orket.application.workflows.turn_artifact_writer import TurnArtifactWriter
from orket.application.workflows.turn_executor import TurnResult
from orket.core.contracts.logging_inputs import LoggingInputs
from orket.core.domain import ReservationStatus
from orket.core.domain.execution import ExecutionTurn
from orket.exceptions import CatastrophicFailure, ExecutionFailed
from orket.logging import bind_logging, log_event, prepare_logging
from orket.runtime.config.contract_assets import DEFAULT_PROMPT_BUDGET_PATH
from orket.schema import CardStatus, DialectConfig, IssueConfig, SeatConfig, TeamConfig
from tests.helpers.card_dispatch import install_dispatch_snapshot_stub
from tests.helpers.model_selection import prepared_model_selection
from tests.helpers.protocol_ledger_clock import ProtocolLedgerClock
from tests.helpers.turn_artifacts import artifact_destination, artifact_test_utc_now


class AsyncSpy:
    def __init__(self, return_value=None, side_effect=None):
        self.return_value = return_value
        self.side_effect = side_effect
        self.calls = []

    async def __call__(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        if callable(self.side_effect):
            return self.side_effect(*args, **kwargs)
        if isinstance(self.side_effect, list):
            if self.side_effect:
                return self.side_effect.pop(0)
            return self.return_value
        return self.return_value


class FakeCards:
    def __init__(self):
        self.get_by_build = AsyncSpy(return_value=[])
        self.independent_ready = AsyncSpy(return_value=[])
        self.get_by_id = AsyncSpy(return_value=SimpleNamespace(status=CardStatus.CODE_REVIEW))
        self.update_status = AsyncSpy(return_value=None)
        self.save = AsyncSpy(return_value=None)


class FakeSnapshots:
    def __init__(self):
        self.record = AsyncSpy(return_value=None)


class FakeLoader:
    def __init__(self, workspace_root):
        self._assets = []
        self.file_tools = SimpleNamespace(write_file=self._write_file)

        self._workspace_root = workspace_root

    def queue_assets(self, assets):
        self._assets = list(assets)

    def load_asset(self, category, name, model):
        if not self._assets:
            raise RuntimeError(f"No queued asset for {category}:{name}")
        return self._assets.pop(0)

    async def _write_file(self, path, content):
        target = self._workspace_root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return str(target)


class FakeSandbox:
    def __init__(self):
        self.registry = SimpleNamespace(get=lambda _sid: None)


@pytest.fixture
def orchestrator(tmp_path, monkeypatch):
    install_dispatch_snapshot_stub(monkeypatch)
    cards = FakeCards()
    snapshots = FakeSnapshots()
    loader = FakeLoader(tmp_path)
    org = SimpleNamespace(process_rules={}, architecture=SimpleNamespace(idesign_threshold=10))
    orch = Orchestrator(
        workspace=tmp_path,
        async_cards=cards,
        snapshots=snapshots,
        org=org,
        config_root=tmp_path,
        db_path=str(tmp_path / "test.db"),
        loader=loader,
        sandbox_orchestrator=FakeSandbox(),
        control_plane_clock=ProtocolLedgerClock().utc_now_iso,
        architecture_policy=ArchitecturePolicySnapshot(False),
     turn_clock=artifact_test_utc_now)
    return orch, cards, loader


@pytest.mark.unit
@pytest.mark.asyncio
# Layers are declared per test for the exercised boundary.
async def test_execute_epic_completion(orchestrator, tmp_path):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Test Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        # Existing completed backlog means no candidates and immediate completion path.
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        await orch.execute_epic(
            active_build="build-1",
            run_id="run-1",
            epic=epic,
            team=team,
            env=env,
        )
        assert len(cards.independent_ready.calls) == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_raises_when_no_candidates_and_backlog_incomplete(orchestrator, tmp_path):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Stalled Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.IN_PROGRESS)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        with pytest.raises(ExecutionFailed, match="No executable candidates while backlog incomplete"):
            await orch.execute_epic(
                active_build="build-stalled",
                run_id="run-stalled",
                epic=epic,
                team=team,
                env=env,
            )


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_propagates_dependency_block_before_stall(orchestrator, tmp_path):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        parent = SimpleNamespace(id="ARC-1", status=CardStatus.BLOCKED, depends_on=[])
        child = SimpleNamespace(id="COD-1", status=CardStatus.READY, depends_on=["ARC-1"])
        epic = SimpleNamespace(name="Dependency Block Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[parent, child], [parent, child]]
        cards.independent_ready.side_effect = [[], []]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        await orch.execute_epic(
            active_build="build-dependency-block",
            run_id="run-dependency-block",
            epic=epic,
            team=team,
            env=env,
        )
        assert child.status == CardStatus.BLOCKED
        assert cards.update_status.calls[0][0] == ("COD-1", CardStatus.BLOCKED)
        assert cards.update_status.calls[0][1]["reason"] == "dependency_blocked"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_runs_scaffolder_stage(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Scaffold Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        hit = {"count": 0}
        class _FakeScaffolder:
            def __init__(self, workspace_root, file_tools, organization, *, project_surface_profile=None, architecture_pattern=None):
                self.workspace_root = workspace_root
            async def ensure(self):
                hit["count"] += 1
                return {"created_directories": [], "created_files": []}
        monkeypatch.setattr("orket.application.services.orchestrator_support_services.Scaffolder", _FakeScaffolder)
        await orch.execute_epic(
            active_build="build-scaffold",
            run_id="run-scaffold",
            epic=epic,
            team=team,
            env=env,
        )
        assert hit["count"] == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_support_services_can_override_scaffolder(orchestrator, tmp_path, monkeypatch):
    """Layer: unit. Verifies execute_epic uses the explicit orchestrator support-service seam for scaffolder construction."""
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Scoped Support Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        hit = {"count": 0}
        class _FakeScaffolder:
            async def ensure(self):
                hit["count"] += 1
                return {"created_directories": [], "created_files": []}
        monkeypatch.setattr(orch.support_services, "create_scaffolder", lambda **kwargs: _FakeScaffolder())
        await orch.execute_epic(
            active_build="build-support-seam",
            run_id="run-support-seam",
            epic=epic,
            team=team,
            env=env,
        )
        assert hit["count"] == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_passes_microservices_pattern_to_stabilizers(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        orch.architecture_policy = ArchitecturePolicySnapshot(True)
        orch.org = SimpleNamespace(
            process_rules={
                "architecture_mode": "force_microservices",
                "disable_dependency_manager": True,
                "disable_deployment_planner": True,
            }
        )
        epic = SimpleNamespace(name="Microservices Scaffold Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        captured = {}
        class _FakeScaffolder:
            def __init__(self, workspace_root, file_tools, organization, project_surface_profile=None, architecture_pattern=None):
                captured['architecture_pattern'] = architecture_pattern
            async def ensure(self):
                return {"created_directories": [], "created_files": []}
        monkeypatch.setattr("orket.application.services.orchestrator_support_services.Scaffolder", _FakeScaffolder)
        await orch.execute_epic(
            active_build="build-scaffold-ms",
            run_id="run-scaffold-ms",
            epic=epic,
            team=team,
            env=env,
        )
        assert captured["architecture_pattern"] == "microservices"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_preserves_deferred_architecture_mode_for_stabilizers(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        orch.architecture_policy = ArchitecturePolicySnapshot(True)
        orch.org = SimpleNamespace(
            process_rules={
                "architecture_mode": "architect_decides",
                "disable_dependency_manager": True,
                "disable_deployment_planner": True,
            }
        )
        epic = SimpleNamespace(name="Deferred Architecture Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        captured = {}
        class _FakeScaffolder:
            def __init__(self, workspace_root, file_tools, organization, project_surface_profile=None, architecture_pattern=None):
                captured['architecture_pattern'] = architecture_pattern
            async def ensure(self):
                return {"created_directories": [], "created_files": []}
        monkeypatch.setattr("orket.application.services.orchestrator_support_services.Scaffolder", _FakeScaffolder)
        await orch.execute_epic(
            active_build="build-scaffold-deferred",
            run_id="run-scaffold-deferred",
            epic=epic,
            team=team,
            env=env,
        )
        assert captured["architecture_pattern"] is None


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_fails_on_scaffolder_validation_error(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Scaffold Fail Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        class _BadScaffolder:
            def __init__(self, workspace_root, file_tools, organization, *, project_surface_profile=None, architecture_pattern=None):
                self.workspace_root = workspace_root
            async def ensure(self):
                raise ScaffoldValidationError("missing directories: agent_output/src")
        monkeypatch.setattr("orket.application.services.orchestrator_support_services.Scaffolder", _BadScaffolder)
        with pytest.raises(ExecutionFailed, match="Scaffolder validation failed"):
            await orch.execute_epic(
                active_build="build-scaffold-fail",
                run_id="run-scaffold-fail",
                epic=epic,
                team=team,
                env=env,
            )


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_runs_dependency_manager_stage(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Dependency Stage Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")
        hit = {"count": 0}
        class _FakeDependencyManager:
            def __init__(self, workspace_root, file_tools, organization, *, project_surface_profile=None, architecture_pattern=None):
                self.workspace_root = workspace_root
            async def ensure(self):
                hit["count"] += 1
                return {"created_files": []}
        monkeypatch.setattr(
            "orket.application.services.orchestrator_support_services.DependencyManager",
            _FakeDependencyManager,
        )

        await orch.execute_epic(
            active_build="build-deps",
            run_id="run-deps",
            epic=epic,
            team=team,
            env=env,
        )

        assert hit["count"] == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_fails_on_dependency_manager_validation_error(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Dependency Stage Fail Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")

        class _BadDependencyManager:
            def __init__(self, workspace_root, file_tools, organization, *, project_surface_profile=None, architecture_pattern=None):
                self.workspace_root = workspace_root

            async def ensure(self):
                raise DependencyValidationError(
                    "missing dependency files: agent_output/dependencies/pyproject.toml"
                )

        monkeypatch.setattr(
            "orket.application.services.orchestrator_support_services.DependencyManager",
            _BadDependencyManager,
        )

        with pytest.raises(ExecutionFailed, match="Dependency manager validation failed"):
            await orch.execute_epic(
                active_build="build-deps-fail",
                run_id="run-deps-fail",
                epic=epic,
                team=team,
                env=env,
            )


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_runs_deployment_planner_stage(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Deploy Stage Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")

        hit = {"count": 0}

        class _FakeDeploymentPlanner:
            def __init__(self, workspace_root, file_tools, organization, *, project_surface_profile=None, architecture_pattern=None):
                self.workspace_root = workspace_root

            async def ensure(self):
                hit["count"] += 1
                return {"created_files": []}

        monkeypatch.setattr(
            "orket.application.services.orchestrator_support_services.DeploymentPlanner",
            _FakeDeploymentPlanner,
        )

        await orch.execute_epic(
            active_build="build-deploy",
            run_id="run-deploy",
            epic=epic,
            team=team,
            env=env,
        )

        assert hit["count"] == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_fails_on_deployment_planner_validation_error(orchestrator, tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        epic = SimpleNamespace(name="Deploy Stage Fail Epic", issues=[], references=[])
        team = SimpleNamespace(seats={})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[SimpleNamespace(id="I1", status=CardStatus.DONE)]]
        cards.independent_ready.side_effect = [[]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")

        class _BadDeploymentPlanner:
            def __init__(self, workspace_root, file_tools, organization, *, project_surface_profile=None, architecture_pattern=None):
                self.workspace_root = workspace_root

            async def ensure(self):
                raise DeploymentValidationError(
                    "missing deployment files: agent_output/deployment/Dockerfile"
                )

        monkeypatch.setattr(
            "orket.application.services.orchestrator_support_services.DeploymentPlanner",
            _BadDeploymentPlanner,
        )

        with pytest.raises(ExecutionFailed, match="Deployment planner validation failed"):
            await orch.execute_epic(
                active_build="build-deploy-fail",
                run_id="run-deploy-fail",
                epic=epic,
                team=team,
                env=env,
            )


@pytest.mark.unit
@pytest.mark.asyncio
async def test_handle_failure_retry_limit(orchestrator, monkeypatch, fresh_runtime_state):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test", retry_count=3, max_retries=3)
        result = SimpleNamespace(error="Total failure", violations=[])

        class _Task:
            def cancel(self):
                return None

        async def _fake_get_task(_run_id):
            return _Task()

        monkeypatch.setattr("orket.state.runtime_state.get_task", _fake_get_task)

        with pytest.raises(CatastrophicFailure):
            await orch._handle_failure(issue, result, "run-1", ["dev"])

        assert cards.update_status.calls[-1][0] == ("I1", CardStatus.BLOCKED)
        assert cards.save.calls[-1][0][0]["retry_count"] == 4


@pytest.mark.unit
@pytest.mark.asyncio
async def test_handle_failure_retry_increment(orchestrator):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test", retry_count=0, max_retries=3)
        result = SimpleNamespace(error="Fixable error", violations=[])

        with pytest.raises(ExecutionFailed):
            await orch._handle_failure(issue, result, "run-1", ["dev"])

        assert cards.update_status.calls[-1][0] == ("I1", CardStatus.READY)
        assert cards.save.calls[-1][0][0]["retry_count"] == 1
        assert cards.save.calls[-1][0][0]["status"] == CardStatus.READY


@pytest.mark.asyncio
@pytest.mark.unit
async def test_handle_failure_uses_evaluator_exception_policy(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="dev", summary="Test", retry_count=0, max_retries=3)
    result = SimpleNamespace(error="Fixable error", violations=[])
    class CustomEvaluator:
        def evaluate_failure(self, inputs):
            return {"action": "retry", "next_retry_count": inputs.retry_count + 1}

        def failure_exception_class(self, action):
            return RuntimeError

        def status_for_failure_action(self, action):
            return CardStatus.READY

        def failure_event_name(self, action):
            return None

        def retry_failure_message(self, issue_id, retry_count, max_retries, error):
            return f"CUSTOM RETRY {issue_id} {retry_count}/{max_retries}: {error}"

    orch.evaluator_node = CustomEvaluator()

    with pytest.raises(RuntimeError, match="CUSTOM RETRY I1 1/3: Fixable error"):
        await orch._handle_failure(issue, result, "run-1", ["dev"])


@pytest.mark.asyncio
@pytest.mark.unit
async def test_handle_failure_normalizes_idesign_violation_message_when_disabled(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="dev", summary="Test", retry_count=0, max_retries=3)
    result = SimpleNamespace(error="raw", violations=["Tool write_file failed: Permission denied"])
    class CustomEvaluator:
        def evaluate_failure(self, inputs):
            return {"action": "governance_violation", "next_retry_count": inputs.retry_count}

        def failure_exception_class(self, action):
            return ExecutionFailed

        def status_for_failure_action(self, action):
            return CardStatus.BLOCKED

        def governance_violation_message(self, error):
            return "iDesign Violation: Governance violations: ['Tool write_file failed: Permission denied']"

    orch.evaluator_node = CustomEvaluator()

    with pytest.raises(ExecutionFailed) as exc:
        await orch._handle_failure(issue, result, "run-1", ["dev"])

    message = str(exc.value)
    assert "Governance Violation:" in message
    assert "iDesign Violation:" not in message


@pytest.mark.asyncio
@pytest.mark.unit
async def test_handle_failure_keeps_idesign_violation_message_when_enabled(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(
        id="I1",
        seat="dev",
        summary="Test",
        retry_count=0,
        max_retries=3,
        params={"idesign_enabled": True},
    )
    result = SimpleNamespace(error="raw", violations=["Tool write_file failed: Permission denied"])
    class CustomEvaluator:
        def evaluate_failure(self, inputs):
            return {"action": "governance_violation", "next_retry_count": inputs.retry_count}

        def failure_exception_class(self, action):
            return ExecutionFailed

        def status_for_failure_action(self, action):
            return CardStatus.BLOCKED

        def governance_violation_message(self, error):
            return "iDesign Violation: Governance violations: ['Tool write_file failed: Permission denied']"

    orch.evaluator_node = CustomEvaluator()

    with pytest.raises(ExecutionFailed) as exc:
        await orch._handle_failure(issue, result, "run-1", ["dev"])

    message = str(exc.value)
    assert "iDesign Violation:" in message


@pytest.mark.asyncio
@pytest.mark.unit
async def test_handle_failure_approval_pending_preserves_issue_state_without_scheduler_transition(orchestrator):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test", status=CardStatus.IN_PROGRESS, retry_count=0, max_retries=3)
        result = SimpleNamespace(error="Approval required for tool 'write_file'", violations=[])
        class CustomEvaluator:
            def evaluate_failure(self, inputs):
                return {"action": "approval_pending", "next_retry_count": inputs.retry_count}

            def failure_exception_class(self, action):
                return ExecutionFailed

            def status_for_failure_action(self, action):
                return CardStatus.READY

            def failure_event_name(self, action):
                return "approval_pending"

        transition_spy = AsyncSpy(return_value=None)
        orch.evaluator_node = CustomEvaluator()
        orch._request_issue_transition = transition_spy

        with pytest.raises(ExecutionFailed, match="Approval required for tool 'write_file'"):
            await orch._handle_failure(issue, result, "run-1", ["dev"])

        assert transition_spy.calls == []
        assert len(cards.save.calls) == 1
        saved_issue = cards.save.calls[0][0][0]
        assert saved_issue["id"] == "I1"
        assert saved_issue["status"] == CardStatus.IN_PROGRESS.value


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_honors_custom_loop_policy(orchestrator, tmp_path):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = SimpleNamespace(id="I1", status=CardStatus.READY, seat="dev")
        epic = SimpleNamespace(name="Policy Epic", issues=[issue], references=[])
        team = SimpleNamespace(
            seats={
                "dev": SimpleNamespace(roles=["dev"]),
                "code_reviewer": SimpleNamespace(roles=["code_reviewer"]),
            }
        )
        env = SimpleNamespace(temperature=0.1, timeout=30)

        cards.get_by_build.side_effect = [[issue], [issue]]
        cards.independent_ready.side_effect = [[issue]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")

        class CustomLoopPolicy:
            def concurrency_limit(self, organization):
                return 1

            def max_iterations(self, organization):
                return 1

            def is_backlog_done(self, backlog):
                return False

        hit = {"count": 0}

        async def _fake_execute_issue_turn(*args, **kwargs):
            hit["count"] += 1
            return None

        orch.loop_policy_node = CustomLoopPolicy()
        orch._execute_issue_turn = _fake_execute_issue_turn

        with pytest.raises(ExecutionFailed, match="Hyper-Loop exhausted iterations"):
            await orch.execute_epic(
                active_build="build-policy",
                run_id="run-policy",
                epic=epic,
                team=team,
                env=env,
            )

        assert hit["count"] == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_uses_custom_model_clients(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"dev": SimpleNamespace(roles=["lead_architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="dev", description="role", tools=[]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            def __init__(self, owner):
                self._owner = owner

            async def complete(self, _messages):
                return SimpleNamespace(content="ok", raw={})

            async def clear_context(self):
                return None

            async def close(self):
                self._owner.close_calls += 1

        class CustomModelClientNode:
            def __init__(self):
                self.provider_calls = 0
                self.client_calls = 0
                self.close_calls = 0

            def create_provider(self, selected_model, env):
                self.provider_calls += 1
                return _Provider(self)

            def create_client(self, provider):
                self.client_calls += 1
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "SYSTEM",
        )

        orch.memory = _Memory()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop
        orch.model_clients = CustomModelClientNode()

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert orch.model_clients.provider_calls == 1
        assert orch.model_clients.client_calls == 1
        assert orch.model_clients.close_calls == 1


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_prefers_explicit_model_override_for_prompt_strategy(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"dev": SimpleNamespace(roles=["lead_architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="dev", description="role", tools=[]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            def __init__(self, owner):
                self._owner = owner

            async def complete(self, _messages):
                return SimpleNamespace(content="ok", raw={})

            async def clear_context(self):
                return None

            async def close(self):
                self._owner.close_calls += 1

        class _ModelClientNode:
            def __init__(self):
                self.provider_model = None
                self.close_calls = 0

            def create_provider(self, selected_model, env):
                self.provider_model = selected_model
                return _Provider(self)

            def create_client(self, provider):
                return SimpleNamespace()

        captured = {"override": None, "dialect_model": None}

        class _PromptStrategy:
            def select_model(self, inputs):
                captured["override"] = "strategy-called"
                return "dummy-model"

            def select_dialect(self, model):
                captured["dialect_model"] = model
                return "generic"

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "SYSTEM",
        )

        orch.memory = _Memory()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop
        orch.model_clients = _ModelClientNode()

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
            model_override="google/gemma-4-26b-a4b",
        )

        assert captured["override"] is None
        assert captured["dialect_model"] == "google/gemma-4-26b-a4b"
        assert orch.model_clients.provider_model == "google/gemma-4-26b-a4b"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_closes_provider_per_turn_across_repeated_cycles(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"dev": SimpleNamespace(roles=["lead_architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="dev", description="role", tools=[]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
            * 20
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            def __init__(self, owner):
                self._owner = owner

            async def complete(self, _messages):
                return SimpleNamespace(content="ok", raw={})

            async def clear_context(self):
                return None

            async def close(self):
                self._owner.close_calls += 1

        class _Client:
            def __init__(self, provider, owner):
                self._provider = provider
                self._owner = owner

            async def complete(self, _messages):
                self._owner.complete_calls += 1
                return await self._provider.complete(_messages)

        class _ModelClientNode:
            def __init__(self):
                self.provider_calls = 0
                self.client_calls = 0
                self.close_calls = 0
                self.complete_calls = 0

            def create_provider(self, selected_model, env):
                self.provider_calls += 1
                return _Provider(self)

            def create_client(self, provider):
                self.client_calls += 1
                return _Client(provider, self)

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                await client.complete([{"role": "user", "content": "ping"}])
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "SYSTEM",
        )

        orch.memory = _Memory()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop
        orch.model_clients = _ModelClientNode()

        for cycle in range(20):
            await orch._execute_issue_turn(
                issue_data=issue_data,
                epic=epic,
                team=team,
                env=env,
                run_id=f"run-{cycle}",
                active_build="build-1",
                model_selection=prepared_model_selection(_PromptStrategy()),
                executor=_Executor(),
                toolbox=SimpleNamespace(),
            )

        assert orch.model_clients.provider_calls == 20
        assert orch.model_clients.client_calls == 20
        assert orch.model_clients.complete_calls == 20
        assert orch.model_clients.close_calls == 20


@pytest.mark.asyncio
@pytest.mark.unit
async def test_execute_issue_turn_skips_sandbox_when_policy_disabled(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        issue = IssueConfig(id="I1", seat="dev", summary="Test")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"dev": SimpleNamespace(roles=["lead_architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="dev", description="role", tools=[]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _Evaluator:
            def evaluate_success(self, _inputs):
                return {}

            def success_post_actions(self, _success_eval):
                return {"trigger_sandbox": True, "next_status": None}

            def should_trigger_sandbox(self, success_actions):
                return bool(success_actions.get("trigger_sandbox"))

            def next_status_after_success(self, success_actions):
                return success_actions.get("next_status")

        async def _noop(*args, **kwargs):
            return None

        trigger_calls = {"count": 0}

        async def _fake_trigger(*args, **kwargs):
            trigger_calls["count"] += 1
            return None

        monkeypatch.setenv("ORKET_DISABLE_SANDBOX", "1")
        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "SYSTEM",
        )

        orch.memory = _Memory()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _fake_trigger
        orch.model_clients = _ModelClientNode()
        orch.evaluator_node = _Evaluator()

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert trigger_calls["count"] == 0


@pytest.mark.integration
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_blocks_review_when_runtime_verifier_fails(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = IssueConfig(
            id="REV-1",
            seat="code_reviewer",
            summary="Review",
            status=CardStatus.CODE_REVIEW,
            note="Preserve the original review instructions.",
        )
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"code_reviewer": SimpleNamespace(roles=["code_reviewer"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Executor:
            def __init__(self):
                self.calls = 0

            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                self.calls += 1
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _RuntimeVerifier:
            def __init__(self, workspace_root, organization=None, *, project_surface_profile=None, architecture_pattern=None, artifact_contract=None, issue_params=None):
                self.workspace_root = workspace_root

            async def verify(self):
                return SimpleNamespace(
                    ok=False,
                    checked_files=["agent_output/main.py"],
                    errors=["SyntaxError: invalid syntax", "runtime stdout assertion failed: path=blocked_state"],
                    command_results=[
                        {
                            "command_id": "command:001",
                            "command_display": "python -m compileall -q agent_output",
                            "working_directory": ".",
                            "returncode": 1,
                            "outcome": "fail",
                            "failure_class": "command_failed",
                            "evidence_class": "syntax_only",
                        }
                    ],
                    failure_breakdown={"command_failed": 1},
                    overall_evidence_class="syntax_only",
                    evidence_summary={
                        "syntax_only": {
                            "evaluated": True,
                            "checked_files": ["agent_output/main.py"],
                            "commands": [
                                {
                                    "command_id": "command:001",
                                    "command_display": "python -m compileall -q agent_output",
                                    "working_directory": ".",
                                    "outcome": "fail",
                                    "returncode": 1,
                                    "failure_class": "command_failed",
                                }
                            ],
                        },
                        "command_execution": {"evaluated": False, "commands": []},
                        "behavioral_verification": {
                            "evaluated": False,
                            "stdout_contract_requested": False,
                            "json_assertion_count": 0,
                            "commands": [],
                        },
                        "not_evaluated": [
                            {
                                "check": "behavioral_verification",
                                "reason": "no runtime stdout contract requested behavioral verification",
                            }
                        ],
                    },
                )

        monkeypatch.setattr("orket.application.services.orchestrator_support_services.RuntimeVerifier", _RuntimeVerifier)
        executor = _Executor()

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=executor,
            toolbox=SimpleNamespace(),
        )

        assert executor.calls == 0
        saved_issue = cards.save.calls[-1][0][0]
        assert saved_issue["status"] == CardStatus.READY
        assert saved_issue["retry_count"] == 1
        assert saved_issue["note"] == "Preserve the original review instructions."
        assert saved_issue["params"]["runtime_retry_note"] == (
            "runtime_guard_retry_scheduled: "
            "SyntaxError: invalid syntax | runtime stdout assertion failed: path=blocked_state"
        )
        report_path = orch.workspace / "agent_output" / "verification" / "runtime_verification.json"
        index_path = orch.workspace / "agent_output" / "verification" / "runtime_verification_index.json"
        assert report_path.exists()
        assert index_path.exists()
        report = json.loads(report_path.read_text(encoding="utf-8"))
        assert report["ok"] is False
        assert report["artifact_role"] == "support_verification_evidence"
        assert report["artifact_authority"] == "support_only"
        assert report["authored_output"] is False
        assert report["overall_evidence_class"] == "syntax_only"
        assert report["provenance"]["issue_id"] == "REV-1"
        assert report["provenance"]["turn_index"] == 1
        assert report["provenance"]["retry_count"] == 0
        assert report["history"]["index_path"] == "agent_output/verification/runtime_verification_index.json"
        assert (orch.workspace / report["history"]["record_path"]).exists()
        assert isinstance(report.get("command_results"), list)
        assert isinstance(report.get("failure_breakdown"), dict)
        assert report.get("guard_contract", {}).get("result") == "fail"
        assert report.get("guard_decision", {}).get("action") == "retry"


@pytest.mark.contract
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_marks_terminal_failure_when_runtime_retries_exhausted(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = IssueConfig(
            id="REV-1",
            seat="code_reviewer",
            summary="Review",
            status=CardStatus.CODE_REVIEW,
            retry_count=3,
            max_retries=3,
        )
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"code_reviewer": SimpleNamespace(roles=["code_reviewer"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Executor:
            def __init__(self):
                self.calls = 0

            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                self.calls += 1
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _RuntimeVerifier:
            def __init__(self, workspace_root, organization=None, *, project_surface_profile=None, architecture_pattern=None, artifact_contract=None, issue_params=None):
                self.workspace_root = workspace_root

            async def verify(self):
                return SimpleNamespace(
                    ok=False,
                    checked_files=["agent_output/main.py"],
                    errors=["SyntaxError: invalid syntax"],
                    command_results=[],
                    failure_breakdown={},
                    overall_evidence_class="not_evaluated",
                    evidence_summary={
                        "syntax_only": {"evaluated": True, "checked_files": ["agent_output/main.py"], "commands": []},
                        "command_execution": {"evaluated": False, "commands": []},
                        "behavioral_verification": {
                            "evaluated": False,
                            "stdout_contract_requested": False,
                            "json_assertion_count": 0,
                            "commands": [],
                        },
                        "not_evaluated": [
                            {
                                "check": "behavioral_verification",
                                "reason": "no runtime stdout contract requested behavioral verification",
                            }
                        ],
                    },
                )

        monkeypatch.setattr("orket.application.services.orchestrator_support_services.RuntimeVerifier", _RuntimeVerifier)
        executor = _Executor()

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=executor,
            toolbox=SimpleNamespace(),
        )

        assert executor.calls == 0
        saved_issue = cards.save.calls[-1][0][0]
        assert saved_issue["status"] == CardStatus.BLOCKED
        assert saved_issue["retry_count"] == 3
        report_path = orch.workspace / "agent_output" / "verification" / "runtime_verification.json"
        report = json.loads(report_path.read_text(encoding="utf-8"))
        assert report.get("guard_decision", {}).get("action") == "terminal_failure"


@pytest.mark.contract
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_marks_terminal_failure_for_repeated_guard_fingerprint(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        seen_fingerprints = []
        seed_decision = GuardAgent().evaluate(
            contract=build_runtime_guard_contract(ok=False, errors=["SyntaxError: invalid syntax"]),
            retry_count=0,
            max_retries=3,
            output_text="SyntaxError: invalid syntax",
            seen_fingerprints=seen_fingerprints,
        )
        issue = IssueConfig(
            id="REV-1",
            seat="code_reviewer",
            summary="Review",
            status=CardStatus.CODE_REVIEW,
            retry_count=1,
            max_retries=3,
            params={"guard_retry_fingerprints": [seed_decision.retry_fingerprint]},
        )
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"code_reviewer": SimpleNamespace(roles=["code_reviewer"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Executor:
            def __init__(self):
                self.calls = 0

            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                self.calls += 1
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _RuntimeVerifier:
            def __init__(self, workspace_root, organization=None, *, project_surface_profile=None, architecture_pattern=None, artifact_contract=None, issue_params=None):
                self.workspace_root = workspace_root

            async def verify(self):
                return SimpleNamespace(
                    ok=False,
                    checked_files=["agent_output/main.py"],
                    errors=["SyntaxError: invalid syntax"],
                    command_results=[],
                    failure_breakdown={},
                    overall_evidence_class="not_evaluated",
                    evidence_summary={
                        "syntax_only": {"evaluated": True, "checked_files": ["agent_output/main.py"], "commands": []},
                        "command_execution": {"evaluated": False, "commands": []},
                        "behavioral_verification": {
                            "evaluated": False,
                            "stdout_contract_requested": False,
                            "json_assertion_count": 0,
                            "commands": [],
                        },
                        "not_evaluated": [
                            {
                                "check": "behavioral_verification",
                                "reason": "no runtime stdout contract requested behavioral verification",
                            }
                        ],
                    },
                )

        monkeypatch.setattr("orket.application.services.orchestrator_support_services.RuntimeVerifier", _RuntimeVerifier)
        executor = _Executor()

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=executor,
            toolbox=SimpleNamespace(),
        )

        assert executor.calls == 0
        saved_issue = cards.save.calls[-1][0][0]
        assert saved_issue["status"] == CardStatus.BLOCKED
        report_path = orch.workspace / "agent_output" / "verification" / "runtime_verification.json"
        report = json.loads(report_path.read_text(encoding="utf-8"))
        assert report.get("guard_decision", {}).get("action") == "terminal_failure"
        assert report.get("guard_decision", {}).get("terminal_reason", {}).get("code") == "MODEL_NON_COMPLIANT"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_uses_prompt_resolver_when_policy_enabled(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        orch.org.process_rules["prompt_resolver_mode"] = "resolver"
        issue = IssueConfig(id="I1", seat="architect", summary="Design")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"architect": SimpleNamespace(roles=["architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(
                    name="architect",
                    description="Role",
                    tools=[],
                    prompt_metadata={"id": "role.architect", "version": "2.1.0"},
                ),
                DialectConfig(
                    model_family="generic",
                    dsl_format="json",
                    constraints=[],
                    hallucination_guard="none",
                    prompt_metadata={"id": "dialect.generic", "version": "1.3.0"},
                ),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["context"] = context
                captured["system_prompt"] = system_prompt
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _Resolution:
            def __init__(self):
                self.system_prompt = "RESOLVED PROMPT"
                self.metadata = {
                    "prompt_id": "role.architect+dialect.generic",
                    "prompt_version": "2.1.0/1.3.0",
                    "prompt_checksum": "abc123",
                    "resolver_policy": "resolver_v1",
                }
                self.layers = {
                    "role_base": {"name": "architect", "version": "2.1.0"},
                    "dialect_adapter": {"name": "generic", "version": "1.3.0", "prefix_applied": False},
                    "guards": [],
                    "context_profile": "default",
                }

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_resolver.PromptResolver.resolve",
            lambda **kwargs: _Resolution(),
        )

        orch.memory = _Memory()
        orch.model_clients = _ModelClientNode()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["system_prompt"].partition("\n\nDeclared card acceptance:\n")[0] == "RESOLVED PROMPT"
        assert captured["context"]["prompt_metadata"]["prompt_id"] == "role.architect+dialect.generic"
        assert captured["context"]["prompt_metadata"]["resolver_policy"] == "resolver_v1"
        assert captured["context"]["prompt_layers"]["role_base"]["version"] == "2.1.0"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_uses_prompt_compiler_when_resolver_disabled(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        orch.org.process_rules["prompt_resolver_mode"] = "compiler"
        issue = IssueConfig(id="I1", seat="architect", summary="Design")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"architect": SimpleNamespace(roles=["architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="architect", description="Role", tools=[], prompt_metadata={}),
                DialectConfig(
                    model_family="generic",
                    dsl_format="json",
                    constraints=[],
                    hallucination_guard="none",
                    prompt_metadata={},
                ),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["context"] = context
                captured["system_prompt"] = system_prompt
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "COMPILER PROMPT",
        )
        monkeypatch.setattr(
            "orket.application.services.prompt_resolver.PromptResolver.resolve",
            lambda **kwargs: (_ for _ in ()).throw(AssertionError("resolver should not be called")),
        )

        orch.memory = _Memory()
        orch.model_clients = _ModelClientNode()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["system_prompt"].partition("\n\nDeclared card acceptance:\n")[0] == "COMPILER PROMPT"
        assert captured["context"]["prompt_metadata"]["prompt_id"] == "legacy.prompt_compiler"
        assert captured["context"]["prompt_metadata"]["resolver_policy"] == "compiler"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_suppresses_reference_context_for_cards_runtime_issue(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        orch.org.process_rules["prompt_resolver_mode"] = "compiler"
        issue = IssueConfig(
            id="I1",
            seat="coder",
            summary="Implement contract-heavy artifact",
            params={
                "execution_profile": "write_artifact_v1",
                "artifact_contract": {
                    "kind": "artifact",
                    "primary_output": "agent_output/out.txt",
                    "required_read_paths": ["agent_output/requirements.txt"],
                    "required_write_paths": ["agent_output/out.txt"],
                    "review_read_paths": ["agent_output/out.txt"],
                },
            },
        )
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"coder": SimpleNamespace(roles=["coder"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="coder", description="Role", tools=[], prompt_metadata={}),
                DialectConfig(
                    model_family="generic",
                    dsl_format="json",
                    constraints=[],
                    hallucination_guard="none",
                    prompt_metadata={},
                ),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return [{"content": "stale benchmark memory", "metadata": {}, "timestamp": "2026-04-03T00:00:00+00:00"}]

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["system_prompt"] = system_prompt
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "COMPILER PROMPT",
        )

        orch.memory = _Memory()
        orch.model_clients = _ModelClientNode()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["system_prompt"].partition("\n\nDeclared card acceptance:\n")[0] == "COMPILER PROMPT"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_passes_default_prompt_selection_policy(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        orch.org.process_rules["prompt_resolver_mode"] = "resolver"
        issue = IssueConfig(id="I1", seat="architect", summary="Design")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"architect": SimpleNamespace(roles=["architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="architect", description="Role", tools=[], prompt_metadata={}),
                DialectConfig(
                    model_family="generic",
                    dsl_format="json",
                    constraints=[],
                    hallucination_guard="none",
                    prompt_metadata={},
                ),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _Resolution:
            def __init__(self):
                self.system_prompt = "RESOLVED PROMPT"
                self.metadata = {
                    "prompt_id": "role.architect+dialect.generic",
                    "prompt_version": "1.0.0/1.0.0",
                    "prompt_checksum": "abc123",
                    "resolver_policy": "resolver_v1",
                }
                self.layers = {
                    "role_base": {"name": "architect", "version": "1.0.0"},
                    "dialect_adapter": {"name": "generic", "version": "1.0.0", "prefix_applied": False},
                    "guards": [],
                    "context_profile": "default",
                }

        async def _noop(*args, **kwargs):
            return None

        def _fake_resolve(**kwargs):
            captured["kwargs"] = kwargs
            return _Resolution()

        monkeypatch.setattr("orket.application.services.prompt_resolver.PromptResolver.resolve", _fake_resolve)

        orch.memory = _Memory()
        orch.model_clients = _ModelClientNode()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["kwargs"]["selection_policy"] == "stable"
        assert captured["kwargs"]["context"]["prompt_selection_policy"] == "stable"
        assert captured["kwargs"]["context"]["prompt_selection_strict"] is True
        assert "required_action_tools" in captured["kwargs"]["context"]
        assert "required_statuses" in captured["kwargs"]["context"]
        assert "required_read_paths" in captured["kwargs"]["context"]
        assert "required_write_paths" in captured["kwargs"]["context"]
        assert captured["kwargs"]["guards"] == ["hallucination"]
        assert "HALLUCINATION.FILE_NOT_FOUND" in captured["kwargs"]["context"]["runtime_guard_rule_ids"]


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_passes_runtime_prompt_patch_into_resolver(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        orch.org.process_rules["prompt_resolver_mode"] = "resolver"
        monkeypatch.setenv("ORKET_PROMPT_PATCH", "Patch line one.\nPatch line two.")
        monkeypatch.setenv("ORKET_PROMPT_PATCH_LABEL", "gemma-tool-use-v1")
        issue = IssueConfig(id="I1", seat="architect", summary="Design")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"architect": SimpleNamespace(roles=["architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="architect", description="Role", tools=[], prompt_metadata={}),
                DialectConfig(
                    model_family="generic",
                    dsl_format="json",
                    constraints=[],
                    hallucination_guard="none",
                    prompt_metadata={},
                ),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["context"] = context
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        class _Resolution:
            def __init__(self):
                self.system_prompt = "RESOLVED PROMPT"
                self.metadata = {
                    "prompt_id": "role.architect+dialect.generic",
                    "prompt_version": "1.0.0/1.0.0",
                    "prompt_checksum": "abc123",
                    "resolver_policy": "resolver_v1",
                }
                self.layers = {
                    "role_base": {"name": "architect", "version": "1.0.0"},
                    "dialect_adapter": {"name": "generic", "version": "1.0.0", "prefix_applied": False},
                    "guards": [],
                    "context_profile": "default",
                }

        async def _noop(*args, **kwargs):
            return None

        def _fake_resolve(**kwargs):
            captured["kwargs"] = kwargs
            return _Resolution()

        monkeypatch.setattr("orket.application.services.prompt_resolver.PromptResolver.resolve", _fake_resolve)

        orch.memory = _Memory()
        orch.model_clients = _ModelClientNode()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["kwargs"]["patch"] == "Patch line one.\nPatch line two."
        assert captured["context"]["prompt_metadata"]["prompt_patch_applied"] is True
        assert captured["context"]["prompt_metadata"]["prompt_patch_label"] == "gemma-tool-use-v1"
        assert captured["context"]["prompt_layers"]["patch"]["applied"] is True


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_passes_runtime_prompt_patch_into_compiler(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        monkeypatch.setenv("ORKET_PROMPT_PATCH", "Compiler patch.")
        issue = IssueConfig(id="I1", seat="architect", summary="Design")
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1")
        team = SimpleNamespace(seats={"architect": SimpleNamespace(roles=["architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="architect", description="Role", tools=[], prompt_metadata={}),
                DialectConfig(
                    model_family="generic",
                    dsl_format="json",
                    constraints=[],
                    hallucination_guard="none",
                    prompt_metadata={},
                ),
            ]
        )

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClientNode:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["context"] = context
                captured["system_prompt"] = system_prompt
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        def _fake_compile(skill, dialect, **kwargs):
            captured["compile_kwargs"] = kwargs
            return "COMPILER PROMPT"

        monkeypatch.setattr("orket.application.services.prompt_compiler.PromptCompiler.compile", _fake_compile)

        orch.memory = _Memory()
        orch.model_clients = _ModelClientNode()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["compile_kwargs"]["patch"] == "Compiler patch."
        assert captured["context"]["prompt_metadata"]["prompt_patch_applied"] is True
        assert captured["system_prompt"].partition("\n\nDeclared card acceptance:\n")[0] == "COMPILER PROMPT"


@pytest.mark.integration
@pytest.mark.asyncio
# Layer: unit
# Layer: unit
async def test_execute_epic_uses_custom_tool_strategy_node(tmp_path, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(tmp_path))):
        install_dispatch_snapshot_stub(monkeypatch)
        issue_ready = SimpleNamespace(
            id="I1",
            status=CardStatus.READY,
            seat="lead_architect",
            model_dump=lambda: {"id": "I1", "seat": "lead_architect", "summary": "Test", "status": "ready"},
        )
        issue_stopped = SimpleNamespace(id="I1", status=CardStatus.CANCELED, seat="lead_architect")

        cards = FakeCards()
        cards.get_by_build.side_effect = [[issue_ready], [issue_stopped]]
        cards.independent_ready.side_effect = [[issue_ready], []]

        snapshots = FakeSnapshots()
        loader = FakeLoader(tmp_path)
        loader.queue_assets(
            [
                SimpleNamespace(name="lead_architect", description="Role", tools=["read_file"]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
        )

        org = SimpleNamespace(process_rules={"tool_strategy_node": "custom-tool-strategy"})
        orch = Orchestrator(
            workspace=tmp_path,
            async_cards=cards,
            snapshots=snapshots,
            org=org,
            config_root=tmp_path,
            db_path=str(tmp_path / "test.db"),
            loader=loader,
            sandbox_orchestrator=FakeSandbox(),
            architecture_policy=ArchitecturePolicySnapshot(False),
         turn_clock=artifact_test_utc_now)

        class CustomToolStrategy:
            def select_tools(self, inputs):
                return ("read_file",)

        class _PromptStrategy:
            def select_model(self, inputs):
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClient:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        tool_strategy_hit = {"used": False}

        async def _fake_execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
            (tmp_path / "strategy.txt").write_text("application-owned binding", encoding="utf-8")
            res = await toolbox.execute("read_file", {"path": "strategy.txt"}, context=context)
            tool_strategy_hit["used"] = res.get("ok") is True and res.get("content") == "application-owned binding"
            return TurnResult(
                success=True,
                turn=ExecutionTurn(timestamp=None, role=context["role"], issue_id=context["issue_id"], content="Turn handled; work awaits review.", note=""),
            )

        orch.decision_nodes.register_tool_strategy("custom-tool-strategy", CustomToolStrategy())
        orch.decision_nodes.resolve_prompt_strategy = lambda *_args, **_kwargs: _PromptStrategy()
        orch.model_clients = _ModelClient()
        orch.memory = _Memory()
        orch._save_checkpoint = AsyncSpy(return_value=None)

        monkeypatch.setattr("orket.application.workflows.turn_executor.TurnExecutor.execute_turn", _fake_execute_turn)

        epic = SimpleNamespace(name="Tool Strategy Epic", references=[], issues=[], parent_id=None, id="EPIC-1")
        team = SimpleNamespace(seats={"lead_architect": SimpleNamespace(roles=["lead_architect"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")

        await orch.execute_epic(
            active_build="build-tool-strategy",
            run_id="run-tool-strategy",
            epic=epic,
            team=team,
            env=env,
        )

        assert tool_strategy_hit["used"] is True

@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_includes_stage_gate_mode(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="integrity_guard", summary="Guard Review")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="integrity_guard",
        roles_to_load=["integrity_guard"],
        turn_status=CardStatus.AWAITING_GUARD_REVIEW,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["stage_gate_mode"] == "review_required"
    assert context["approval_required_tools"] == []
    assert context["required_read_paths"] == ["agent_output/main.py"]
    assert callable(context["create_pending_gate_request"])


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_promotes_gate_mode_when_approval_tools_present(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="coder", summary="Code Work")

    class _LoopPolicy:
        def required_action_tools_for_seat(self, inputs):
            return ["write_file", "update_issue_status"]

        def required_statuses_for_seat(self, inputs):
            return ["code_review"]

        def gate_mode_for_seat(self, inputs):
            return "auto"

        def approval_required_tools_for_seat(self, inputs):
            return ["write_file"]

        def required_read_paths_for_seat(self, inputs):
            return []

    orch.loop_policy_node = _LoopPolicy()
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["approval_required_tools"] == ["write_file"]
    assert context["stage_gate_mode"] == "approval_required"

@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_includes_required_read_paths_for_reviewer(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="REV-1", seat="code_reviewer", summary="Review")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="code_reviewer",
        roles_to_load=["code_reviewer"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        dependency_context={"depends_on": ["COD-1"], "dependency_count": 1, "dependency_statuses": {}, "unresolved_dependencies": []},
        resume_mode=False,
    )
    assert context["required_read_paths"] == [
        "agent_output/requirements.txt",
        "agent_output/main.py",
    ]
    assert context["required_write_paths"] == []

@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_includes_required_write_paths_for_coder(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="COD-1", seat="coder", summary="Implement")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["required_write_paths"] == ["agent_output/main.py"]

@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_non_final_guard_requires_done_status(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="COD-1", seat="coder", summary="Guard handoff")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="integrity_guard",
        roles_to_load=["integrity_guard"],
        turn_status=CardStatus.AWAITING_GUARD_REVIEW,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["required_statuses"] == ["done"]
    assert context["required_action_tools"] == ["read_file", "update_issue_status"]
    assert context["required_read_paths"] == ["agent_output/main.py"]


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_final_guard_includes_read_contract(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="REV-1", seat="code_reviewer", summary="Final guard review")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="integrity_guard",
        roles_to_load=["integrity_guard"],
        turn_status=CardStatus.AWAITING_GUARD_REVIEW,
        selected_model="dummy-model",
        runtime_verifier_ok=True,
        resume_mode=False,
    )
    assert context["required_statuses"] == ["done", "blocked"]
    assert context["required_action_tools"] == ["read_file", "update_issue_status"]
    assert context["required_read_paths"] == [
        "agent_output/requirements.txt",
        "agent_output/design.txt",
        "agent_output/main.py",
        "agent_output/verification/runtime_verification.json",
    ]
    assert context["runtime_verifier_ok"] is True


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_includes_architecture_contract_for_architect(orchestrator, monkeypatch):
    """Layer: unit. Architecture evaluation consumes the explicit unlock snapshot."""
    orch, _cards, _loader = orchestrator
    orch.architecture_policy = ArchitecturePolicySnapshot(True)
    orch.org = SimpleNamespace(
        process_rules={
            "architecture_mode": "force_microservices",
            "frontend_framework_mode": "force_angular",
        }
    )
    issue = IssueConfig(id="ARC-1", seat="architect", summary="Design architecture")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="architect",
        roles_to_load=["architect"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["architecture_mode"] == "force_microservices"
    assert context["architecture_decision_required"] is True
    assert context["architecture_decision_path"] == "agent_output/design.txt"
    assert context["architecture_forced_pattern"] == "microservices"
    assert context["frontend_framework_mode"] == "force_angular"
    assert context["frontend_framework_forced"] == "angular"
    assert "angular" in context["frontend_framework_allowed"]
    assert "monolith" in context["architecture_allowed_patterns"]
    assert "microservices" in context["architecture_allowed_patterns"]


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_declares_role_tools_when_required_actions_are_empty(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="product_owner", summary="Define acceptance packet")
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="product_owner",
        roles_to_load=["product_owner"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
        skill_tool_bindings=synthesize_role_tool_profile_bindings(
            [
                "read_file",
                "write_file",
                "add_issue_comment",
                "get_issue_context",
                "update_issue_status",
            ]
        ),
    )

    declared = context["verification_scope"]["declared_interfaces"]
    assert "add_issue_comment" in declared
    assert "get_issue_context" in declared
    assert "update_issue_status" in declared


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_applies_issue_turn_contract_overrides(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(
        id="I2",
        seat="product_owner",
        summary="Define exit criteria",
        params={
            "turn_contract": {
                "required_action_tools": ["add_issue_comment", "update_issue_status"],
                "required_statuses": ["done"],
                "required_read_paths": ["docs/ROADMAP.md"],
                "required_write_paths": ["agent_output/soak_matrix/product/exit_criteria.md"],
                "required_comment_min_length": 120,
                "required_comment_contains": ["Findings", "Evidence"],
            }
        },
    )
    context = await orch._build_turn_context(
        run_id="run-2",
        issue=issue,
        seat_name="product_owner",
        roles_to_load=["product_owner"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
        skill_tool_bindings=synthesize_role_tool_profile_bindings(
            [
                "read_file",
                "write_file",
                "add_issue_comment",
                "get_issue_context",
                "update_issue_status",
            ]
        ),
    )

    assert context["required_action_tools"] == ["add_issue_comment", "update_issue_status"]
    assert context["required_statuses"] == ["done"]
    assert context["required_read_paths"] == ["docs/ROADMAP.md"]
    assert context["required_write_paths"] == ["agent_output/soak_matrix/product/exit_criteria.md"]
    assert context["required_comment_min_length"] == 120
    assert context["required_comment_contains"] == ["Findings", "Evidence"]
    declared = context["verification_scope"]["declared_interfaces"]
    assert "add_issue_comment" in declared
    assert "update_issue_status" in declared


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_does_not_apply_issue_turn_contract_overrides_to_guard(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(
        id="I2",
        seat="product_owner",
        summary="Define exit criteria",
        params={
            "artifact_contract": {
                "kind": "artifact",
                "primary_output": "agent_output/soak_matrix/product/product_brief.md",
                "required_write_paths": ["agent_output/soak_matrix/product/product_brief.md"],
                "review_read_paths": ["agent_output/soak_matrix/product/product_brief.md"],
            },
            "turn_contract": {
                "required_action_tools": ["write_file", "update_issue_status"],
                "required_statuses": ["code_review"],
                "required_read_paths": ["docs/ROADMAP.md"],
                "required_write_paths": ["agent_output/soak_matrix/product/exit_criteria.md"],
            }
        },
    )
    context = await orch._build_turn_context(
        run_id="run-guard",
        issue=issue,
        seat_name="integrity_guard",
        roles_to_load=["integrity_guard"],
        turn_status=CardStatus.AWAITING_GUARD_REVIEW,
        selected_model="dummy-model",
        runtime_verifier_ok=True,
        resume_mode=False,
    )

    assert context["required_action_tools"] == ["read_file", "update_issue_status"]
    assert context["required_statuses"] == ["done"]
    assert context["required_read_paths"] == ["agent_output/soak_matrix/product/product_brief.md"]
    assert context["required_write_paths"] == []


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_includes_profile_traits_and_scenario_truth(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(
        id="RMS-22",
        seat="market_researcher",
        summary="Repo-local provider comparison",
        params={
            "execution_profile": "truthful_block_only_v1",
            "cards_runtime": {
                "scenario_truth": {
                    "scenario_id": "role_matrix_soak_v1",
                    "blocked_issue_policy": {
                        "allowed_issue_ids": ["RMS-22"],
                        "blocked_implies_run_failure": True,
                    },
                    "expected_terminal_status": "terminal_failure",
                }
            },
            "turn_contract": {
                "required_action_tools": ["read_file", "update_issue_status"],
                "required_statuses": ["blocked"],
                "required_read_paths": [
                    "benchmarks/results/probes/provider_codegen_matrix/primary/ollama.chain.json",
                ],
            },
            "runtime_verifier": {
                "expect_json_stdout": True,
            },
        },
    )
    context = await orch._build_turn_context(
        run_id="run-blocked",
        issue=issue,
        seat_name="market_researcher",
        roles_to_load=["market_researcher"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["execution_profile"] == "truthful_block_only_v1"
    assert context["profile_traits"]["intent"] == "truthful_block_only"
    assert context["scenario_truth"]["scenario_id"] == "role_matrix_soak_v1"
    assert context["runtime_verifier_contract"] == {}


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_keeps_issue_runtime_verifier_contract_for_write_artifact_profile(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(
        id="WR-ART-1",
        seat="coder",
        summary="Write simulator artifact",
        params={
            "execution_profile": "write_artifact_v1",
            "artifact_contract": {
                "kind": "artifact",
                "primary_output": "agent_output/challenge_runtime/simulator.py",
                "required_write_paths": ["agent_output/challenge_runtime/simulator.py"],
            },
            "runtime_verifier": {
                "commands": [
                    {"argv": ["python", "-c", "print('artifact-proof')"], "cwd": "agent_output"},
                ]
            },
        },
    )
    context = await orch._build_turn_context(
        run_id="run-artifact-override",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["execution_profile"] == "write_artifact_v1"
    assert context["profile_traits"]["intent"] == "write_artifact"
    assert context["runtime_verifier_contract"] == {
        "commands": [
            {"argv": ["python", "-c", "print('artifact-proof')"], "cwd": "agent_output"},
        ]
    }


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_includes_runtime_retry_note(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(
        id="WR-ART-2",
        seat="coder",
        summary="Retry simulator artifact",
        note="Keep truthful simulator semantics.",
        params={"runtime_retry_note": "runtime_guard_retry_scheduled: timeout after 60s"},
    )
    context = await orch._build_turn_context(
        run_id="run-artifact-retry-note",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["runtime_retry_note"] == "runtime_guard_retry_scheduled: timeout after 60s"


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_uses_transcript_length_for_turn_index(orchestrator):
    """Layer: unit."""
    orch, _cards, _loader = orchestrator
    orch.transcript = [
        SimpleNamespace(role="coder", issue_id="I1", content="first"),
        SimpleNamespace(role="reviewer", issue_id="I1", content="second"),
    ]
    orch._history_context = lambda seat_name=None: []
    issue = IssueConfig(id="WR-ART-2A", seat="coder", summary="Retry simulator artifact")

    context = await orch._build_turn_context(
        run_id="run-artifact-turn-index",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["turn_index"] == 3


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_invalid_tool_limits_fail_closed(orchestrator):
    """Layer: unit."""
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(
        process_rules={
            "skill_max_execution_time": "not-a-number",
            "skill_max_memory": "still-not-a-number",
        }
    )
    issue = IssueConfig(id="WR-ART-2B", seat="coder", summary="Retry simulator artifact")

    context = await orch._build_turn_context(
        run_id="run-artifact-tool-limits",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["max_tool_execution_time"] is None
    assert context["max_tool_memory"] is None


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_defaults_to_monolith_and_vue(orchestrator):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={})
    issue = IssueConfig(id="ARC-2", seat="architect", summary="Design architecture")
    context = await orch._build_turn_context(
        run_id="run-2",
        issue=issue,
        seat_name="architect",
        roles_to_load=["architect"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["architecture_mode"] == "force_monolith"
    assert context["architecture_forced_pattern"] == "monolith"
    assert context["frontend_framework_mode"] == "force_vue"
    assert context["frontend_framework_forced"] == "vue"
    assert context["project_surface_profile"] == "unspecified"


@pytest.mark.unit
def test_resolve_architecture_pattern_preserves_architect_decides(orchestrator):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={"architecture_mode": "architect_decides"})

    assert orchestrator_policy.select_architecture_mode(user_settings=orch.support_services.load_user_settings(), process_rules=orchestrator_policy.organization_process_rules(orch.org), environment=orch.decision_environment, architecture_policy=orch.architecture_policy) == "architect_decides"
    assert orchestrator_policy.select_architecture_pattern(orchestrator_policy.select_architecture_mode(user_settings=orch.support_services.load_user_settings(), process_rules=orchestrator_policy.organization_process_rules(orch.org), environment=orch.decision_environment, architecture_policy=orch.architecture_policy)) is None


# Layer: unit
@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_protocol_governed_defaults(orchestrator):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={})
    issue = IssueConfig(id="ARC-3", seat="architect", summary="Design architecture")
    context = await orch._build_turn_context(
        run_id="run-3", issue=issue,
        seat_name="architect", roles_to_load=["architect"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["protocol_governed_enabled"] is False
    assert context["max_response_bytes"] == 8192
    assert context["max_tool_calls"] == 8
    assert context["allowed_tool_rings"] == ["core"]
    assert context["allowed_capability_profiles"] == ["workspace"]
    assert context["allowed_namespace_scopes"] == ["issue:ARC-3"]
    assert context["capabilities_allowed"] == ["workspace"]
    assert context["run_namespace_scope"] == "issue:ARC-3"
    assert context["run_determinism_class"] == "workspace"
    assert context["run_determinism_policy"] == "workspace"
    assert context["compatibility_mappings"] == {}
    assert context["timezone"] == "UTC"
    assert context["locale"] == "C.UTF-8"
    assert context["network_mode"] == "off"
    assert context["network_allowlist_values"] == []
    assert len(context["network_allowlist_hash"]) == 64
    assert context["clock_mode"] == "wall"
    assert context["clock_artifact_ref"] == ""
    assert len(context["clock_artifact_hash"]) == 64
    assert context["env_allowlist"] == {}
    assert context["env_allowlist_values"] == []
    assert len(context["env_allowlist_hash"]) == 64
    assert context["local_prompting_mode"] == "shadow"
    assert context["local_prompting_allow_fallback"] is False
    assert context["local_prompting_fallback_profile_id"] == ""
    assert context["prompt_budget_enabled"] is False
    assert context["prompt_budget_require_backend_tokenizer"] is False
    assert context["prompt_budget_policy_path"] == str(DEFAULT_PROMPT_BUDGET_PATH)


# Layer: unit
@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_protocol_governed_env_overrides(orchestrator, monkeypatch):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={})
    monkeypatch.setenv("ORKET_PROTOCOL_GOVERNED_ENABLED", "true")
    monkeypatch.setenv("ORKET_PROTOCOL_MAX_RESPONSE_BYTES", "4096")
    monkeypatch.setenv("ORKET_PROTOCOL_MAX_TOOL_CALLS", "3")
    monkeypatch.setenv("ORKET_PROTOCOL_TIMEZONE", "America/Denver")
    monkeypatch.setenv("ORKET_PROTOCOL_LOCALE", "en_US.UTF-8")
    monkeypatch.setenv("ORKET_PROTOCOL_NETWORK_MODE", "allowlist")
    monkeypatch.setenv("ORKET_PROTOCOL_NETWORK_ALLOWLIST", "api.example.com,cache.example.com")
    monkeypatch.setenv("ORKET_PROTOCOL_CLOCK_MODE", "artifact_replay")
    monkeypatch.setenv("ORKET_PROTOCOL_CLOCK_ARTIFACT_REF", "artifacts/clock/run-4.json")
    monkeypatch.setenv("ORKET_PROTOCOL_ENV_ALLOWLIST", "HOME,PATH")
    monkeypatch.setenv("ORKET_LOCAL_PROMPTING_MODE", "enforce")
    monkeypatch.setenv("ORKET_LOCAL_PROMPTING_ALLOW_FALLBACK", "true")
    monkeypatch.setenv("ORKET_LOCAL_PROMPTING_FALLBACK_PROFILE_ID", "openai_compat.qwen.openai_messages.v1")
    issue = IssueConfig(id="ARC-4", seat="architect", summary="Design architecture")
    context = await orch._build_turn_context(
        run_id="run-4", issue=issue,
        seat_name="architect",
        roles_to_load=["architect"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )
    assert context["protocol_governed_enabled"] is True
    assert context["max_response_bytes"] == 4096
    assert context["max_tool_calls"] == 3
    assert context["timezone"] == "America/Denver"
    assert context["locale"] == "en_US.UTF-8"
    assert context["network_mode"] == "allowlist"
    assert context["network_allowlist_values"] == ["api.example.com", "cache.example.com"]
    assert len(context["network_allowlist_hash"]) == 64
    assert context["clock_mode"] == "artifact_replay"
    assert context["clock_artifact_ref"] == "artifacts/clock/run-4.json"
    assert len(context["clock_artifact_hash"]) == 64
    assert context["env_allowlist_values"] == ["HOME", "PATH"]
    assert "PATH" in context["env_allowlist"]
    assert set(context["env_allowlist"].keys()).issubset({"HOME", "PATH"})
    assert len(context["env_allowlist_hash"]) == 64
    assert context["local_prompting_mode"] == "enforce"
    assert context["local_prompting_allow_fallback"] is True
    assert context["local_prompting_fallback_profile_id"] == "openai_compat.qwen.openai_messages.v1"
    assert context["prompt_budget_enabled"] is True
    assert context["prompt_budget_policy_path"] == str(DEFAULT_PROMPT_BUDGET_PATH)


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_protocol_determinism_invalid_network_mode_fails_fast(orchestrator, monkeypatch):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={})
    monkeypatch.setenv("ORKET_PROTOCOL_NETWORK_MODE", "internet")
    issue = IssueConfig(id="ARC-4B", seat="architect", summary="Design architecture")

    with pytest.raises(ValueError, match="E_NETWORK_MODE_INVALID"):
        await orch._build_turn_context(
            run_id="run-4b",
            issue=issue,
            seat_name="architect",
            roles_to_load=["architect"],
            turn_status=CardStatus.IN_PROGRESS,
            selected_model="dummy-model",
            resume_mode=False,
        )

@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_uses_active_run_policy_overrides(orchestrator):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={"allowed_tool_rings": ["core", "compatibility"]})
    orch.active_capabilities_allowed = ["workspace", "external"]
    orch.active_run_determinism_class = "external"
    orch.active_compatibility_mappings = {
        "openclaw.file_read": {
            "mapping_version": 1,
            "mapped_core_tools": ["workspace.read"],
            "schema_compatibility_range": ">=1.0.0 <2.0.0",
            "determinism_class": "workspace",
        }
    }
    issue = IssueConfig(id="ARC-4C", seat="architect", summary="Design architecture")

    context = await orch._build_turn_context(
        run_id="run-4c",
        issue=issue,
        seat_name="architect",
        roles_to_load=["architect"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    assert context["allowed_tool_rings"] == ["core", "compatibility"]
    assert context["allowed_capability_profiles"] == ["workspace", "external"]
    assert context["allowed_namespace_scopes"] == ["issue:ARC-4C"]
    assert context["capabilities_allowed"] == ["workspace", "external"]
    assert context["run_namespace_scope"] == "issue:ARC-4C"
    assert context["run_determinism_class"] == "external"
    assert context["run_determinism_policy"] == "external"
    assert "openclaw.file_read" in context["compatibility_mappings"]



@pytest.mark.unit
def test_resolve_runtime_modes_honor_user_settings_when_process_rules_unset(orchestrator, monkeypatch):
    """Layer: unit. Architecture evaluation consumes the explicit unlock snapshot."""
    orch, _cards, _loader = orchestrator
    orch.architecture_policy = ArchitecturePolicySnapshot(True)
    orch.org = SimpleNamespace(process_rules={})
    monkeypatch.setattr(
        "orket.application.services.orchestrator_support_services.load_user_settings",
        lambda: {
            "architecture_mode": "force_microservices",
            "frontend_framework_mode": "force_angular",
            "project_surface_profile": "api_vue",
        },
    )
    assert orchestrator_policy.select_architecture_mode(user_settings=orch.support_services.load_user_settings(), process_rules=orchestrator_policy.organization_process_rules(orch.org), environment=orch.decision_environment, architecture_policy=orch.architecture_policy) == "force_microservices"
    assert orchestrator_policy.select_frontend_framework_mode(user_settings=orch.support_services.load_user_settings(), process_rules=orchestrator_policy.organization_process_rules(orch.org)) == "force_angular"
    assert orchestrator_policy.select_project_surface_profile(user_settings=orch.support_services.load_user_settings(), process_rules=orchestrator_policy.organization_process_rules(orch.org)) == "api_vue"


@pytest.mark.unit
def test_resolve_small_project_builder_variant_from_user_settings(orchestrator, monkeypatch):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(process_rules={})
    monkeypatch.setattr(
        "orket.application.services.orchestrator_support_services.load_user_settings",
        lambda: {"small_project_builder_variant": "architect"},
    )
    assert orchestrator_policy.select_small_project_builder_variant(user_settings=orch.support_services.load_user_settings(), process_rules=orchestrator_policy.organization_process_rules(orch.org)) == "architect"


@pytest.mark.unit
def test_resolve_small_project_policy_maps_architect_to_lead_architect(orchestrator):
    orch, _cards, _loader = orchestrator
    epic = SimpleNamespace(issues=[SimpleNamespace(id="I1")])
    team = SimpleNamespace(
        seats={
            "lead_architect": SimpleNamespace(roles=["lead_architect"]),
            "reviewer": SimpleNamespace(roles=["code_reviewer"]),
        }
    )
    orch.org = SimpleNamespace(process_rules={"small_project_builder_variant": "architect"})

    policy = orch._resolve_small_project_team_policy(epic, team)

    assert policy["active"] is True
    assert policy["builder_role"] == "architect"
    assert policy["builder_seat"] == "lead_architect"


@pytest.mark.unit
def test_auto_inject_small_project_reviewer_from_process_rules(orchestrator):
    orch, _cards, _loader = orchestrator
    orch.org = SimpleNamespace(
        process_rules={
            "small_project_auto_inject_code_reviewer": True,
            "small_project_auto_inject_reviewer_seat_name": "reviewer_auto",
        }
    )
    team = TeamConfig(name="standard", seats={"coder": SeatConfig(name="Coder", roles=["coder"])})
    epic = SimpleNamespace(issues=[SimpleNamespace(id="I1")])

    assert orchestrator_team_policy.should_auto_inject_small_project_reviewer(orch.org) is True
    seat_name = orchestrator_team_policy.auto_inject_small_project_reviewer_seat(orch.org, team)
    policy = orch._resolve_small_project_team_policy(epic, team)

    assert seat_name == "reviewer_auto"
    assert "reviewer_auto" in team.seats
    assert "code_reviewer" in team.seats["reviewer_auto"].roles
    assert policy["reviewer_seat"] == "reviewer_auto"


@pytest.mark.contract
@pytest.mark.asyncio
# Layer: unit
async def test_execute_epic_requires_reviewer_for_small_project(orchestrator, tmp_path):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        issue = SimpleNamespace(id="I1", status=CardStatus.READY, seat="coder")
        epic = SimpleNamespace(name="No Reviewer Epic", issues=[issue], references=[])
        team = SimpleNamespace(seats={"coder": SimpleNamespace(roles=["coder"])})
        env = SimpleNamespace(temperature=0.1, timeout=30)
        cards.get_by_build.side_effect = [[issue]]
        cards.independent_ready.side_effect = [[issue]]
        (tmp_path / "user_settings.json").write_text('{"models": {}}', encoding="utf-8")

        with pytest.raises(ExecutionFailed, match="missing code_reviewer seat"):
            await orch.execute_epic(
                active_build="build-no-reviewer",
                run_id="run-no-reviewer",
                epic=epic,
                team=team,
                env=env,
            )


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_small_project_variant_overrides_builder_seat(orchestrator, monkeypatch):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        orch.org = SimpleNamespace(process_rules={"small_project_builder_variant": "architect"})
        issue = IssueConfig(id="I1", seat="coder", summary="Implement", status=CardStatus.READY)
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(parent_id=None, id="EPIC-1", name="Epic 1", issues=[issue])
        team = SimpleNamespace(
            seats={
                "architect": SimpleNamespace(roles=["architect"]),
                "coder": SimpleNamespace(roles=["coder"]),
                "code_reviewer": SimpleNamespace(roles=["code_reviewer"]),
            }
        )
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="architect", description="Role", tools=[]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
        )

        class _PromptStrategy:
            def select_model(self, inputs):
                assert inputs.role == "architect"
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClient:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["role"] = context["role"]
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "SYSTEM",
        )

        orch.memory = _Memory()
        orch.model_clients = _ModelClient()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["role"] == "architect"


@pytest.mark.unit
@pytest.mark.asyncio
# Layer: unit
async def test_execute_issue_turn_does_not_coerce_builder_seat_when_small_project_policy_inactive(
    orchestrator, monkeypatch
):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, loader = orchestrator
        issue = IssueConfig(id="I1", seat="product_owner", summary="Define exit criteria", status=CardStatus.READY)
        issue_data = SimpleNamespace(model_dump=lambda: issue.model_dump())
        epic = SimpleNamespace(
            parent_id=None,
            id="EPIC-1",
            name="Epic 1",
            issues=[issue, SimpleNamespace(id="I2"), SimpleNamespace(id="I3"), SimpleNamespace(id="I4")],
        )
        team = SimpleNamespace(
            seats={
                "product_owner": SimpleNamespace(roles=["product_owner"]),
                "coder": SimpleNamespace(roles=["coder"]),
                "code_reviewer": SimpleNamespace(roles=["code_reviewer"]),
            }
        )
        env = SimpleNamespace(temperature=0.1, timeout=30)

        loader.queue_assets(
            [
                SimpleNamespace(name="product_owner", description="Role", tools=[]),
                DialectConfig(model_family="generic", dsl_format="json", constraints=[], hallucination_guard="none"),
            ]
        )

        class _PromptStrategy:
            def select_model(self, inputs):
                assert inputs.role == "product_owner"
                return "dummy-model"

            def select_dialect(self, model):
                return "generic"

        class _Provider:
            async def clear_context(self):
                return None

        class _ModelClient:
            def create_provider(self, selected_model, env):
                return _Provider()

            def create_client(self, provider):
                return SimpleNamespace()

        class _Memory:
            async def search(self, _query):
                return []

            async def remember(self, content, metadata):
                return None

        captured = {}

        class _Executor:
            async def execute_turn(self, issue, role_config, client, toolbox, context, system_prompt=None):
                captured["builder_seat_choice"] = context["builder_seat_choice"]
                captured["reviewer_seat_choice"] = context["reviewer_seat_choice"]
                return TurnResult(
                    success=True,
                    turn=ExecutionTurn(timestamp=None, content="Turn handled; work awaits review.", role=context["role"], issue_id=context["issue_id"], note=""),
                )

        async def _noop(*args, **kwargs):
            return None

        monkeypatch.setattr(
            "orket.application.services.prompt_compiler.PromptCompiler.compile",
            lambda skill, dialect, **kwargs: "SYSTEM",
        )

        orch.memory = _Memory()
        orch.model_clients = _ModelClient()
        orch._save_checkpoint = _noop
        orch._trigger_sandbox = _noop

        await orch._execute_issue_turn(
            issue_data=issue_data,
            epic=epic,
            team=team,
            env=env,
            run_id="run-1",
            active_build="build-1",
            model_selection=prepared_model_selection(_PromptStrategy()),
            executor=_Executor(),
            toolbox=SimpleNamespace(),
        )

        assert captured["builder_seat_choice"] == "product_owner"
        assert captured["reviewer_seat_choice"] == "integrity_guard"


@pytest.mark.unit
@pytest.mark.asyncio
async def test_team_replan_schedules_card_when_requirements_request_replan(orchestrator):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        backlog = [
            SimpleNamespace(
                id="REQ-1",
                seat="requirements_analyst",
                params={"replan_requested": True},
                model_dump=lambda: {
                    "id": "REQ-1",
                    "seat": "requirements_analyst",
                    "params": {"replan_requested": False},
                    "status": CardStatus.READY,
                },
            )
        ]
        team = SimpleNamespace(
            seats={
                "architect": SimpleNamespace(roles=["architect"]),
                "code_reviewer": SimpleNamespace(roles=["code_reviewer"]),
            }
        )

        triggered = await orch.team_replan.maybe_schedule(backlog=backlog, run_id='run-abc1', active_build='build-1', team=team, request_transition=lambda **fields: orch._request_issue_transition(**fields), cards=lambda: orch.async_cards, select_team=lambda current_epic, current_team: orch._resolve_small_project_team_policy(current_epic, current_team), child_publication=lambda: getattr(orch, 'scheduler_control_plane', None), emit=lambda event, fields: log_event(event, fields, orch.workspace))

        assert triggered is True
        assert orch.team_replan._counts["run-abc1"] == 1
        saved_payloads = [call[0][0] for call in cards.save.calls]
        assert any(payload.get("id") == "REPLAN-RUN-AB-1" for payload in saved_payloads)


@pytest.mark.unit
@pytest.mark.asyncio
async def test_team_replan_limit_exceeded_raises_terminal_failure(orchestrator):
    with bind_logging(await prepare_logging(LoggingInputs(orchestrator[0].workspace))):
        orch, cards, _loader = orchestrator
        orch.team_replan._counts["run-limit"] = 3
        backlog = [
            SimpleNamespace(
                id="REQ-1",
                seat="requirements_analyst",
                params={"replan_requested": True},
                status=CardStatus.READY,
            )
        ]
        team = SimpleNamespace(
            seats={
                "architect": SimpleNamespace(roles=["architect"]),
                "code_reviewer": SimpleNamespace(roles=["code_reviewer"]),
            }
        )

        with pytest.raises(ExecutionFailed, match="TEAM_REPLAN_LIMIT_EXCEEDED"):
            await orch.team_replan.maybe_schedule(backlog=backlog, run_id='run-limit', active_build='build-1', team=team, request_transition=lambda **fields: orch._request_issue_transition(**fields), cards=lambda: orch.async_cards, select_team=lambda current_epic, current_team: orch._resolve_small_project_team_policy(current_epic, current_team), child_publication=lambda: getattr(orch, 'scheduler_control_plane', None), emit=lambda event, fields: log_event(event, fields, orch.workspace))
        assert cards.update_status.calls[-1][0][1] == CardStatus.BLOCKED


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_pending_gate_callback_creates_tool_approval_request(orchestrator):
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="coder", summary="Code Work")

    class _PendingRepo:
        def __init__(self):
            self.calls = []

        async def create_request(self, **kwargs):
            self.calls.append(kwargs)
            return "REQ-TOOL-42"

    class _LoopPolicy:
        def required_action_tools_for_seat(self, inputs):
            return ["write_file", "update_issue_status"]

        def required_statuses_for_seat(self, inputs):
            return ["code_review"]

        def gate_mode_for_seat(self, inputs):
            return "auto"

        def approval_required_tools_for_seat(self, inputs):
            return ["write_file"]

    orch.pending_gates = _PendingRepo()
    orch.loop_policy_node = _LoopPolicy()
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    request_id = await context["create_pending_gate_request"](
        destination=artifact_destination(TurnArtifactWriter(orch.workspace), session_id="run-1",
            issue_id=issue.id, role_name="coder", turn_index=1),
        tool_name="write_file",
        tool_args={"path": "out.txt", "content": "ok"},
    )

    assert request_id == "REQ-TOOL-42"
    assert len(orch.pending_gates.calls) == 1
    req = orch.pending_gates.calls[0]
    assert req["session_id"] == "run-1"
    assert req["issue_id"] == "I1"
    assert req["seat_name"] == "coder"
    assert req["gate_mode"] == "approval_required"
    assert req["request_type"] == "tool_approval"
    assert req["reason"] == "approval_required_tool:write_file"
    assert req["payload"]["tool"] == "write_file"
    assert req["payload"]["role"] == "coder"
    assert req["payload"]["turn_index"] == 1
    assert req["payload"]["control_plane_target_ref"] == "turn-tool-run:run-1:I1:coder:0001"
    reservation = await orch.control_plane_repository.get_latest_reservation_record(
        reservation_id=f"approval-reservation:{request_id}"
    )
    assert reservation is not None
    assert reservation.status is ReservationStatus.ACTIVE
    assert reservation.holder_ref == "turn-tool-run:run-1:I1:coder:0001"


@pytest.mark.unit
@pytest.mark.asyncio
async def test_build_turn_context_pending_gate_callback_creates_create_issue_tool_approval_request(orchestrator):
    """Layer: unit."""
    orch, _cards, _loader = orchestrator
    issue = IssueConfig(id="I1", seat="coder", summary="Code Work")

    class _PendingRepo:
        def __init__(self):
            self.calls = []

        async def create_request(self, **kwargs):
            self.calls.append(kwargs)
            return "REQ-TOOL-43"

    class _LoopPolicy:
        def required_action_tools_for_seat(self, inputs):
            return ["create_issue", "update_issue_status"]

        def required_statuses_for_seat(self, inputs):
            return ["code_review"]

        def gate_mode_for_seat(self, inputs):
            return "auto"

        def approval_required_tools_for_seat(self, inputs):
            return ["create_issue"]

    orch.pending_gates = _PendingRepo()
    orch.loop_policy_node = _LoopPolicy()
    context = await orch._build_turn_context(
        run_id="run-1",
        issue=issue,
        seat_name="coder",
        roles_to_load=["coder"],
        turn_status=CardStatus.IN_PROGRESS,
        selected_model="dummy-model",
        resume_mode=False,
    )

    request_id = await context["create_pending_gate_request"](
        destination=artifact_destination(TurnArtifactWriter(orch.workspace), session_id="run-1",
            issue_id=issue.id, role_name="coder", turn_index=1),
        tool_name="create_issue",
        tool_args={"seat": "reviewer", "summary": "Follow-up task"},
    )

    assert request_id == "REQ-TOOL-43"
    assert len(orch.pending_gates.calls) == 1
    req = orch.pending_gates.calls[0]
    assert req["session_id"] == "run-1"
    assert req["issue_id"] == "I1"
    assert req["seat_name"] == "coder"
    assert req["gate_mode"] == "approval_required"
    assert req["request_type"] == "tool_approval"
    assert req["reason"] == "approval_required_tool:create_issue"
    assert req["payload"]["tool"] == "create_issue"
    assert req["payload"]["role"] == "coder"
    assert req["payload"]["turn_index"] == 1
    assert req["payload"]["control_plane_target_ref"] == "turn-tool-run:run-1:I1:coder:0001"
    reservation = await orch.control_plane_repository.get_latest_reservation_record(
        reservation_id=f"approval-reservation:{request_id}"
    )
    assert reservation is not None
    assert reservation.status is ReservationStatus.ACTIVE
    assert reservation.holder_ref == "turn-tool-run:run-1:I1:coder:0001"

@pytest.mark.unit
def test_validate_guard_rejection_payload_default_logic(orchestrator):
    orch, _cards, _loader = orchestrator

    invalid = orch._validate_guard_rejection_payload(
        SimpleNamespace(rationale="", violations=[], remediation_actions=["Do something"])
    )
    assert invalid == {"valid": False, "reason": "missing_rationale"}

    invalid_actions = orch._validate_guard_rejection_payload(
        SimpleNamespace(rationale="Needs remediation.", violations=[], remediation_actions=[])
    )
    assert invalid_actions == {"valid": False, "reason": "missing_remediation_actions"}

    valid = orch._validate_guard_rejection_payload(
        SimpleNamespace(rationale="Needs remediation.", violations=[], remediation_actions=["Fix issue"])
    )
    assert valid == {"valid": True, "reason": None}


@pytest.mark.unit
@pytest.mark.asyncio
async def test_create_pending_gate_request_uses_policy_gate_mode(orchestrator):
    orch, _cards, _loader = orchestrator

    class _PendingRepo:
        def __init__(self):
            self.calls = []
        async def create_request(self, **kwargs):
            self.calls.append(kwargs)
            return "REQ-1234"
    class _LoopPolicy:
        def gate_mode_for_seat(self, inputs):
            return "review_required" if inputs.seat_name == "integrity_guard" else "auto"
    orch.pending_gates = _PendingRepo()
    orch.loop_policy_node = _LoopPolicy()
    request_id = await orch._create_pending_gate_request(
        run_id="run-1",
        issue_id="ISSUE-1",
        seat_name="integrity_guard",
        reason="missing_rationale",
        payload={"rationale": "", "remediation_actions": []},
        issue=IssueConfig(id="ISSUE-1", seat="integrity_guard", summary="Guard Review"),
        turn_status=CardStatus.AWAITING_GUARD_REVIEW,
    )
    assert request_id == "REQ-1234"
    assert len(orch.pending_gates.calls) == 1
    call = orch.pending_gates.calls[0]
    assert call["session_id"] == "run-1"
    assert call["gate_mode"] == "review_required"
    assert call["request_type"] == "guard_rejection_payload"
    reservation = await orch.control_plane_repository.get_latest_reservation_record(
        reservation_id=f"approval-reservation:{request_id}"
    )
    assert reservation is not None
    assert reservation.status is ReservationStatus.ACTIVE
    assert reservation.holder_ref == f"approval-request:{request_id}"
