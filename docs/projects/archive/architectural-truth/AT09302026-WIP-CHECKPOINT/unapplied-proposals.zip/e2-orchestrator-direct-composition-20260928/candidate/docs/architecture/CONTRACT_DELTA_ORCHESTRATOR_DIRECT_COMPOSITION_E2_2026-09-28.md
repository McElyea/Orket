# Orchestrator direct service composition

Date: 2026-09-28
Status: Proposed E2 cut; unchanged-source opening and closing pending
Canonical behavior authority: `docs/specs/RUNTIME_ARCHITECTURE_POLICY_INPUTS.md`

## Responsibility and delta

The existing `Orchestrator` facade directly composes canonical dependency, guard,
turn-executor and failure services in seven methods that formerly forwarded
through `orchestrator_ops`. The seven redundant ops implementations are removed;
there is one implementation at the existing instance seam and no new module,
coordinator, proxy, copied owner or compatibility export. Ops retains epic/turn
phase composition, context assembly, checkpointing, sandbox and gate orchestration.
The canonical services retain decision and effect authority.

Dependency reads select the current `self.async_cards` when the instance method
runs. Guard validation selects the current loop node; extraction calls the same
canonical guard-review function. Dispatch awaits the supplied executor's current
execute_turn method with the same argument order and system_prompt keyword.
Failure composition evaluates workspace, report clock, cards, evaluator and bound
transition callback in the same pre-await order. Its two message-policy callbacks
continue resolving current instance methods when the handler later invokes them.
All copied method bodies and call arguments are AST-identical to the removed ops
implementations; only `self: Any` is removed from those method signatures.

The instance method names and accepted argument shapes remain. Their signatures
now express the former ops signatures directly, replacing *args/**kwargs forwarders.
Private signature introspection and the frame/qualified-name of an invalid call's
TypeError can differ. Public Orchestrator export, constructor and all other methods
remain unchanged. Removed private ops functions and their now-unused imported
symbols are not retained as compatibility aliases.

## Consumer and import timing

`tests/helpers/card_dispatch.py` moves only its dependency-function monkeypatch to
the facade's actual import owner; its separate dispatch-snapshot patch stays in ops.
One dependency integration caller invokes the existing facade method unbound with
the same minimal repository-bearing fixture, replacing its direct ops call. All
existing assertions, real card/evidence setup and application-policy inputs remain.
Repository source/docs search found no other direct calls or patches of these seven
private ops functions, nor a documented external import contract for them.

Four canonical effect/policy imports move to the facade: dependency building,
guard payload extraction, guard validation and the failure-handler class. They
remain direct captured imports, not late canonical-module lookups. Patching the
canonical source after import still does not rebind a consumer; patch the actual
facade-owned alias. Instance replacement continues to work at the existing phase.
ToolBox/TurnExecutor and execution/guard/schema type names support the concrete
signatures and refer to their canonical declarations. Some canonical modules can
initialize earlier in the facade import sequence; import order is not declared
AST-identical. Static inspection found no added native operation, registration,
source fallback or back-edge. Cold import and real-flow acceptance remain required.

## Size, proof and limits

Ops reduces 478 to 396 lines; facade grows 361 to 389. Combined product size reduces
839 to 785 lines and seven redundant function definitions disappear. No new
function exceeds 70 lines and no class public method is added. The existing
73-line facade constructor is unchanged and remains E2 debt; this cut does not
claim all E2 function-size obligations are complete.

The proposed one additional integration control publishes a real failure report,
holds its acknowledgement, then replaces facade fields and message callbacks. It
requires the captured clock/evaluator/transition owner, current late message
callbacks, and actual card blocking/history. It uses the real report/card owners
and a delegating evaluator. Existing dependency acceptance, guard payload, actual
turn, retry/control-plane, phase, provider and public pipeline guards remain the
main parity selection. No tests merely mirror an annotation or moved source line.

Static AST/consumer/import/size and Ruff checks do not establish runtime parity.
Root must observe the new control against unchanged product, apply the proposed
product/consumer changes, and repeat the named selection. Native cold import,
canonical typing/dependency gates and installed/Linux/provider acceptance are
separate. Keep current 0.6.114; no version bump or capability change is proposed.
Rollback only this direct-composition cut if source parity or selection timing
changes; preserve the already accepted epic and turn extractions and their proofs.
