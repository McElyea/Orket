"""Integration: existing facade captures failure owners and resolves later instance callbacks."""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import pytest

from orket.application.services.failure_report_service import FailureReportService
from orket.core.contracts.logging_inputs import LoggingInputs
from orket.decision_nodes.builtins import DefaultEvaluatorNode
from orket.exceptions import GovernanceViolation
from orket.logging import bind_logging, prepare_logging
from orket.schema import CardStatus, IssueConfig
from tests.integration.test_dispatch_input_admission import _dispatch_context
from tests.integration.test_epic_execution_phase_ownership import _settle, _wait_for_entry

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]


def _unexpected(*_args, **_kwargs):
    raise AssertionError('replacement owner must not replace an already-composed failure phase')


async def _fail(orch, issue, result):
    with bind_logging(await prepare_logging(LoggingInputs(orch.workspace))):
        await orch._handle_failure(issue, result, 'failure-phase', ['coder'], turn_index=1)


async def test_facade_failure_composition_retains_owners_and_uses_late_message_callbacks(tmp_path, monkeypatch):
    repo, record, _team, orch = await _dispatch_context(tmp_path, SimpleNamespace())
    issue = IssueConfig.model_validate(record.model_dump())
    result = SimpleNamespace(error='selected failure', violations=['selected violation'])
    events, entered, release = [], asyncio.Event(), asyncio.Event()
    timestamp = '2026-09-28T12:00:00+00:00'
    publish = FailureReportService.publish

    class Observer(DefaultEvaluatorNode):
        def evaluate_failure(self, inputs):
            events.append(('selected_evaluator', inputs.error))
            return super().evaluate_failure(inputs)

        def governance_violation_message(self, error):
            return f'iDesign Violation: {error}'

    async def held_report(owner, report):
        path = await publish(owner, report)
        entered.set()
        await release.wait()
        return path

    def selected_clock():
        events.append(('selected_clock', timestamp))
        return timestamp

    def late_enabled(selected_issue):
        events.append(('late_enabled', selected_issue.id))
        return False

    normalize = orch._normalize_governance_violation_message

    def late_normalize(message):
        events.append(('late_normalize', message))
        return normalize(message)

    orch.evaluator_node, orch.failure_report_clock = Observer(), selected_clock
    monkeypatch.setattr(FailureReportService, 'publish', held_report)
    active = asyncio.create_task(_fail(orch, issue, result))
    try:
        await _wait_for_entry(active, entered)
        report = json.loads(await asyncio.to_thread(
            (orch.workspace / 'agent_output/policy_violation_card.json').read_text, encoding='utf-8'))
        assert report['detail'] == result.error and report['timestamp'] == timestamp
        assert (await repo.get_by_id(issue.id)).status == CardStatus.READY
        orch.evaluator_node = SimpleNamespace(evaluate_failure=_unexpected)
        orch.failure_report_clock = _unexpected
        orch._request_issue_transition = _unexpected
        orch._is_issue_idesign_enabled = late_enabled
        orch._normalize_governance_violation_message = late_normalize
        release.set()
        with pytest.raises(GovernanceViolation, match='^Governance Violation: selected failure$'):
            await asyncio.wait_for(active, 10)
        assert events == [('selected_clock', timestamp), ('selected_evaluator', 'selected failure'),
            ('late_enabled', issue.id), ('late_normalize', 'iDesign Violation: selected failure')]
        saved = await repo.get_by_id(issue.id)
        assert saved.status == CardStatus.BLOCKED and saved.retry_count == 0
        assert issue.status == CardStatus.BLOCKED
        history = await repo.get_card_history(issue.id)
        assert len(history) == 1 and "reason='governance_violation'" in history[0]
    finally:
        await _settle(active, release)
