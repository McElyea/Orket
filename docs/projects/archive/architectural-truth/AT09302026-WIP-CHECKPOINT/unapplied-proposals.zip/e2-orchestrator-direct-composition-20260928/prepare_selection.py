﻿from pathlib import Path
base=Path('.tmp/e2-orchestrator-turn-execution-20260928/SELECTORS.txt').read_text(encoding='utf-8-sig').splitlines()
extra=['tests/integration/test_orchestrator_failure_phase_composition.py',
       'tests/integration/test_evaluator_input_admission.py','tests/contracts/test_loop_input_values.py',
       'tests/contracts/test_turn_prompt_truth.py','tests/application/test_orchestrator_context_window.py',
       'tests/integration/test_turn_context_observation_ownership.py']
selected=list(dict.fromkeys(extra+base))
for path in selected:
    if path not in extra[:1]:
        assert Path(path.split('::')[0]).is_file(),path
Path('.tmp/e2-orchestrator-direct-composition-20260928/SELECTORS.txt').write_text('\n'.join(selected)+'\n',newline='\n')
print(len(selected),'explicit selectors; no collection')
