﻿"""Root-scheduled cold import identity probe; this file is not run during preparation."""
from __future__ import annotations

import argparse
import hashlib
import importlib
import sys
from pathlib import Path

from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

ALIASES = {
    'build_card_dependency_context': 'orket.application.services.card_dependency_service',
    'guard_review_for_turn': 'orket.application.services.guard_review_payload',
    'validate_guard_review': 'orket.application.services.loop_decision_service',
    'OrchestratorFailureHandler': 'orket.application.services.orchestrator_failure_handler',
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['before', 'after'], required=True)
    parser.add_argument('--order', choices=['facade-first', 'canonical-first'], required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    modules = {}
    if args.order == 'canonical-first':
        modules = {name: importlib.import_module(path) for name, path in ALIASES.items()}
    facade = importlib.import_module('orket.application.workflows.orchestrator')
    ops = importlib.import_module('orket.application.workflows.orchestrator_ops')
    if not modules:
        modules = {name: importlib.import_module(path) for name, path in ALIASES.items()}
    owner = ops if args.phase == 'before' else facade
    observations = []
    for name, source in modules.items():
        original = getattr(source, name)
        assert getattr(owner, name) is original
        marker = object()
        try:
            setattr(source, name, marker)
            assert getattr(owner, name) is original
        finally:
            setattr(source, name, original)
        try:
            setattr(owner, name, marker)
            assert getattr(source, name) is original
        finally:
            setattr(owner, name, original)
        observations.append({'name': name, 'canonical_module': source.__name__, 'consumer': owner.__name__,
            'identity': True, 'captured_source_binding': True, 'local_patch_independent': True})
    assert facade.__all__ == ['Orchestrator']
    write_payload_with_diff_ledger(args.out, {'proof_kind': 'native cold import/identity; not live behavior',
        'phase': args.phase, 'order': args.order, 'interpreter': sys.executable, 'prefix': sys.prefix,
        'observations': observations, 'source': {module.__name__: {
            'path': str(Path(module.__file__).resolve()),
            'sha256': hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()}
            for module in [facade, ops, *modules.values()]}})


if __name__ == '__main__':
    main()
