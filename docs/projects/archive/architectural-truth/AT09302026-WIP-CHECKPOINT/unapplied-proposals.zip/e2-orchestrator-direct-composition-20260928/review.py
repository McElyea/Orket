﻿"""Static parity, import inventory, size and immutable binding for direct composition."""
from __future__ import annotations

import ast
import copy
import difflib
import hashlib
import sys
from pathlib import Path

ROOT=Path.cwd()
HERE=ROOT/'.tmp/e2-orchestrator-direct-composition-20260928'
sys.path.insert(0,str(ROOT))
from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

OPS='orket/application/workflows/orchestrator_ops.py'
FACADE='orket/application/workflows/orchestrator.py'
PRODUCT=[OPS,FACADE]
CONSUMERS=['tests/helpers/card_dispatch.py','tests/integration/test_card_dependency_acceptance.py']
OPENING=['tests/integration/test_orchestrator_failure_phase_composition.py']
DOC='docs/architecture/CONTRACT_DELTA_ORCHESTRATOR_DIRECT_COMPOSITION_E2_2026-09-28.md'
NAMES={'_validate_guard_rejection_payload','_build_dependency_context','_extract_guard_review_payload',
       '_dispatch_turn','_handle_failure','_is_issue_idesign_enabled','_normalize_governance_violation_message'}
SUPPORT=['orket/application/services/card_dependency_service.py','orket/application/services/guard_review_payload.py',
    'orket/application/services/loop_decision_service.py','orket/application/services/orchestrator_failure_handler.py',
    'orket/application/services/failure_report_service.py','orket/application/services/orchestrator_issue_transitions.py',
    'orket/application/workflows/turn_executor.py','orket/application/services/toolbox.py',
    'orket/application/workflows/orchestrator_turn_workflow.py','orket/application/workflows/orchestrator_epic_workflow.py',
    'orket/decision_nodes/builtins.py','tests/integration/test_dispatch_input_admission.py',
    'tests/integration/test_epic_execution_phase_ownership.py','tests/integration/test_card_retry_recovery.py',
    'tests/integration/test_orchestrator_turn_phase_ownership.py','tests/integration/test_evaluator_input_admission.py',
    'tests/application/test_orchestrator_epic.py','docs/specs/RUNTIME_ARCHITECTURE_POLICY_INPUTS.md','pyproject.toml']


def parse(path):
    return ast.parse(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def functions(module):
    return {n.name:n for n in module.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}


def methods(module):
    return functions(next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='Orchestrator'))


def imports(module):
    return [(n.module,a.name,a.asname) for n in module.body if isinstance(n,ast.ImportFrom) for a in n.names]


def statements(nodes):
    return [ast.dump(n) for n in nodes]


old_ops,new_ops=[parse(HERE/t/OPS) for t in ('baseline','candidate')]
old_facade,new_facade=[parse(HERE/t/FACADE) for t in ('baseline','candidate')]
old_functions,new_functions=functions(old_ops),functions(new_ops)
assert set(old_functions)-set(new_functions)==NAMES and not(set(new_functions)-set(old_functions))
for name in new_functions:
    assert ast.dump(new_functions[name])==ast.dump(old_functions[name]),name
before,after=methods(old_facade),methods(new_facade)
assert before.keys()==after.keys()
for name in before:
    if name not in NAMES:
        assert ast.dump(before[name])==ast.dump(after[name]),name
        continue
    previous,current=copy.deepcopy(old_functions[name]),copy.deepcopy(after[name])
    previous.args.args[0].annotation=None
    assert ast.dump(previous)==ast.dump(current),name
old_other=[n for n in old_facade.body if not isinstance(n,(ast.Import,ast.ImportFrom,ast.ClassDef))]
new_other=[n for n in new_facade.body if not isinstance(n,(ast.Import,ast.ImportFrom,ast.ClassDef))]
assert statements(old_other)==statements(new_other)
old_defs=[n for t in [old_ops,old_facade] for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
new_defs=[n for t in [new_ops,new_facade] for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
assert len(old_defs)-len(new_defs)==7
any_count=lambda trees:sum(isinstance(n,ast.Name) and n.id=='Any' for t in trees for n in ast.walk(t))
assert any_count([new_ops,new_facade])<any_count([old_ops,old_facade])
for rel in CONSUMERS:
    before,after=[parse(HERE/t/rel) for t in ('baseline','candidate')]
    assert [ast.dump(n) for n in ast.walk(before) if isinstance(n,ast.Assert)] == [ast.dump(n) for n in ast.walk(after) if isinstance(n,ast.Assert)]
    restored=copy.deepcopy(after)
    if rel.endswith('card_dispatch.py'):
        imported=next(n for n in restored.body if isinstance(n,ast.ImportFrom) and n.module=='orket.application.workflows')
        imported.names=[a for a in imported.names if a.name!='orchestrator']
        call=functions(restored)['install_dispatch_snapshot_stub'].body[-1].value
        assert call.args[0].id=='orchestrator'
        call.args[0].id='orchestrator_ops'
    else:
        old_import=next(n for n in before.body if isinstance(n,ast.ImportFrom) and n.module=='orket.application.workflows')
        index=before.body.index(old_import)
        restored.body.insert(index,old_import)
        calls=[n for n in ast.walk(restored) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
            and n.func.attr=='_build_dependency_context']
        assert len(calls)==1 and calls[0].func.value.id=='Orchestrator'
        calls[0].func.value.id='orchestrator_ops'
    assert ast.dump(restored)==ast.dump(before),rel
sizes={}
for tree,paths in [('candidate',PRODUCT+CONSUMERS),('opening',OPENING)]:
    for rel in paths:
        module=parse(HERE/tree/rel)
        lines=len((HERE/tree/rel).read_text(encoding='utf-8-sig').splitlines())
        spans=[(n.name,n.end_lineno-n.lineno+1) for n in ast.walk(module) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
        assert lines<=400,rel
        oversized=[n for n,length in spans if length>70]
        assert oversized==(['__init__'] if rel==FACADE else []),(rel,oversized)
        sizes[rel]={'lines':lines,'largest_function':max(length for _,length in spans)}
        if tree=='candidate':
            assert (HERE/'baseline'/rel).read_bytes()==(ROOT/rel).read_bytes(),rel
        else:
            assert not (ROOT/rel).exists(),rel
candidate=HERE/'candidate'/DOC
candidate.parent.mkdir(parents=True,exist_ok=True)
candidate.write_text((HERE/'DELTA.md').read_text(encoding='utf-8-sig'),newline='\n')
assert not (ROOT/DOC).exists()
for paths,name,tree in [(PRODUCT,'product.patch','candidate'),(CONSUMERS,'consumers.patch','candidate'),
    (OPENING,'opening.patch','opening'),([DOC],'authority.patch','candidate')]:
    patch=[]
    for rel in paths:
        base=HERE/'baseline'/rel
        old=base.read_text(encoding='utf-8-sig') if base.exists() else ''
        new=(HERE/tree/rel).read_text(encoding='utf-8-sig')
        patch.append(f'diff --git a/{rel} b/{rel}\n')
        if not base.exists():
            patch.append('new file mode 100644\n')
        patch.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
            fromfile=f'a/{rel}' if base.exists() else '/dev/null',tofile=f'b/{rel}'))
    (HERE/name).write_text(''.join(patch),newline='\n')
for rel in SUPPORT:
    target=HERE/'support'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes()==(ROOT/rel).read_bytes(),rel
    else:
        target.write_bytes((ROOT/rel).read_bytes())
write_payload_with_diff_ledger(HERE/'receipt.json',{'proof':'scratch static only; no imports/runtime/collection/Mypy',
    'baseline':{r:digest(HERE/'baseline'/r) for r in PRODUCT+CONSUMERS},
    'candidate':{r:digest(HERE/'candidate'/r) for r in PRODUCT+CONSUMERS+[DOC]},
    'opening':{r:digest(HERE/'opening'/r) for r in OPENING},
    'support':{r:digest(HERE/'support'/r) for r in SUPPORT},
    'patches':{r:digest(HERE/r) for r in ['product.patch','consumers.patch','opening.patch','authority.patch']},
    'cold_probe_sha256':digest(HERE/'cold_import_probe.py'), 'sizes':sizes,
    'function_definitions_before':len(old_defs),'function_definitions_after':len(new_defs),
    'Any_name_references_before':any_count([old_ops,old_facade]),
    'Any_name_references_after':any_count([new_ops,new_facade]),
    'moved_aliases':{r:[row for row in imports(new) if row not in imports(old)]
        for r,old,new in [(OPS,old_ops,new_ops),(FACADE,old_facade,new_facade)]},
    'removed_aliases':{r:[row for row in imports(old) if row not in imports(new)]
        for r,old,new in [(OPS,old_ops,new_ops),(FACADE,old_facade,new_facade)]},
    'unchanged_debt':'facade constructor remains73lines; not widened',
})
print('AST/consumer/size review passed',sizes)
print('function totals',len(old_defs),len(new_defs),'Any references',any_count([old_ops,old_facade]),any_count([new_ops,new_facade]))
print('patches',{r:digest(HERE/r) for r in ['product.patch','consumers.patch','opening.patch','authority.patch']})
print('receipt',digest(HERE/'receipt.json'))
