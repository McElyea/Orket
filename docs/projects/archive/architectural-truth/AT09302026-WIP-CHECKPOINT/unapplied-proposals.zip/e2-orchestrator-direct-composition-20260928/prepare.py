﻿"""Eliminate redundant ops forwarding into existing Orchestrator composition."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path.cwd()
HERE = ROOT / '.tmp/e2-orchestrator-direct-composition-20260928'
sys.path.insert(0, str(ROOT / '.tmp/e2-orchestrator-review-20260928'))
import candidate_tools as c

OPS = 'orket/application/workflows/orchestrator_ops.py'
FACADE = 'orket/application/workflows/orchestrator.py'
CONSUMERS = ['tests/helpers/card_dispatch.py', 'tests/integration/test_card_dependency_acceptance.py']
NAMES = ('_validate_guard_rejection_payload', '_build_dependency_context', '_extract_guard_review_payload',
         '_dispatch_turn', '_handle_failure', '_is_issue_idesign_enabled', '_normalize_governance_violation_message')
for rel in [OPS, FACADE, *CONSUMERS]:
    baseline = HERE / 'baseline' / rel
    baseline.parent.mkdir(parents=True, exist_ok=True)
    if baseline.exists():
        assert baseline.read_bytes() == (ROOT / rel).read_bytes(), rel
    else:
        baseline.write_bytes((ROOT / rel).read_bytes())
source = (HERE / 'baseline' / OPS).read_text()
source = c.remove_definitions(source, NAMES)
for statement in [
    'from orket.application.services.guard_review_payload import guard_review_for_turn\n',
    'from orket.application.services.orchestrator_failure_handler import OrchestratorFailureHandler\n',
    'from orket.core.domain.execution import ExecutionTurn\n',
    'from orket.core.domain.guard_review import GuardReviewPayload\n',
    '    RoleConfig,\n',
]:
    assert statement in source
    source = source.replace(statement, '')
source = source.replace('''from orket.application.services.card_dependency_service import (
    build_card_dependency_context,
    read_card_dispatch_snapshot,
)
''', 'from orket.application.services.card_dependency_service import read_card_dispatch_snapshot\n')
source = source.replace('''from orket.application.services.loop_decision_service import (
    capture_seat_policy_input,
    validate_guard_review,
)
''', 'from orket.application.services.loop_decision_service import capture_seat_policy_input\n')
source = source.lstrip('\n')
candidate = HERE / 'candidate' / OPS
candidate.parent.mkdir(parents=True, exist_ok=True)
candidate.write_text(source, newline='\n')

methods = {
'_validate_guard_rejection_payload': '''def _validate_guard_rejection_payload(self, payload: GuardReviewPayload) -> dict[str, Any]:
        return dict(validate_guard_review(self.loop_policy_node, payload))''',
'_build_dependency_context': '''async def _build_dependency_context(self, issue: IssueConfig) -> dict[str, Any]:
        return await build_card_dependency_context(cards=self.async_cards, issue=issue)''',
'_extract_guard_review_payload': '''def _extract_guard_review_payload(self, turn: ExecutionTurn) -> GuardReviewPayload:
        return guard_review_for_turn(turn)''',
'_dispatch_turn': '''async def _dispatch_turn(
        self, executor: TurnExecutor, issue: IssueConfig, role_config: RoleConfig, client: Any,
        toolbox: ToolBox, context: dict[str, Any], system_prompt: str,
    ) -> Any:
        return await executor.execute_turn(issue, role_config, client, toolbox, context, system_prompt=system_prompt)''',
'_handle_failure': '''async def _handle_failure(
        self, issue: IssueConfig, result: Any, run_id: str, roles: list[str], *, turn_index: int | None = None,
    ) -> None:
        handler = OrchestratorFailureHandler(
            workspace_root=self.workspace,
            report_timestamp=self.failure_report_clock(),
            async_cards=self.async_cards,
            evaluator_node=self.evaluator_node,
            request_issue_transition=self._request_issue_transition,
            is_issue_idesign_enabled=lambda current_issue: self._is_issue_idesign_enabled(current_issue),
            normalize_governance_violation_message=lambda message: self._normalize_governance_violation_message(message),
        )
        await handler.handle(issue=issue, result=result, run_id=run_id, roles=roles, turn_index=turn_index)''',
'_is_issue_idesign_enabled': '''def _is_issue_idesign_enabled(self, issue: IssueConfig) -> bool:
        params = getattr(issue, "params", None)
        if not isinstance(params, dict):
            return False
        return bool(params.get("idesign_enabled", False))''',
'_normalize_governance_violation_message': '''def _normalize_governance_violation_message(self, message: str | None) -> str:
        normalized = str(message or "")
        normalized = normalized.replace("iDesign Violation:", "Governance Violation:")
        normalized = normalized.replace("iDesign AST Violation", "Governance AST Violation")
        return normalized''',
}
source = (HERE / 'baseline' / FACADE).read_text()
owner = next(n for n in ast.parse(source).body if isinstance(n, ast.ClassDef) and n.name == 'Orchestrator')
source = c.replace_nodes(source, [(n, methods[n.name]) for n in owner.body if getattr(n, 'name', None) in methods])
for before, after in [
    ('from orket.application.services.card_completion_service import CardCompletionService\n',
     'from orket.application.services.card_completion_service import CardCompletionService\nfrom orket.application.services.card_dependency_service import build_card_dependency_context\n'),
    ('from orket.application.services.model_client_factory import ModelClientFactory\n',
     'from orket.application.services.guard_review_payload import guard_review_for_turn\nfrom orket.application.services.loop_decision_service import validate_guard_review\nfrom orket.application.services.model_client_factory import ModelClientFactory\nfrom orket.application.services.orchestrator_failure_handler import OrchestratorFailureHandler\n'),
    ('from orket.core.contracts.card_completion_commit',
     'from orket.application.services.toolbox import ToolBox\nfrom orket.application.workflows.turn_executor import TurnExecutor\nfrom orket.core.contracts.card_completion_commit'),
    ('from orket.logging import log_event\n',
     'from orket.core.domain.execution import ExecutionTurn\nfrom orket.core.domain.guard_review import GuardReviewPayload\nfrom orket.logging import log_event\n'),
    ('from orket.schema import CardStatus, EnvironmentConfig, EpicConfig, IssueConfig, TeamConfig',
     'from orket.schema import CardStatus, EnvironmentConfig, EpicConfig, IssueConfig, RoleConfig, TeamConfig'),
]:
    assert before in source
    source = source.replace(before, after)
candidate = HERE / 'candidate' / FACADE
candidate.write_text(source, newline='\n')

for rel in CONSUMERS:
    source = (HERE / 'baseline' / rel).read_text()
    if rel.endswith('card_dispatch.py'):
        source = source.replace('from orket.application.workflows import orchestrator_ops',
            'from orket.application.workflows import orchestrator, orchestrator_ops')
        source = source.replace('monkeypatch.setattr(orchestrator_ops, "build_card_dependency_context", dependency_context)',
            'monkeypatch.setattr(orchestrator, "build_card_dependency_context", dependency_context)')
    else:
        source = source.replace('from orket.application.workflows import orchestrator_ops\n', '')
        source = source.replace('orchestrator_ops._build_dependency_context(SimpleNamespace(async_cards=repo), issue)',
            'Orchestrator._build_dependency_context(SimpleNamespace(async_cards=repo), issue)')
    candidate = HERE / 'candidate' / rel
    candidate.parent.mkdir(parents=True, exist_ok=True)
    candidate.write_text(source, newline='\n')
for rel in [OPS, FACADE, *CONSUMERS]:
    path = HERE / 'candidate' / rel
    tree = ast.parse(path.read_text())
    spans = [(n.name, n.end_lineno - n.lineno + 1) for n in ast.walk(tree)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    print(rel, len(path.read_text().splitlines()), sorted(spans, key=lambda item: item[1], reverse=True)[:3])
