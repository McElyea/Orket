﻿from pathlib import Path
p=Path('.tmp/e2-orchestrator-direct-composition-20260928/opening/tests/integration/test_orchestrator_failure_phase_composition.py')
s=p.read_text(encoding='utf-8-sig').replace("        assert await repo.get_card_history(issue.id) == []", "        history = await repo.get_card_history(issue.id)\n        assert len(history) == 1 and \"reason='governance_violation'\" in history[0]")
p.write_text(s,newline='\n')
