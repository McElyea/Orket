"""Supplied iterator and native finalizer controls preserve the actual public provider port."""
from __future__ import annotations

import asyncio

from orket.core.contracts.interaction_stream import StreamEventType
from orket.streaming.model_provider import ModelStreamProvider, ProviderEvent, ProviderEventType
from orket.workloads import model_stream_v1 as workload


def install_context_observer(context, state):
    original, emit = context.await_cancel, context.emit_event

    async def observed():
        state["watcher"] = asyncio.current_task()
        try:
            await original()
        finally:
            if state["case"].startswith("watch"):
                state["watch_calls"] += 1
                state["watch_entered"].set()
                await state["watch_release"].wait()
                await asyncio.to_thread((state["root"] / "cleanup-effect.bin").write_bytes, b"watcher cleanup completed")
                state["watch_finished"].set()
                if state["failure"] is not None:
                    raise state["failure"]

    context.await_cancel = observed

    async def emitted(kind, payload):
        result = await emit(kind, payload)
        if kind == StreamEventType.TOKEN_DELTA:
            state["first_token"].set()
        return result

    context.emit_event = emitted


class BorrowedIterator:
    def __init__(self, state):
        self.state = state
        self.index = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        self.state["consumer"] = asyncio.current_task()
        self.index += 1
        if self.index > 2:
            raise StopAsyncIteration
        event_type = ProviderEventType.SELECTED if self.index == 1 else ProviderEventType.STOPPED
        return ProviderEvent(provider_turn_id="supplied-borrowed", event_type=event_type,
            payload={"model_id": "borrowed", "stop_reason": "completed"})

    async def aclose(self):
        self.state["borrowed_close_called"] = True
        raise AssertionError("The arbitrary AsyncIterator port did not transfer aclose ownership")


class SuppliedProvider(ModelStreamProvider):
    def __init__(self, state):
        self.state = state

    def start_turn(self, request):
        self.state["consumer"] = asyncio.current_task()
        iterator = BorrowedIterator(self.state) if self.state["case"] == "borrowed" else self._generate()
        self.state["iterator"] = iterator
        return iterator

    async def _generate(self):
        try:
            yield ProviderEvent(provider_turn_id="supplied-generator", event_type=ProviderEventType.SELECTED,
                                payload={"model_id": "controlled"})
            yield ProviderEvent(provider_turn_id="supplied-generator", event_type=ProviderEventType.STOPPED,
                                payload={"stop_reason": "completed"})
        finally:
            self.state["close_entered"].set()
            await self.state["close_release"].wait()
            await asyncio.to_thread((self.state["root"] / "cleanup-effect.bin").write_bytes, b"generator cleanup completed")
            self.state["close_finished"].set()
            if self.state["failure"] is not None:
                raise self.state["failure"]

    async def cancel(self, provider_turn_id):
        self.state["cancelled_turn"] = provider_turn_id


def install_supplied_provider(monkeypatch, state):
    provider = SuppliedProvider(state)
    monkeypatch.setenv("ORKET_MODEL_STREAM_PROVIDER", "stub")
    monkeypatch.setattr(workload, "StubModelStreamProvider", lambda: provider)
