"""Held real HTTP client exits and peer EOF for the public model-stream workload."""
from __future__ import annotations

import asyncio
import json
import threading
from contextlib import asynccontextmanager
from functools import partial

import httpx

from orket.streaming.model_provider import OpenAICompatModelStreamProvider
from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger
from tests.helpers.model_stream_input_controls import configure
from tests.helpers.observed_http_server import observed_http_server


def state_for(root, case):
    kind = case.split(":")[-1]
    failures = {"OSError": OSError("actual stream exit failure"),
        "CancelledError": asyncio.CancelledError("native stream exit cancellation"),
        "SystemExit": SystemExit(73), "KeyboardInterrupt": KeyboardInterrupt("stream exit fatal")}
    failure = failures.get(kind)
    if failure is not None:
        failure.__cause__ = LookupError("original stream failure cause")
    return {"root": root, "case": case, "failure": failure, "native_entered": threading.Event(),
        "native_release": threading.Event(), "native_finished": threading.Event(),
        "close_entered": asyncio.Event(), "close_release": asyncio.Event(), "close_finished": asyncio.Event(),
        "watch_entered": asyncio.Event(), "watch_release": asyncio.Event(), "watch_finished": asyncio.Event(),
        "peer_eof": asyncio.Event(), "first_token": asyncio.Event(), "next_chunk": asyncio.Event(),
        "requests": [], "close_calls": 0, "watch_calls": 0, "cancel_calls": [],
        "expired": False, "provider_started": False}


def install_provider_observer(monkeypatch, state):
    start, cancel = OpenAICompatModelStreamProvider.start_turn, OpenAICompatModelStreamProvider.cancel

    def started(owner, request):
        state.update(provider=owner, provider_started=True, consumer=asyncio.current_task())
        iterator = start(owner, request)
        state["iterator"] = iterator  # Strong reference makes product ownership observable before fixture teardown.
        return iterator

    monkeypatch.setattr(OpenAICompatModelStreamProvider, "start_turn", started)

    async def cancelled(owner, provider_turn_id):
        state["cancel_calls"].append(provider_turn_id)
        return await cancel(owner, provider_turn_id)

    monkeypatch.setattr(OpenAICompatModelStreamProvider, "cancel", cancelled)


def install_native_exit(monkeypatch, state):
    exit_client = httpx.Client.__exit__

    def held(owner, *args):
        state["native_thread"] = threading.get_ident()
        state["close_calls"] += 1
        state["native_client"] = owner
        (state["root"] / "native-request-observed.bin").write_bytes(b"real HTTP response reached client exit")
        state["native_entered"].set()
        try:
            state["expired"] = not state["native_release"].wait(10)
            assert not state["expired"], "native stream exit hold expired"
            result = exit_client(owner, *args)
            if state["failure"] is not None:
                raise state["failure"]
            return result
        finally:
            state["native_finished"].set()

    monkeypatch.setattr(httpx.Client, "__exit__", held)


def install_async_exit(monkeypatch, state):
    exit_client = httpx.AsyncClient.__aexit__

    async def held(owner, *args):
        if not state["provider_started"]:
            return await exit_client(owner, *args)
        state["close_calls"] += 1
        state["async_client"] = owner
        state["close_entered"].set()
        await state["close_release"].wait()
        result = await exit_client(owner, *args)
        state["close_finished"].set()
        return result

    monkeypatch.setattr(httpx.AsyncClient, "__aexit__", held)


async def response(request, state):
    state["requests"].append(request)
    first, body = request
    if first.startswith("GET /v1/models "):
        return 200, {"data": [{"id": "fixture"}]}
    assert first.startswith("POST /v1/chat/completions ") and body["model"] == "fixture"
    if body["stream"]:
        return 200, b'data: {"choices":[{"delta":{}}]}\n\ndata: [DONE]\n\n'
    return 200, {"choices": [{"message": {"content": "physical completion"}}], "usage": {"completion_tokens": 1}}


@asynccontextmanager
async def peer_stream_server(state):
    tasks, errors = set(), []

    async def handle(reader, writer):
        task = asyncio.current_task()
        tasks.add(task)
        try:
            head = await reader.readuntil(b"\r\n\r\n")
            first, *headers = head.decode().split("\r\n")
            size = next((int(h.split(":", 1)[1]) for h in headers if h.lower().startswith("content-length:")), 0)
            data = await reader.readexactly(size)
            state["requests"].append((first, json.loads(data) if data else None))
            if first.startswith("GET "):
                body = b'{"data":[{"id":"fixture"}]}'
                writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n" +
                    f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
            else:
                body = b'data: {"choices":[{"delta":{"content":"live chunk"}}]}\n\n'
                writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nTransfer-Encoding: chunked\r\n\r\n" +
                    f"{len(body):x}\r\n".encode() + body + b"\r\n")
                await writer.drain()
                if ":context:" in state["case"]:
                    await asyncio.wait_for(state["next_chunk"].wait(), 8)
                    writer.write(f"{len(body):x}\r\n".encode() + body + b"\r\n")
                    await writer.drain()
                assert await asyncio.wait_for(reader.read(1), 8) == b""
                state["peer_eof"].set()
            await writer.drain()
        except BaseException as failure:  # Fixture supervisor retrieves every actual socket handler outcome.
            errors.append(failure)
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(handle, "127.0.0.1", 0)
    try:
        yield f"http://127.0.0.1:{server.sockets[0].getsockname()[1]}"
    finally:
        server.close()
        await server.wait_closed()
        await asyncio.wait_for(asyncio.gather(*tasks), 10)
        assert not errors, errors


@asynccontextmanager
async def configured_server(monkeypatch, state):
    if state["case"].startswith("stream"):
        async with peer_stream_server(state) as address:
            configure(monkeypatch, state["root"], address, "control")
            monkeypatch.setenv("ORKET_MODEL_STREAM_OPENAI_USE_STREAM", "true")
            yield
    else:
        async with observed_http_server(partial(response, state=state), allow_disconnect=True) as server:
            configure(monkeypatch, state["root"], server[0], "control")
            if state["case"].startswith("fallback"):
                monkeypatch.setenv("ORKET_MODEL_STREAM_OPENAI_USE_STREAM", "true")
            yield


async def wait_observed(event, active=None):
    if isinstance(event, threading.Event):
        assert await asyncio.to_thread(event.wait, 3), "native client exit was not entered"
        return
    waiter = asyncio.create_task(event.wait())
    try:
        tasks = [waiter] if active is None else [waiter, active]
        done, _pending = await asyncio.wait(tasks, timeout=3, return_when=asyncio.FIRST_COMPLETED)
        assert done, "neither controlled cleanup nor public completion was observed"
    finally:
        waiter.cancel()
        await asyncio.gather(waiter, return_exceptions=True)


async def readback(state, active, *, name):
    iterator = state.get("iterator")
    consumer = state.get("consumer")
    watcher = state.get("watcher")
    data = {"case": state["case"], "parent_done": active.done(),
        "external_waiter_done": state["waiter"].done() if "waiter" in state else None,
        "consumer_done": None if consumer is None else consumer.done(),
        "watcher_done": None if watcher is None else watcher.done(),
        "native_entered": state["native_entered"].is_set(), "native_finished": state["native_finished"].is_set(),
        "close_entered": state["close_entered"].is_set(), "close_finished": state["close_finished"].is_set(),
        "watch_entered": state["watch_entered"].is_set(), "watch_finished": state["watch_finished"].is_set(),
        "peer_eof": state["peer_eof"].is_set(), "requests": state["requests"], "cancel_calls": state["cancel_calls"],
        "provider_cancel_slots": len(state["provider"]._canceled) if "provider" in state else None,
        "generator_frame_present": getattr(iterator, "ag_frame", None) is not None,
        "native_effect": await asyncio.to_thread((state["root"] / "native-request-observed.bin").exists),
        "cleanup_effect": await asyncio.to_thread((state["root"] / "cleanup-effect.bin").exists)}
    await asyncio.to_thread(write_payload_with_diff_ledger, state["root"] / (name + ".json"), data)
    return data
