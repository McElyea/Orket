# First model-stream lifetime slice

Scratch-only reviewable candidate. No tracked writes, product imports, runtime,
pytest collection or Mypy execution. Input and admission drafts remain frozen;
their now-closed durable deltas are read as support and are not overwritten.

## What changes

Three product paths form the smallest retained boundary approved by root:

| Path | Lines | Largest function | Scope |
| --- | ---: | ---: | --- |
| orket/workloads/model_stream_v1.py | 175 | 57 | Delegates actual turn lifetime; provider admission and final commit logic unchanged |
| orket/workloads/model_stream_turn.py | 133 | 37 | One turn's real identity/result, consumer, concrete generator and watcher |
| orket/streaming/model_provider.py | 571 | 168 existing | Shrinks by three lines; exactly two raw native POST awaits become owned-thread awaits |

The new turn owner uses shared run_owned_io/finish_owned_io without modifying
shared settlement. It delivers at most one parent interruption to actual async
consumption and retains native work, concrete Python generator aclose and watcher
join through further interruption. Event mapping and per-event branching are
moved without policy changes. Only types.AsyncGeneratorType is adopted; arbitrary
AsyncIterator optional methods do not create a close obligation.

The watcher returns its observed failures as a tuple so fatal Task exceptions
cannot escape before its owner observes them. One private stop marker identifies
only the cancellation this owner issued, including pre-start cancellation. Its
native/cleanup CancelledError is not blanket-suppressed. Concrete finalizer
failures have explicit producer provenance and take precedence over later caller
cancellation; multiple actual failures retain identity as group members.

At the broader provider-consumption boundary, shared caller-interruption
precedence remains unchanged. In particular a provider/native CancelledError
arriving during caller cancellation selects the first caller interruption.
The candidate deliberately proves that policy rather than claiming arbitrary
exception-origin inference. Existing ordinary provider ERROR conversion remains;
the new exact native identity controls target the concrete generator/watcher
finalization boundaries. A plain deadline retains its old fail_closed timeout
outcome after actual local work settles. Additional caller cancellation while a
deadline drains remains governed by asyncio.timeout/shared owner semantics.

## What is verified structurally

- Whole provider AST restoration removes only two owned native awaits and their
  imports. Existing POST request/timeout/header/parse and provider error conversion
  algorithms remain exact.
- All workload selection helpers, admission and construction are AST-identical;
  run entry inputs and final commit suffix are exact. Pure event mapping is exact;
  the event-consumer loop differs only by explicit turn state and iterator handle.
  The watcher still awaits the same context cancellation and invokes the same
  provider flag operation.
- New/modified files except the already oversized provider stay below 400 lines;
  new functions are below 70. The existing provider shrinks. New class has only
  __init__/run as public operations. No outside _event_mapping consumer was found;
  no compatibility export or existing test-hook migration is needed.
- Scoped canonical Ruff and whitespace-strict combined apply-check pass against
  current source. Package classifications allow application-to-adapter and
  adapter-to-adapter edges; no dependency exception is proposed. This import
  review is static, not execution of the full dependency gate.

Receipt SHA256:
`a51e3676d7219ef038877fb43eefc23c96454a9e96fffe49e53bb9744369eba5`.

| Baseline | SHA256 |
| --- | --- |
| workload | d9b796b50ab7756a4e58c367193e82c45a0e6b309fd9360ac872d4df2ce3c314 |
| provider | 7ca42ad138f1f99189554ef6a60a7fa30449acab0ca0634a7233e3d3ddd720b0 |
| durable provider governance spec | 4fc3171cf85129dc326d152f49c30e9b8b981d671ff367e876ce0e46b30a41be |

| Patch | SHA256 |
| --- | --- |
| product.patch | 326f33afae816085f57a775a2426bd1cad6b59016e51fd37696000ee15c8cf91 |
| opening.patch | 91afc469e500c27ca2b3233d7a115233587d79da90ae2dc336faf66d9df36f03 |
| authority.patch | 6fef4eff1f937681390250d0e19bf052386f5ba2ec62e592c0ff75aa64e6fcbf |

## Opening and closing selection

Nineteen cases are declared, not collected/executed. Opening adds four files:
HTTP/native controls194/max42, protocol controls92/max26, isolated worker216/max44,
integration module33/max10. Existing input fixture helpers and actual child harness
are reused unchanged; hashes are bound in receipt.json.

| Cases | What physically distinguishes ownership |
| --- | --- |
| Native normal, repeat cancellation, deadline, abandoned outer wait_for | Real loopback completion is read before actual sync client context exit is held; parent/consumer/watch remain retained; worker close is independently observed |
| Native CancelledError after repeat cancellation; ordinary OSError | Actual HTTP precedes held native exit and injected outcome; shared first-caller cancellation and existing provider ERROR conversion are explicit guards |
| Zero-delta fallback with repeat cancellation | Real streaming POST produces no delta, followed by actual native nonstream POST; held second exit cannot be abandoned |
| Max-token and actual manager cancellation | Real chunked peer emits a token; peer EOF is observed independently while actual async client exit is held |
| Concrete generator success/OSError/CancelledError/SystemExit | Supplied native Python generator finalizer performs a real file write after its hold; exact escaping outcome/cause or caller cancellation is observed |
| Watcher success/OSError/CancelledError/SystemExit/KeyboardInterrupt | Real context cancellation watch finalizer holds, writes a real file and returns/raises; repeated outward cancellation cannot release it |
| Arbitrary borrowed iterator | Public turn and durable commit use supplied AsyncIterator with a forbidden optional aclose; no false ownership transfer |

The fixtures preserve strong references to actual generators, eliminating GC as
an accidental cleanup mechanism. before-release.json observes actual original
parent, consumer and watcher tasks, actual requests and effect files. A second
readback occurs after the public result but before fixture rescue/manager shutdown.
Only then are events and durable commit independently read. The unchanged-source
fixture finally releases gates, drains native attempts and closes a remaining
concrete generator as emergency cleanup; that is never counted as product proof.
Fresh child processes contain potential unchanged-source fatal watcher escape;
the existing native supervisor records process lifetime and independent reap.

Root-owned sequence: apply opening only, run unchanged product and retain exact
inputs/readback; audit every failure for fixture/setup versus ownership policy;
then apply reviewed product and repeat all identities. Add tests/streaming,
tests/integration/test_model_stream_workload_inputs.py,
tests/integration/test_model_stream_target_admission.py, interaction lifetime
controls, tests/integration/test_owned_io_cancellation_identity.py and native
owned-I/O fatal/diagnostic guards. Use ORKET_DISABLE_SANDBOX=1 and distinct
worktree-local TEMP/TMP/artifacts. Root owns installed/full-gate scheduling.

## What is not verified; remaining blockers or drift

All runtime results remain absent. These are supplied loopback/native-control
protocols, not actual local daemon/external provider inference or model quality.
Local cancellation does not establish remote termination or rollback. Direct
provider consumers remain responsible for early-exit cleanup.

This slice intentionally leaves OpenAI HTTPX construction, captured TLS/proxy
inputs and native worker attribute observation, Ollama synchronous construction
and unclosed client/inner iterator, and provider-internal cleanup/error-conversion
issues open. In particular OpenAI can convert a context-exit error while closing
its generator into an attempted ERROR yield under GeneratorExit. The escaping
close failure is owned here; original transport failure identity in that path
requires a separate provider-client refactor. Do not turn supplied generator
identity controls into claims about this real provider internal path.

Specific reusable-owner concerns, source-inspected only: ProviderHttpResources
does not continue past a fatal close and logs directly during cleanup;
open_provider_catalog_client can suppress native cleanup CancelledError when a
body failure exists; runtime_result_lifetime.close_runtime_owner has a separate
uncontained task loop. This draft does not edit/reuse them to assert a wider
streaming lifetime. The new durable delta states all these limits. No D/C/E
closure or live provider acceptance follows from this proposed slice.

## Exact proposed paths

- orket/workloads/model_stream_v1.py
- orket/workloads/model_stream_turn.py
- orket/streaming/model_provider.py
- tests/helpers/model_stream_lifetime_controls.py
- tests/helpers/model_stream_protocol_controls.py
- tests/helpers/model_stream_lifetime_worker.py
- tests/integration/test_model_stream_owned_lifetime.py
- docs/specs/PROVIDER_GOVERNANCE_COMMAND_OWNERSHIP.md
- docs/architecture/CONTRACT_DELTA_MODEL_STREAM_LIFETIME_D_2026-09-28.md

All actual author writes are beneath this ignored candidate directory. No input
or admission candidate file or root-owned proof artifact was altered.
