"""Scratch-only first model-stream lifetime boundary over reviewed admission inputs."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / ".tmp/e2-orchestrator-review-20260928"))
import candidate_tools as c

c.STAGE = HERE
WORKLOAD = "orket/workloads/model_stream_v1.py"
PROVIDER = "orket/streaming/model_provider.py"
text = c.read(WORKLOAD)
expected = ROOT / ".tmp/d-model-stream-admission-20260928/candidate" / WORKLOAD
assert (HERE / "baseline" / WORKLOAD).read_bytes() == expected.read_bytes()
text = text.replace("import asyncio\n", "").replace("import contextlib\n", "")
text = text.replace("from orket.core.contracts.interaction_stream import CommitIntent, StreamEventType",
                    "from orket.core.contracts.interaction_stream import CommitIntent")
text = text.replace("    ProviderEvent,\n", "").replace("    ProviderEventType,\n", "")
text = c.remove_definitions(text, {"_event_mapping"})
text = c.import_lines(text, ["from orket.workloads.model_stream_turn import ModelStreamTurn"])
start = text.index("    provider_turn_id: str | None = None", text.index("async def run_model_stream_v1"))
end = text.index("    if provider_error:", start)
text = text[:start] + "    stop_reason, provider_error = await ModelStreamTurn(provider, req, interaction_context).run(turn_timeout_s)\n\n" + text[end:]
c.write(WORKLOAD, text)
text = c.read(PROVIDER)
text = text.replace("from enum import Enum\n", "from enum import Enum\nfrom functools import partial\n")
text = text.replace("from pydantic import BaseModel, Field\n", "from pydantic import BaseModel, Field\n\nfrom orket.adapters.execution.owned_io import run_owned_thread\n")
text = text.replace("fallback_body = await asyncio.to_thread(\n                    self._post_chat_completion_sync,\n                    headers,\n                    payload,\n                )", "fallback_body = await run_owned_thread(\n                    partial(self._post_chat_completion_sync, headers, payload), label=\"model-stream-completion\")")
text = text.replace("fallback_body = await asyncio.to_thread(\n                        self._post_chat_completion_sync,\n                        headers,\n                        fallback_payload,\n                    )", "fallback_body = await run_owned_thread(\n                        partial(self._post_chat_completion_sync, headers, fallback_payload), label=\"model-stream-fallback\")")
assert "asyncio.to_thread" not in text
c.write(PROVIDER, text)
