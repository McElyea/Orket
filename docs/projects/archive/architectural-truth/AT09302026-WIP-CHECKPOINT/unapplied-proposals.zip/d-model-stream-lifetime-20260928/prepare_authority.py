"""Append bounded stream-lifetime scope without overwriting the closed input/admission deltas."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / ".tmp/e2-orchestrator-review-20260928"))
import candidate_tools as c

c.STAGE = HERE
rel = "docs/specs/PROVIDER_GOVERNANCE_COMMAND_OWNERSHIP.md"
text = c.read(rel)
text += '''
The builtin model-stream turn separately retains its provider consumer, concrete
Python async-generator cleanup and cancellation watcher through repeated outward
interruption. Both OpenAI-compatible native completion attempts now use the
existing owned-thread boundary. This does not extend ownership to an arbitrary
AsyncIterator's optional close method, change remote cancellation into rollback,
or close remaining HTTP construction/network-input and Ollama client obligations.
Exact exception policy, retained effects and proof ceiling:
`docs/architecture/CONTRACT_DELTA_MODEL_STREAM_LIFETIME_D_2026-09-28.md`.
'''
c.write(rel, text)
