"""Source-only lifetime receipt; never imports or executes product or tests."""
from __future__ import annotations

import ast
import copy
import hashlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / ".tmp/e2-orchestrator-review-20260928"))
import candidate_tools as c
from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

PRODUCT = ["orket/workloads/model_stream_v1.py", "orket/streaming/model_provider.py",
           "orket/workloads/model_stream_turn.py"]
OPENING = ["tests/helpers/model_stream_lifetime_controls.py", "tests/helpers/model_stream_protocol_controls.py",
           "tests/helpers/model_stream_lifetime_worker.py", "tests/integration/test_model_stream_owned_lifetime.py"]
DOCS = ["docs/specs/PROVIDER_GOVERNANCE_COMMAND_OWNERSHIP.md",
        "docs/architecture/CONTRACT_DELTA_MODEL_STREAM_LIFETIME_D_2026-09-28.md"]
SUPPORT = ["orket/adapters/execution/owned_io.py", "orket/application/interactions/context.py",
    "orket/application/interactions/manager.py", "orket/application/interactions/commit.py",
    "orket/application/interactions/finalization.py", "orket/workloads/registry.py",
    "orket/application/services/provider_http_resources.py", "orket/application/services/provider_http_service.py",
    "orket/application/services/runtime_result_lifetime.py", "orket/application/services/native_resource_construction.py",
    "orket/adapters/llm/provider_catalog_client.py", "orket/adapters/llm/provider_inference_client.py",
    "orket/core/contracts/provider_http.py", "tests/helpers/model_stream_input_controls.py",
    "tests/helpers/model_stream_input_worker.py", "tests/helpers/observed_http_server.py",
    "tests/helpers/sdk_observation_controls.py", "tests/integration/test_logging_preparation_lifetime.py",
    "tests/streaming/test_openai_compat_model_provider.py", "tests/streaming/test_model_provider_regressions.py",
    "tests/streaming/test_stream_test_workload.py", "tests/integration/test_owned_io_cancellation_identity.py",
    "docs/architecture/CONTRACT_DELTA_MODEL_STREAM_INPUTS_D_2026-09-28.md",
    "docs/architecture/CONTRACT_DELTA_MODEL_STREAM_ADMISSION_D_2026-09-28.md",
    "model/core/contracts/dependency_direction_policy.json", "pyproject.toml"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parsed(tree, rel):
    return ast.parse((HERE / tree / rel).read_text(encoding="utf-8"))


def definition(tree, name):
    return next(n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)


def dump(node):
    return ast.dump(node, include_attributes=False)


def provider_restoration():
    old, new = [parsed(tree, PRODUCT[1]) for tree in ("baseline", "candidate")]
    class Restore(ast.NodeTransformer):
        count = 0

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == "run_owned_thread":
                call, = node.args
                assert isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and call.func.id == "partial"
                assert len(node.keywords) == 1 and node.keywords[0].arg == "label"
                assert ast.literal_eval(node.keywords[0].value) in {"model-stream-completion", "model-stream-fallback"}
                self.count += 1
                return ast.Call(func=ast.Attribute(value=ast.Name(id="asyncio", ctx=ast.Load()), attr="to_thread",
                                                   ctx=ast.Load()), args=call.args, keywords=[])
            return self.generic_visit(node)

    restore = Restore()
    new = restore.visit(new)
    assert restore.count == 2
    new.body = [n for n in new.body if not (isinstance(n, ast.ImportFrom) and
                 n.module in {"functools", "orket.adapters.execution.owned_io"})]
    assert dump(old) == dump(new), "provider changed beyond the two owned native awaits/imports"


def workload_parity():
    old, new = [parsed(tree, PRODUCT[0]) for tree in ("baseline", "candidate")]
    turn = parsed("candidate", PRODUCT[2])
    assert dump(definition(old, "_event_mapping")) == dump(definition(turn, "_event_mapping"))
    old_run, new_run = [definition(tree, "run_model_stream_v1") for tree in (old, new)]
    assert dump(ast.Module(body=old_run.body[:4], type_ignores=[])) == dump(ast.Module(body=new_run.body[:4], type_ignores=[]))
    index = lambda body: next(i for i, n in enumerate(body) if isinstance(n, ast.If) and
                             isinstance(n.test, ast.Name) and n.test.id == "provider_error")
    assert dump(ast.Module(body=old_run.body[index(old_run.body):], type_ignores=[])) == dump(
        ast.Module(body=new_run.body[index(new_run.body):], type_ignores=[]))
    old_defs = {n.name: n for n in old.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                and n.name not in {"_event_mapping", "run_model_stream_v1"}}
    new_defs = {n.name: n for n in new.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                and n.name != "run_model_stream_v1"}
    assert old_defs.keys() == new_defs.keys() and all(dump(old_defs[k]) == dump(new_defs[k]) for k in old_defs)
    class RestoreState(ast.NodeTransformer):
        def visit_Attribute(self, node):
            if isinstance(node.value, ast.Name) and node.value.id == "self":
                names = {"context": "interaction_context", "request": "req"}
                return ast.Name(id=names.get(node.attr, node.attr), ctx=node.ctx)
            return self.generic_visit(node)

    old_loop = next(n for n in definition(old, "_consume_provider").body if isinstance(n, ast.AsyncFor))
    new_loop = next(n for n in ast.walk(definition(turn, "_consume_provider")) if isinstance(n, ast.AsyncFor))
    restored = RestoreState().visit(copy.deepcopy(new_loop))
    restored.iter = copy.deepcopy(old_loop.iter)
    assert dump(old_loop) == dump(restored), "event policy changed beyond explicit owner state"
    old_watch = definition(old, "_cancel_watch")
    new_watch = definition(turn, "_cancel_watch")
    assert dump(ast.Module(body=old_watch.body, type_ignores=[])) == dump(ast.Module(
        body=[RestoreState().visit(copy.deepcopy(n)) for n in new_watch.body[0].body], type_ignores=[]))


def review():
    for rel in [*PRODUCT[:2], DOCS[0]]:
        assert (HERE / "baseline" / rel).read_bytes() == (ROOT / rel).read_bytes(), rel
    for rel in [PRODUCT[2], *OPENING, DOCS[1]]:
        assert not (ROOT / rel).exists(), rel
    provider_restoration()
    workload_parity()
    measurements = []
    for tree, rel in [("candidate", p) for p in PRODUCT] + [("opening", p) for p in OPENING]:
        path, node = HERE / tree / rel, parsed(tree, rel)
        lines = len(path.read_text(encoding="utf-8").splitlines())
        functions = [n for n in ast.walk(node) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        largest = max(n.end_lineno - n.lineno + 1 for n in functions)
        if rel != PRODUCT[1]:
            assert lines <= 400 and largest <= 70, (rel, lines, largest)
        else:
            assert lines <= len((HERE / "baseline" / rel).read_text().splitlines())
        measurements.append({"tree": tree, "path": rel, "lines": lines, "largest_function": largest,
                             "sha256": digest(path)})
    cases = ast.literal_eval(next(n.value for n in parsed("opening", OPENING[-1]).body
                                 if isinstance(n, ast.Assign) and n.targets[0].id == "CASES"))
    assert len(cases) == len(set(cases)) == 19
    c.STAGE = HERE
    c.emit_patch(PRODUCT, "product.patch")
    c.emit_patch(OPENING, "opening.patch", tree="opening")
    c.emit_patch(DOCS, "authority.patch")
    payload = {"proof_kind": "structural_only", "runtime_executed": False, "collection_executed": False,
        "product_imports_executed": False, "mypy_executed": False, "tracked_writes": False,
        "provider_whole_ast_restoration": True, "unchanged_selection_and_final_commit_ast": True,
        "event_mapping_and_consumer_loop_parity": True, "original_cancel_signal_algorithm_parity": True,
        "shared_owner_unchanged": True, "measurements": measurements, "declared_cases_not_collected": cases,
        "baseline_hashes": {p: digest(HERE / "baseline" / p) for p in [*PRODUCT[:2], DOCS[0]]},
        "support_hashes": {p: digest(ROOT / p) for p in SUPPORT},
        "authority_hashes": {p: digest(HERE / "candidate" / p) for p in DOCS},
        "patch_hashes": {p: digest(HERE / p) for p in ["product.patch", "opening.patch", "authority.patch"]}}
    write_payload_with_diff_ledger(HERE / "receipt.json", payload)
    print(payload)


if __name__ == "__main__":
    review()
