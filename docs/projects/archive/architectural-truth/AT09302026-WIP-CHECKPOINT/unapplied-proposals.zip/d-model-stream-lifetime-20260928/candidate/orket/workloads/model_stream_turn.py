"""One builtin turn retains its consumer, concrete generator and cancellation watcher."""
from __future__ import annotations

import asyncio
from types import AsyncGeneratorType
from typing import Any

from orket.adapters.execution.owned_io import finish_owned_io, run_owned_io
from orket.application.interactions.context import InteractionContext
from orket.core.contracts.interaction_stream import StreamEventType
from orket.streaming.model_provider import ModelStreamProvider, ProviderEvent, ProviderEventType, ProviderTurnRequest


def _event_mapping(event: ProviderEvent) -> tuple[StreamEventType | None, dict[str, Any]]:
    payload = dict(event.payload)
    payload["authoritative"] = False
    if event.event_type == ProviderEventType.SELECTED:
        return (StreamEventType.MODEL_SELECTED, payload)
    if event.event_type == ProviderEventType.LOADING:
        return (StreamEventType.MODEL_LOADING, payload)
    if event.event_type == ProviderEventType.READY:
        return (StreamEventType.MODEL_READY, payload)
    if event.event_type == ProviderEventType.TOKEN_DELTA:
        return (StreamEventType.TOKEN_DELTA, payload)
    return (None, payload)


class ModelStreamTurn:
    def __init__(self, provider: ModelStreamProvider, request: ProviderTurnRequest, context: InteractionContext) -> None:
        self.provider, self.request, self.context = provider, request, context
        self.provider_turn_id: str | None = None
        self.stop_reason = ""
        self.provider_error = ""
        self.finalization_failure: BaseException | None = None

    async def run(self, timeout_s: float) -> tuple[str, str]:
        failure = None
        try:
            async with asyncio.timeout(timeout_s):
                await run_owned_io(self._run_with_watch, label="model-stream-turn",
                                   preserve_failure=True, cancel_on_interrupt=True)
        except BaseException as exc:  # Turn supervisor selects after consumer and watcher settlement.
            failure = exc
        # A concrete finalizer's own cancellation/failure is independently observed;
        # it must not be mistaken for the owner's injected cancellation/deadline.
        if self.finalization_failure is not None:
            raise self.finalization_failure
        if isinstance(failure, TimeoutError):
            self.provider_error = f"provider_turn_timeout:{timeout_s}s"
        elif failure is not None:
            raise failure
        return self.stop_reason, self.provider_error

    async def _run_with_watch(self) -> None:
        stop_marker = object()
        watch_operation = self._cancel_watch()
        try:
            watcher = asyncio.create_task(watch_operation)
        except BaseException:  # Refused task admission has not adopted the coroutine.
            watch_operation.close()
            raise
        failure = None
        try:
            await self._consume_provider()
        except BaseException as exc:  # Retain the consumer outcome until the watcher is joined.
            failure = exc
        if not watcher.done():
            watcher.cancel(stop_marker)

        async def join_watch():
            try:
                return await watcher
            except asyncio.CancelledError as exc:
                return (exc,)  # A watcher stopped before its first step has no body outcome.

        watch_failure, = await finish_owned_io(join_watch)
        if type(watch_failure) is asyncio.CancelledError and watch_failure.args == (stop_marker,):
            watch_failure = None
        if watch_failure is not None:
            if failure is not None and failure is not watch_failure:
                watch_failure = BaseExceptionGroup("Model stream consumer and cancel watcher failed",
                                                   [failure, watch_failure])
            self.finalization_failure = watch_failure
            raise watch_failure
        if failure is not None:
            raise failure

    async def _cancel_watch(self) -> tuple[BaseException | None]:
        try:
            await self.context.await_cancel()
            if self.provider_turn_id:
                await self.provider.cancel(self.provider_turn_id)
        except BaseException as failure:  # Contain task-fatal outcomes until the turn owner observes them.
            return (failure,)
        return (None,)

    async def _consume_provider(self) -> None:
        iterator = self.provider.start_turn(self.request)
        failure = None
        try:
            async for provider_event in iterator:
                self.provider_turn_id = provider_event.provider_turn_id
                if provider_event.event_type == ProviderEventType.ERROR:
                    self.provider_error = str(provider_event.payload.get("error") or "provider_error")
                    break
                if provider_event.event_type == ProviderEventType.STOPPED:
                    self.stop_reason = str(provider_event.payload.get("stop_reason") or "").strip().lower()
                    break
                stream_mapping, payload = _event_mapping(provider_event)
                if stream_mapping is None:
                    continue
                if self.context.is_canceled():
                    await self.provider.cancel(self.provider_turn_id)
                    break
                await self.context.emit_event(stream_mapping, payload)
        except BaseException as exc:  # Close this acquired concrete generator before propagating its outcome.
            failure = exc
        if isinstance(iterator, AsyncGeneratorType):
            async def close_generator():
                await iterator.aclose()

            try:
                await finish_owned_io(close_generator)
            except BaseException as cleanup_failure:
                if failure is not None and failure is not cleanup_failure:
                    cleanup_failure = BaseExceptionGroup("Model stream consumption and generator cleanup failed",
                                                         [failure, cleanup_failure])
                self.finalization_failure = cleanup_failure
                raise cleanup_failure
        # The public port permits arbitrary AsyncIterator objects. Their optional
        # methods do not imply that this workload owns an aclose capability.
        if failure is not None:
            raise failure
