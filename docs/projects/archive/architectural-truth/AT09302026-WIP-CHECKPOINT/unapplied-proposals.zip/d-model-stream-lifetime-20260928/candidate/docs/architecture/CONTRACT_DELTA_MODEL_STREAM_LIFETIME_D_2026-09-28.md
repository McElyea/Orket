# Model-stream consumer and native-completion lifetime

Date: 2026-09-28
Status: Proposed bounded D ownership correction; runtime proof pending

## Boundary and retained authority

The public builtin model_stream_v1 retains one turn consumer and its cancellation
watcher until both settle. The per-turn ModelStreamTurn holds actual provider turn
identity, stop/error state and observed finalizer failure; it is not a proxy for
another mutable owner. It reuses run_owned_io with one cancellation delivery and
finish_owned_io for already-selected finalization. There is no new settlement
loop, global authority or provider-selection policy. Existing input capture and
canonical target admission remain byte-equivalent outside the changed lifetime
handoff. Event mapping and final commit selection remain the existing algorithms.

When start_turn returns a concrete Python types.AsyncGeneratorType, the builtin
acquires and closes that generator before returning, including STOPPED/ERROR or
interaction-cancel breaks. The public ModelStreamProvider port still permits
arbitrary AsyncIterator objects. A borrowed iterator's optional aclose method is
not called merely because it exists. Direct consumers of provider.start_turn
remain responsible for their own iteration/early-exit lifetime.

The native OpenAI-compatible completion and zero-delta fallback POSTs retain the
existing synchronous HTTPX operation through run_owned_thread. A parent timeout
or cancellation cannot finish that awaiting provider until the actual native
request/client-context exit settles. This does not stop an already admitted POST,
roll back completion effects, or prove remote generation terminated. A deadline
is a cancellation request followed by retained local settlement, not a guarantee
of immediate outward return. A separately cancelled external wait_for wrapper can
abandon its own wait; the underlying public turn still retains its admitted work.

## Outcome selection

- Normal events, ordinary provider ERROR conversion, fallback content/synthetic
  token behavior and fail_closed commit selection remain unchanged.
- A turn deadline selects the existing provider_turn_timeout error only after
  owned work settles. Caller cancellation retains its original first message;
  repeated caller cancellation does not release consumer or watcher cleanup.
- At the arbitrary provider-consumption boundary, shared cancel_on_interrupt
  policy remains authoritative: a provider CancelledError after outward caller
  cancellation selects that caller's first interruption. This includes a native
  POST CancelledError propagated through the provider. No unsupported inference
  about that exception's origin is made, and shared owned_io is unchanged.
- Concrete aclose and cancellation-watcher finalization are directly observed
  producer boundaries. Their escaping native error, including CancelledError,
  SystemExit or KeyboardInterrupt, takes precedence over later caller interruption
  and retains object/cause identity when it is the only failure. A distinct body
  and finalizer failure are retained together in a BaseExceptionGroup instead of
  dropping either. No cleanup failure is coerced into successful finalization.
- The owner issues its watcher one private cancellation marker at shutdown. Only
  that exact signal is expected, including cancellation before the watcher's first
  step. A different watcher CancelledError is an observed failure. Fatal watcher
  outcomes are contained as task results until the public turn selects them.
- Interaction cancellation remains the provider's existing cancel flag signal.
  Local streaming resource release is observable; immediate daemon cancellation
  and remote effect rollback are not promised.

## Proposed proof

Nineteen declared integration controls enter run_builtin_workload with real
InteractionManager, StreamBus and durable commit publication. Real loopback
catalog/completion cases hold the actual HTTPX native client context exit, cover
normal/repeated interruption/deadline/an abandoned outer waiter, ordinary error
conversion and the retained provider CancelledError policy. Zero-delta fallback
requires both actual POST requests. Real chunked streaming cases observe peer EOF
after max-token or actual manager cancellation and hold actual async client exit.

Supplied protocol controls separately exercise native Python generator and watcher
finalizers, real file effects, ordinary/native-cancel/fatal outcomes, and a borrowed
non-generator iterator with a forbidden optional aclose. These supplied controls
prove the builtin finalization contract, not real provider failure behavior. Every
held case records parent/consumer/watcher state and physical effects before release,
then again before emergency fixture teardown. Strong generator references make
the product's ownership independent of garbage-collection finalization. The child
harness independently observes process origins and exit/reap.

No runtime or collection has been executed by this candidate author. Static AST,
Ruff, size and patch checks are structural only. Root-owned unchanged-source
opening, closing and installed evidence remain required. Local supplied HTTP and
GGUF fixtures do not establish live provider quality or external inference.

## Remaining blockers or drift

OpenAI HTTPX constructor/TLS/proxy environment capture and event-loop construction
remain open. The native POST still observes existing provider attributes within
its worker; this slice changes lifetime only. Ollama still constructs its SDK
client synchronously and lacks an explicit provider client-close lifetime. Its
inner SDK iterator close and all remote generation effects remain separate.

Existing provider-internal ordinary-error conversion can also catch an HTTP
context-exit error; during GeneratorExit it can attempt to yield ERROR and surface
an async-generator close RuntimeError. This slice preserves escaping finalizer
outcomes; it does not claim that the provider's internal conversion retains the
original HTTP cleanup exception. A later client-owner correction must separate
resource finalization from event-error conversion and prove actual transport faults.

The inspected reusable ProviderHttpResources owner catches Exception/CancelledError
and logs directly while closing peers; fatal close or diagnostic failure can stop
that sequence. open_provider_catalog_client also suppresses CancelledError from
close when a body failure exists. runtime_result_lifetime.close_runtime_owner has
a separate manual task loop and no fatal containment. Their source-bound concerns
are not reproduced or fixed here; importing those owners would not justify broader
streaming cleanup claims. No D/C closure or provider acceptance follows from this
bounded correction.
