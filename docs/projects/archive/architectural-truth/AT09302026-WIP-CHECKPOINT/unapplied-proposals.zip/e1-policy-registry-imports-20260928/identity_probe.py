"""Root-owned child hook for registry identity and actual policy validator behavior."""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
REGISTRY = "orket.runtime.registry.contract_schema"
LEGACY_REGISTRY = "orket.runtime.contract_schema"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def value_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def origins(module, expected):
    path = Path(module.__file__).resolve()
    assert path == (ROOT / (expected.replace(".", "/") + ".py")).resolve() and path.is_relative_to(ROOT)
    return {"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path)}


def input_hashes(receipt, phase):
    expected = dict(receipt["source_hashes"])
    if phase == "candidate":
        for relative in receipt["parity"]:
            expected[relative] = sha(HERE / "candidate" / relative)
    actual = {path: sha(ROOT / path) for path in expected}
    assert actual == expected, [p for p in actual if actual[p] != expected[p]]
    return actual


def exact_refusal(validator, payload, expected):
    before = deepcopy(payload)
    try:
        validator(payload)
    except ValueError as exc:
        assert exc.args == (expected,), (exc.args, expected)
    else:
        raise AssertionError("duplicate policy row was accepted")
    assert payload == before
    return expected


def probe_policy(name, controls, source):
    canonical = "orket.runtime.policy." + name
    consumer = importlib.import_module(canonical)
    assert importlib.import_module("orket.runtime." + name) is consumer
    registry = source.ContractRegistry
    assert consumer.ContractRegistry is registry and registry.__module__ == REGISTRY
    snapshot = getattr(consumer, name + "_snapshot")
    validator = getattr(consumer, "validate_" + name)
    payload = snapshot()
    before = deepcopy(payload)
    expected = validator(payload)
    assert isinstance(expected, tuple) and payload == before
    damaged = deepcopy(payload)
    damaged[controls["collection_key"]].append(deepcopy(damaged[controls["collection_key"]][0]))
    refusal = exact_refusal(validator, damaged, controls["duplicate_error"])

    def rejected_source_constructor(*_args, **_kwargs):
        raise AssertionError("later source constructor patch retargeted a captured class")

    try:
        source.ContractRegistry = rejected_source_constructor
        assert consumer.ContractRegistry is registry
        assert validator(payload) == expected
        exact_refusal(validator, damaged, controls["duplicate_error"])
    finally:
        source.ContractRegistry = registry
    observed = []

    def local_constructor(*args, **kwargs):
        instance = registry(*args, **kwargs)
        assert type(instance) is registry
        observed.append({"collection": instance.collection_key, "schema": instance.schema_version})
        return instance

    try:
        consumer.ContractRegistry = local_constructor
        assert source.ContractRegistry is registry
        assert validator(payload) == expected
        exact_refusal(validator, damaged, controls["duplicate_error"])
        assert len(observed) == 2 and all(r["collection"] == controls["collection_key"] for r in observed)
    finally:
        consumer.ContractRegistry = registry
    assert payload == before and consumer.ContractRegistry is source.ContractRegistry
    return {"policy": name, "origin": origins(consumer, canonical), "class_identity_preserved": True,
            "consumer_legacy_module_identity": True, "source_patch_does_not_retarget_capture": True,
            "local_constructor_reached_by_actual_validator": observed, "payload_sha256": value_sha(payload),
            "result": expected, "duplicate_refusal": refusal, "supplied_payload_not_mutated": True}


def empty_queue_control():
    module = importlib.import_module("orket.runtime.policy.spec_debt_queue")
    original = module.ContractRegistry

    def forbidden_constructor(*_args, **_kwargs):
        raise AssertionError("empty queue unexpectedly reached constructor")

    try:
        module.ContractRegistry = forbidden_constructor
        payload = {"schema_version": "1.0", "entries": []}
        assert module.validate_spec_debt_queue(payload) == ()
        assert payload == {"schema_version": "1.0", "entries": []}
    finally:
        module.ContractRegistry = original
    return {"empty_queue_accepted": True, "constructor_not_reached": True, "input_unchanged": True}


def main():
    from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

    receipt = json.loads((HERE / "receipt.json").read_text(encoding="utf-8"))
    choices = [REGISTRY, LEGACY_REGISTRY]
    choices.extend("orket.runtime." + prefix + name for name in receipt["policies"] for prefix in ("policy.", ""))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("baseline", "candidate"), required=True)
    parser.add_argument("--first", choices=choices, required=True)
    parser.add_argument("--out", type=Path, default=HERE / "identity-observation.json")
    args = parser.parse_args()
    output = args.out.resolve()
    assert output.is_relative_to(ROOT)
    bound = input_hashes(receipt, args.phase)
    assert not any(n == "orket" or n.startswith("orket.") for n in sys.modules)
    importlib.import_module(args.first)
    present = [n for n in choices if n in sys.modules]
    source = importlib.import_module(REGISTRY)
    assert importlib.import_module(LEGACY_REGISTRY) is source
    rows = [probe_policy(name, receipt["parity"]["orket/runtime/policy/" + name + ".py"]["validator_controls"], source)
            for name in receipt["policies"]]
    empty = empty_queue_control()
    assert input_hashes(receipt, args.phase) == bound
    payload = {"proof_kind": "executed_import_class_binding_and_validator_controls", "phase": args.phase,
               "first_requested_import": args.first, "selected_modules_present_after_first_import": present,
               "root_package_initialization_may_load_consumers": True, "registry_origin": origins(source, REGISTRY),
               "registry_legacy_module_identity": True, "source_hashes": bound, "source_inputs_unchanged": True,
               "rows": rows, "empty_queue": empty, "native_process_owner": "required from parent campaign",
               "artifact_publication_proof": False, "external_provider_or_shipping_proof": False}
    write_payload_with_diff_ledger(output, payload)
    print(json.dumps({"phase": args.phase, "first": args.first, "policy_controls": len(rows)}, sort_keys=True))


if __name__ == "__main__":
    main()
