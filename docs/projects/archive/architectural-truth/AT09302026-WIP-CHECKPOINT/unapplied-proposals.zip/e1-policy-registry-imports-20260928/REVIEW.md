# Four policy consumers of the shared contract registry

SCRATCH ONLY. Four import/capture edits; no tracked source, test, or shared-doc mutation. No product imports, runtime, collection, pytest, or Mypy executed. Root owns application and serial proof.

## Findings and remaining risks

**Ship-risk debt:** The exact existing `ContractRegistry` class must remain the constructor seen by each validator. This candidate imports the real module through the registry package's public surface and captures that same class in each original local name. Constructor arguments, validation order, snapshots, errors, and return values are untouched. Cold initialization and actual validator execution remain unverified until the supplied root-owned controls run.

**Exploration-safe debt:** No size extraction or deeper contract change is needed. Each touched source is below 400 lines before and after. The remaining oversized drift checker, provider target, and summary module are excluded; this small import correction does not close their structural or typing debt.

**Self-deception debt:** Four missing flat-alias class attributes and one downstream `no-any-return` in workspace hygiene are targeted in the retained log. Five removed diagnostics is an expectation, not an observation. Static AST, Ruff, and patch checks cannot establish import success, real artifact publication, or deployment correctness. `provider_discovery.py`'s reported object-iteration diagnostic is not flat-alias debt and is expressly excluded.

## Proposed implementation

For each of the four consumers, replace only:

```python
from orket.runtime.contract_schema import ContractRegistry
```

with the genuine public-module import and captured class:

```python
from orket.runtime.registry import contract_schema as _contract_schema

# Preserve the existing consumer-local constructor binding.
ContractRegistry = _contract_schema.ContractRegistry
```

| Consumer | Before / after lines | Actual validator |
| --- | --- | --- |
| `orket/runtime/policy/source_attribution_policy.py` | 102 / 105 | `validate_source_attribution_policy` |
| `orket/runtime/policy/spec_debt_queue.py` | 66 / 69 | `validate_spec_debt_queue` |
| `orket/runtime/policy/trust_language_review_policy.py` | 158 / 161 | `validate_trust_language_review_policy` |
| `orket/runtime/policy/workspace_hygiene_rules.py` | 64 / 67 | `validate_workspace_hygiene_rules` |

`orket/runtime/registry/contract_schema.py` remains the sole class owner. The existing flat module remains an external compatibility alias. The registry package already declares `contract_schema` in `__all__`; no package loader or export changes. Cross-domain policy imports use the public registry module surface described by `test_runtime_domain_modules_do_not_import_peer_domain_private_modules`. Existing dependency policy classifies runtime modules as application and permits application-to-application edges. No exception, direct private peer import, shim, duplicate class, subclass wrapper, cast, `Any`, or suppression is added.

All original AST and source segments, including function signatures/defaults, constructor calls, policy collections, and validator branches, remain exact after newline normalization. The only new binding is the explicit private module local plus the unchanged class local. There are no new product functions/classes or name collisions. Existing consumer-local monkeypatch points remain meaningful; canonical-module class patches made after capture do not replace the consumer class. No claim is made about arbitrary hooks during import. Root package initialization can preload these modules and the child probe records that observation.

## Proof hooks and truthful scope

`identity_probe.py` is child-only and accepts `--phase baseline|candidate`, `--first <module>`, and `--out <contained-output>`. `FIRST_IMPORTS.txt` gives ten fresh first requests: canonical/legacy registry and canonical/legacy names for each of four consumers. Every child checks all four consumers.

The prepared controls check exact module source origins, legacy/canonical module identity, and exact class object identity. They call each actual snapshot and validator with a healthy payload, then append a duplicate row and require the existing exact error. They assert the supplied payload remains unchanged on success and refusal. After patching the canonical source constructor, validators must still reach their captured class. After patching the consumer-local constructor with a delegate to the real class, validators must reach that delegate and construct instances of the original class. The spec-debt empty queue must retain its existing early return without reaching a constructor. None of these controls has been executed during preparation.

The child checks the 26 scoped source inputs before and after execution and writes results using the existing diff ledger. The parent must supply the real native owner, timeout/cancellation settlement, process reaping, and broader source/environment binding. The child itself supplies no process ownership proof. It proves pure contract behavior when executed, not actual artifact publication or external provider behavior.

`SELECTORS.txt` lists ten existing modules: the four policy contracts, runtime package boundary checks, the truth drift checker, run-start artifact creation/reentry, two policy artifact immutability modules, and application policy-enforcement tests. These preserve their current layers and assertions. The public pipeline policy-blocking selection is supplied application-path proof, not provider/live success. Real filesystem artifact assertions remain the responsibility of the existing run-start selections.

Suggested root sequence: confirm source hashes; run baseline selectors and owned cold children; apply the exact four candidate bytes; repeat the same selectors and first requests; compare actual validator values, exact refusal errors, class/patch dispositions, and payload hashes; then run canonical Mypy plus normal dependency/Ruff gates in the permitted window. Do not derive a later aggregate by subtracting five from a stale full baseline, and do not suppress newly exposed caller diagnostics.

Static preparation passed canonical-config Ruff on all candidate product paths and on both helper scripts, exact AST/source-segment checks, and `git apply --check --whitespace=error`. Runtime and Mypy proof remain absent. The canonical baseline used for diagnostic attribution is `.tmp/goal-20260928-tool-roots-epic-native-mypy.log`; it is retained unchanged.

## Complete scoped remaining alias inventory

`REMAINING_ALIASES.tsv` and `INVENTORY.sha256` bind the current policy/config/summary inventory: 29 flat `ImportFrom` statements, 33 imported names, 11 source files. Inspection traversed all AST scopes; no matching plain `import orket.runtime.<flat>` statements were found in these domains. These counts describe the current source before this candidate is applied, not future proof or repository-wide alias closure.

| Current consumer | Statements / names | Disposition |
| --- | --- | --- |
| `config/model_profile_bios.py` | 1 / 1 | Separate same-domain provider-truth snapshot import |
| `config/provider_runtime_target.py` | 12 / 14 | Separate provider/inventory/quarantine family; 618-line owner, class/private callable aliases and bridge caller semantics need focused review |
| `policy/capability_fallback_hierarchy.py` | 1 / 1 | Separate public config provider-truth snapshot import |
| `policy/composition.py` | 1 / 3 | Separate public registry profile/capability authority; preserve deferred engine construction and settings behavior |
| `policy/protocol_determinism_campaign.py` | 1 / 1 | Separate replay-engine class import, needs actual campaign selectors |
| `policy/runtime_truth_drift_checker.py` | 8 / 8 | Separate 1017-line owner; public module captures would grow it without a justified enabling change |
| `policy/source_attribution_policy.py` | 1 / 1 | This four-file candidate |
| `policy/spec_debt_queue.py` | 1 / 1 | This four-file candidate |
| `policy/trust_language_review_policy.py` | 1 / 1 | This four-file candidate |
| `policy/workspace_hygiene_rules.py` | 1 / 1 | This four-file candidate |
| `summary/run_summary.py` | 1 / 1 | Separate 689-line owner; preserve identity validator authority without oversized growth |

The retained log additionally lists `config/provider_discovery.py` under `[attr-defined]` because `payload["models"]` is typed `object` and not iterable. Current source imports its provider inventory/target canonically; there is no remaining flat import in this file. No change to that annotation or input/refusal behavior is proposed here.

## Exact files proposed

Only the four policy consumer paths listed above. Candidate copies, unchanged byte baselines, patch, static logs, inventory, selectors, receipt, and child hook reside under `.tmp/e1-policy-registry-imports-20260928`. No other Git-visible path is proposed for modification.
