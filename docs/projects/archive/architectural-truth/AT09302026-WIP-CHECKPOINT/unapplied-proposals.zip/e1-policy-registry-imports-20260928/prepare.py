"""Prepare four existing registry-class captures; source inspection and Ruff only."""
from __future__ import annotations

import ast
import difflib
import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
POLICIES = ("source_attribution_policy", "spec_debt_queue", "trust_language_review_policy", "workspace_hygiene_rules")
LOG = ".tmp/goal-20260928-tool-roots-epic-native-mypy.log"
DEPENDENCY = "model/core/contracts/dependency_direction_policy.json"
SELECTORS = [
    "tests/runtime/test_runtime_subpackage_boundaries.py",
    "tests/runtime/test_source_attribution_policy.py",
    "tests/runtime/test_spec_debt_queue.py",
    "tests/runtime/test_trust_language_review_policy.py",
    "tests/runtime/test_workspace_hygiene_rules.py",
    "tests/runtime/test_runtime_truth_drift_checker.py",
    "tests/runtime/test_run_start_artifacts.py",
    "tests/runtime/test_run_start_source_attribution_policy_immutability.py",
    "tests/runtime/test_run_start_trust_language_review_policy_immutability.py",
    "tests/integration/policy_enforcement/test_runtime_policy_enforcement.py",
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def dump(node):
    return ast.dump(node, include_attributes=False)


def ruff(relative, source):
    argv = [sys.executable, "-m", "ruff", "check", "--no-cache", "--stdin-filename", str(ROOT / relative), "-"]
    observed = subprocess.run(argv, cwd=ROOT, input=source, text=True, capture_output=True, check=False)
    log = HERE / (Path(relative).stem + "-ruff.log")
    write(log, observed.stdout + observed.stderr)
    assert observed.returncode == 0, observed.stdout + observed.stderr
    return {"argv": argv, "exit_code": observed.returncode, "log_sha256": sha(log)}


def prepare_one(name):
    relative = "orket/runtime/policy/" + name + ".py"
    original = ROOT / relative
    baseline = HERE / "baseline" / relative
    if baseline.exists():
        assert baseline.read_bytes() == original.read_bytes(), relative
    else:
        baseline.parent.mkdir(parents=True, exist_ok=True)
        baseline.write_bytes(original.read_bytes())
    before = original.read_text(encoding="utf-8")
    old_import = "from orket.runtime.contract_schema import ContractRegistry\n"
    new_import = "from orket.runtime.registry import contract_schema as _contract_schema\n"
    assert before.count(old_import) == 1
    after = before.replace(old_import, new_import, 1)
    anchor = name.upper() + "_SCHEMA_VERSION ="
    assert after.count(anchor) == 1
    capture = "# Preserve the existing consumer-local constructor binding.\nContractRegistry = _contract_schema.ContractRegistry\n\n"
    after = after.replace(anchor, capture + anchor, 1)
    write(HERE / "candidate" / relative, after)
    check = ruff(relative, after)
    return relative, before, after, check


def verify(before, after):
    old, new = ast.parse(before), ast.parse(after)
    old_nodes, new_nodes, captures = [], [], []
    for node in old.body:
        if isinstance(node, ast.ImportFrom) and node.module == "orket.runtime.contract_schema":
            continue
        old_nodes.append(node)
    for node in new.body:
        if isinstance(node, ast.ImportFrom) and node.module == "orket.runtime.registry":
            assert [(a.name, a.asname) for a in node.names] == [("contract_schema", "_contract_schema")]
            continue
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "ContractRegistry" for t in node.targets):
            captures.append(node)
            continue
        new_nodes.append(node)
    assert len(captures) == 1 and ast.unparse(captures[0]) == "ContractRegistry = _contract_schema.ContractRegistry"
    assert list(map(dump, old_nodes)) == list(map(dump, new_nodes))
    assert [ast.get_source_segment(before, n) for n in old_nodes] == [ast.get_source_segment(after, n) for n in new_nodes]
    assert not any(isinstance(n, ast.Name) and n.id == "_contract_schema" for n in ast.walk(old))
    assert len(after.splitlines()) < 400
    calls = [n for n in ast.walk(old) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "ContractRegistry"]
    assert len(calls) == 1
    controls = {k.arg: ast.literal_eval(k.value) for k in calls[0].keywords if k.arg in {"collection_key", "duplicate_error"}}
    return {"original_lines": len(before.splitlines()), "candidate_lines": len(after.splitlines()),
            "all_original_ast_exact_except_import": True, "original_source_segments_exact": True,
            "capture_exact_and_no_shadow": True, "validator_controls": controls}


def inventory():
    domains = {"config", "evidence", "execution", "policy", "registry", "summary"}
    rows, paths = [], set()
    for domain in ("policy", "config", "summary"):
        for path in sorted((ROOT / "orket/runtime" / domain).glob("*.py")):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if not isinstance(node, ast.ImportFrom) or not node.module:
                    continue
                parts = node.module.split(".")
                if len(parts) != 3 or parts[:2] != ["orket", "runtime"] or parts[2] in domains:
                    continue
                paths.add(path.relative_to(ROOT).as_posix())
                alias = ROOT / (node.module.replace(".", "/") + ".py")
                calls = [n for n in ast.walk(ast.parse(alias.read_text(encoding="utf-8"))) if isinstance(n, ast.Call)
                         and isinstance(n.func, ast.Name) and n.func.id == "_import_module"]
                assert len(calls) == 1
                canonical = ast.literal_eval(calls[0].args[0])
                for name in node.names:
                    rows.append((path.relative_to(ROOT).as_posix(), str(node.lineno), node.module,
                                 canonical, name.name, name.asname or name.name))
    assert len(rows) == 33 and len(paths) == 11
    write(HERE / "REMAINING_ALIASES.tsv", "consumer\tline\tlegacy\tcanonical\tname\tlocal\n" +
          "".join("\t".join(row) + "\n" for row in rows))
    write(HERE / "INVENTORY.sha256", "".join(sha(ROOT / p) + "  " + p + "\n" for p in sorted(paths)))
    return {"statements": len({(r[0], r[1]) for r in rows}), "names": len(rows), "files": len(paths),
            "paths": sorted(paths), "scope": "current flat ImportFrom in all AST scopes of policy/config/summary"}


def support():
    paths = {LOG, DEPENDENCY, "pyproject.toml", "orket/runtime/__init__.py",
             "orket/runtime/contract_schema.py", "orket/runtime/registry/contract_schema.py",
             "orket/runtime/registry/__init__.py", "orket/runtime/policy/__init__.py", *SELECTORS}
    paths.update("orket/runtime/policy/" + name + ".py" for name in POLICIES)
    paths.update("orket/runtime/" + name + ".py" for name in POLICIES)
    return {p: sha(ROOT / p) for p in sorted(paths)}


def main():
    from scripts.common.rerun_diff_ledger import write_payload_with_diff_ledger

    checks, parity, chunks = {}, {}, []
    for name in POLICIES:
        relative, before, after, check = prepare_one(name)
        checks[relative] = check
        parity[relative] = verify(before, after)
        chunks.append(f"diff --git a/{relative} b/{relative}\n")
        chunks.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="a/" + relative, tofile="b/" + relative))
    write(HERE / "candidate.patch", "".join(chunks))
    result = subprocess.run(["git", "apply", "--check", "--whitespace=error", str(HERE / "candidate.patch")], cwd=ROOT, text=True, capture_output=True, check=False)
    write(HERE / "apply-check.log", result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    all_aliases = inventory()
    source_hashes = support()
    package = ast.parse((ROOT / "orket/runtime/registry/__init__.py").read_text(encoding="utf-8"))
    exports = next(ast.literal_eval(n.value) for n in package.body if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == "__all__" for t in n.targets))
    assert "contract_schema" in exports
    policy = json.loads((ROOT / DEPENDENCY).read_text(encoding="utf-8"))
    assert policy["classifications"]["orket.runtime"] == "application"
    assert ["application", "application"] in policy["allowed_edges"]
    diagnostics = [line for line in (ROOT / LOG).read_text(encoding="utf-8-sig").splitlines()
                   if any(line.startswith(p.replace("/", "\\") + ":") for p in parity) and ": error:" in line]
    assert len(diagnostics) == 5
    write(HERE / "SELECTORS.txt", "\n".join(SELECTORS) + "\n")
    first = ["orket.runtime.registry.contract_schema", "orket.runtime.contract_schema"]
    first.extend("orket.runtime." + prefix + name for name in POLICIES for prefix in ("policy.", ""))
    write(HERE / "FIRST_IMPORTS.txt", "\n".join(first) + "\n")
    receipt = {"proof_kind": "structural_only", "tracked_writes": False, "product_imports": False,
               "runtime_executed": False, "collection_executed": False, "mypy_executed": False,
               "parity": parity, "policies": list(POLICIES), "source_hashes": source_hashes,
               "inventory": all_aliases, "retained_diagnostics": diagnostics, "target_diagnostics": 5,
               "observed_removed_diagnostics": None, "checks": checks, "git_apply_check_exit": result.returncode,
               "public_module_declared": True, "dependency_exception_added": False, "selectors": SELECTORS,
               "artifacts": {p.relative_to(HERE).as_posix(): sha(p) for p in HERE.rglob("*")
                             if p.is_file() and p.name != "receipt.json"}}
    write_payload_with_diff_ledger(HERE / "receipt.json", receipt)
    print(json.dumps({"sizes": parity, "source_bindings": len(source_hashes), "receipt_sha256": sha(HERE / "receipt.json")}, sort_keys=True))


if __name__ == "__main__":
    main()
