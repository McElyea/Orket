# Proposed captured stream client ownership

Source-only review, no product imports, runtime, collection, Mypy or tracked edits.
Baseline for the subsequent provider flow is the frozen first lifetime candidate
in .tmp/d-model-stream-lifetime-20260928, not a rewritten version of its receipts.
The separate shared-resource prerequisite can target current source independently.

## Ship-risk debt and the bounded cut

1. OpenAI constructs AsyncClient on the event loop and its native nonstream helper
   constructs Client in a worker; both consult ambient TLS/proxy configuration.
   The worker also rereads provider attributes. USE_STREAM is read after the turn
   lock rather than from the workload's captured environment. Existing canonical
   capture_provider_http_inputs and build_provider_http_client already implement
   explicit proxy mounts, captured trust/keylog paths, verified SSL construction,
   trust_env=False and partial resource registration. Duplicating these policies
   in streaming would create another authority.
2. Ollama constructs AsyncClient synchronously in its constructor. The installed
   SDK source has a public async close() and a native Python async generator for
   streaming chat; the existing provider neither closes the client nor explicitly
   closes that inner generator on its own early return. SDK BaseClient reads
   OLLAMA_HOST and OLLAMA_API_KEY; the existing inference builder already overrides
   the former explicitly and uses CapturedOllamaAuth for the latter.
3. ProviderHttpResources is the existing shared acquired-resource owner. Its
   _close catches only Exception/CancelledError and directly logs before appending
   failure, so fatal resource or diagnostic failure can skip later resources.
   open_provider_catalog_client separately catches and suppresses CancelledError
   from cleanup after a body failure. These source defects block truthful reuse.
4. Provider ordinary-error catches enclose lexical client contexts. During
   generator close, an ordinary client/response exit failure can be converted into
   an attempted ERROR yield under GeneratorExit, losing the native cleanup outcome.
   First-slice iterator ownership cannot repair that provider-internal conversion.

## Proposed resource-owner prerequisite

Keep owned_io unchanged. In existing ProviderHttpResources, append every actual
BaseException before diagnostic dispatch, reuse run_owned_diagnostic with that
failure as primary, and continue all retained peer close attempts. Preserve the
existing aggregate error shape and resource identities; diagnostics must neither
replace a primary nor prevent later close attempts.

Move the existing catalog construction/yield/finalization algorithm into that same
resource owner as one context operation. It admits the canonical native builder
through run_owned_thread, owns any resources registered before partial failure,
and uses finish_owned_io for cleanup after an outcome is selected. A successful
body retains caller cancellation during close; an already failed body retains
later cancellation only as interruption while native cleanup failure remains
visible. Distinct actual body and cleanup failures remain group members. Treat
GeneratorExit as intentional generator close: clean cleanup propagates it, while
failed cleanup is visible without classifying GeneratorExit as another fault.
Migrate open_provider_catalog_client to this operation; do not leave two competing
construction/context teardown algorithms. Reuse the same operation for streams.

This prerequisite changes shared catalog/inference/short-request/Gitea cleanup,
so it needs independent real controls and retained integration guards before the
stream composition claim. Native constructor helper/runtime_result_lifetime have
their own direct diagnostic/manual-loop issues; there is no reason to introduce
those algorithms into this stream path when the acquired-resource owner and
existing run_owned_thread already cover admission and partial registration.

Opening controls should use actual list_provider_models/local HTTP and observed
native client/transport close operations, not a generic fake owner. Required
counterexamples: native close CancelledError after selected HTTP failure; fatal
client close followed by real retained transport closure; ordinary/fatal/cancel
supporting diagnostic failure while preserving each close outcome and remaining
peer attempts; held native construction and held close under repeated cancellation;
partial proxy construction refusal and real loopback network effects. Fresh child
processes contain unchanged-source fatal escapes. Existing provider HTTP ownership,
TLS/environment/inference and Gitea ownership suites are meaningful parity guards.

## Proposed provider client composition

Extend the existing ProviderInferenceHttpService with a per-turn stream-client
context, using the same captured ProviderHttpInputs and acquired-resource owner.
The adapter native builder retains all transports and the actual HTTPX/Ollama
client. Keep OpenAI's exact timeout phases: pool=timeout_s and connect/read/write
=min(10, timeout_s); retain Ollama SDK timeout=None/follow_redirects=True plus its
existing separate connect/stream budgets. No uniform short-request timeout should
silently replace those rules.

Streaming is classified as adapters; it cannot import the application service.
The honest dependency handoff is a core stream-HTTP ownership port, required by
the pure OpenAI/Ollama provider constructors. The workload supplies the application
service using its already captured environment/CWD and passes captured USE_STREAM.
There is no ambient adapter fallback or application import exception. This is a
deliberate direct-constructor signature change, not a compatibility shim. Existing
repo construction callers are the two workload branches and three direct tests;
the supplied workload provider fake also needs the new explicit port argument.

Actual native construction occurs before a client is exposed and remains retained
through cancellation; all request payload/scalar selections must be local values
before the first await. Each real turn owns its own client context, preserving
OpenAI's per-turn isolation and defining Ollama's formerly missing close lifetime.
Nonstream and zero-delta fallback can use that same async HTTPX client. The private
sync POST helper is then removed, rather than kept as an unused compatibility
export for tests. This changes cancellation from noninterruptible native POST drain
to retained async request abort/close; exact wire fields/timeouts/fallback content
and remote-effect uncertainty must be documented and proved.

## Error conversion and terminal events

Inside the acquired-client context, remember only the exact declared generation
exception selected for ordinary provider ERROR conversion, and re-raise it through
the existing resource owner. Outside that context, emit ERROR only when the final
outcome is that same object. A constructor failure, cleanup error/group, fatal
failure or GeneratorExit cannot match, so it propagates without yielding. This
uses actual producer provenance, not type/traceback inference or wrapper exceptions.

Successful STOPPED and ordinary ERROR events should follow actual resource
settlement. Cancellation may stop token delivery and close local sockets; it does
not prove daemon generation stopped or undo submitted effects. A native cleanup
failure prevents a completed STOPPED claim. For a genuine generation plus cleanup
failure the resource owner retains both identities. A native CancelledError from
concrete close remains exact/grouped according to that selected body outcome;
the broader first-slice provider-boundary shared cancellation policy is unchanged.

Explicitly close only the installed Ollama SDK's acquired concrete Python async
generator, using the same retained finalization boundary. Do not assume arbitrary
AsyncIterator close ownership. Direct public provider consumers still own their
outer iteration lifetime; builtin ModelStreamTurn owns its acquired generator.

## Source and consumer migrations to review before implementation

The 571-line model_provider facade is already oversized. A coherent implementation
should preserve actual public class exports while defining each implementation
once in focused modules; no forwarded methods, copied owner state or private
monkeypatch compatibility exports. Pure event/request/protocol definitions can
move to one core contract and be re-exported at the genuine existing public import
surface. The exact module split is still a proposed design, not applied code.

- tests/streaming/test_openai_compat_model_provider.py: replace private sync POST
  fake with the explicit supplied HTTP port; retain payload/fallback assertions.
- tests/streaming/test_model_provider_regressions.py: actual SDK/client port setup
  replaces constructor-time sys.modules fake while retaining distinct budgets.
- tests/streaming/test_stream_test_workload.py: supplied provider constructor
  accepts the actual injected port; public selection and event assertions stay.
- tests/helpers/model_stream_input_controls.py and input worker: observe actual
  async request/closure after private native helper removal, retaining all seven
  input identities and request/root/auth/budget semantics. Do not fabricate a
  native worker observation for the new async flow.
- Frozen first-slice lifetime controls: retain generic generator/watch/borrowed
  and streaming cases; native-POST-specific controls become historical proof for
  that removed transport path. New async nonstream/fallback/native-construction
  controls must replace their actual obligations with an explicit migration map.
  Do not silently relabel the old native fixture as proof of async HTTP behavior.

## Meaningful later stream proof

Actual loopback proxy/origin split, captured NO_PROXY, relative trust/keylog under
held native construction and CWD/environment mutation; real invalid trust refusal
with no request; current SDK Ollama /api/chat NDJSON and OpenAI SSE/nonstream/fallback
requests with real client/transport close; held partial construction; actual peer
EOF on max-token/context/task/deadline abort; ordinary/native-cancel/fatal context
exit failures with no ERROR yield under GeneratorExit; request and close failure
groups retaining both actual identities. Every case needs before-release and
pre-fixture-teardown physical/task readback, supported original/closing source
identities, and child process reap. No external-provider or daemon-quality claim.

## Verification status

Read-only source inspection only. No proposed product/test code has been drafted
in this second stage yet. Root approval of the required-port contract and resource
prerequisite scope precedes implementation. Remaining concerns above are source
findings, not observed native failures or a claim of full D/C closure.
