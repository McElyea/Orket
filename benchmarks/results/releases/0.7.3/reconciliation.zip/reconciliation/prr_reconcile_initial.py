"""Read-only final PRR reconciliation; writes only new ignored receipts/downloads."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import httpx
import prr_common as p

REPO = 'McElyea/Orket'
COMMIT = '9cb8a89056c46f0c3633e0c20aaac60d80113236'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=p.ROOT, text=True).strip()


async def releases(directory, state, publication):
    refs = await p.command(directory, state, ['git', 'ls-remote', 'origin',
        'refs/heads/main', 'refs/tags/v0.7.*', 'refs/tags/sdk-v0.7.*'], 'remote-refs')
    actual = {line.split()[1]: line.split()[0] for line in refs.stdout.decode().splitlines()}
    for ref, value in publication['remote_refs'].items():
        if ref != 'refs/heads/main':
            assert actual[ref] == value, ref
    state['remote_refs'] = actual
    state['main_at_observation'] = actual['refs/heads/main']
    assert git('rev-parse', 'HEAD') == actual['refs/heads/main']
    subprocess.run(['git', 'merge-base', '--is-ancestor', COMMIT, 'HEAD'], check=True)
    state['later_main_commits'] = git('log', '--format=%H %s', COMMIT + '..HEAD').splitlines()
    for tag in ('v0.7.2', 'sdk-v0.7.2'):
        assert git('cat-file', '-t', 'refs/tags/' + tag) == 'tag'
        assert git('rev-parse', tag + '^{}') == COMMIT
        row = await p.command(directory, state, ['gh', 'api',
            f'repos/{REPO}/releases/tags/{tag}'], 'metadata-' + tag)
        data = json.loads(row.stdout)
        assert not data['draft'] and not data['prerelease'] and data['tag_name'] == tag
        destination = directory / tag
        destination.mkdir()
        await p.command(directory, state, ['gh', 'release', 'download', tag,
            '--repo', REPO, '--dir', destination], 'download-' + tag, seconds=180)
        expected = dict(publication['releases'][tag]['downloaded_assets_sha256'])
        expected['publication.json'] = publication['receipt_downloads'][tag]
        downloaded = {item.name: p.sha(item) for item in destination.iterdir()}
        assert downloaded == expected, tag
        assert {a['name']: a['digest'] for a in data['assets']} == {
            name: 'sha256:' + digest for name, digest in expected.items()}
        for manifest in destination.glob('SHA256SUMS*.txt'):
            for line in manifest.read_text().splitlines():
                digest, name = line.split()
                assert downloaded[name] == digest, name
        public = read(destination / 'publication.json')
        assert public['commit'] == COMMIT and public['observed_result'] == 'success'
        assert public['remote_refs'] == publication['remote_refs']
        assert public['releases'] == publication['releases']
        assert public['final_checks_receipt_sha256'] == p.sha(p.BASE / 'final-checks-r03/state.json')
        state.setdefault('releases', {})[tag] = dict(url=data['html_url'],
            downloaded_assets_sha256=downloaded, checksum_entries_verified=True)
        p.write(directory / 'state.json', state)
    old_refs = {line.split()[1]: line.split()[0] for line in publication['previous_tag_refs'].splitlines()}
    assert all(actual[key] == value for key, value in old_refs.items())
    for tag, expected in publication['previous_assets'].items():
        row = await p.command(directory, state, ['gh', 'api',
            f'repos/{REPO}/releases/tags/{tag}'], 'preserved-' + tag)
        assets = json.loads(row.stdout)['assets']
        assert [{k: a[k] for k in ('id', 'name', 'size', 'digest')} for a in assets] == expected
    state['previous_releases_preserved'] = True


def historical_evidence(state):
    root = p.ROOT / 'benchmarks/results/releases/0.7.2'
    evidence = read(root / 'verification.json')
    batches = {}
    for name, expected in evidence['batches'].items():
        raw = gzip.decompress((p.ROOT / expected['receipt']).read_bytes())
        assert hashlib.sha256(raw).hexdigest() == expected['raw_receipt_sha256'], name
        original = p.BASE / name / 'state.json'
        assert raw == original.read_bytes(), name
        receipt = json.loads(raw)
        assert receipt['observed_result'] == expected['observed_result']
        assert all(c['lifetime']['cleanup_confirmed'] for c in receipt['commands'])
        batches[name] = dict(result=receipt['observed_result'], raw_receipt_sha256=expected['raw_receipt_sha256'])
    state['historical_batches_exact'] = batches
    tracked = git('ls-files', 'benchmarks/results/releases/0.7.2').splitlines()
    mismatches = []
    for path in tracked:
        original = subprocess.check_output(['git', 'show', COMMIT + ':' + path], cwd=p.ROOT)
        if original != (p.ROOT / path).read_bytes():
            mismatches.append(path)
    assert not mismatches, mismatches
    state['sealed_evidence_files_exact'] = len(tracked)
    state['proof_reuse'] = 'Historical accepted Windows 0.7.2 runtime evidence; no changed runtime inputs.'


async def environment(directory, state):
    script = """$all = @(Get-CimInstance Win32_Process)
$owned = @($all | Where-Object { $_.Name -match '^(python|pythonw|uvicorn)\\.exe$' -and $_.CommandLine -match '(prr_[^\\s]*\\.py|orket-prr-v1|post-release-reliability)' -and $_.CommandLine -notlike '*prr_reconcile.py*' })
$server = @($all | Where-Object { $_.Name -eq 'llama-server.exe' } | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath)
$listener = @(Get-NetTCPConnection -State Listen -LocalPort 8080 | Select-Object LocalAddress,LocalPort,OwningProcess)
@{remaining_prr_processes=@($owned | Select-Object ProcessId,CreationDate,ExecutablePath); operator_servers=$server; listeners=$listener} | ConvertTo-Json -Depth 4
if ($owned.Count) { exit 1 }
"""
    row = await p.command(directory, state, ['powershell', '-NoProfile', '-Command', script], 'process-state')
    observation = json.loads(row.stdout)
    assert any(s['ProcessId'] == 45556 for s in observation['operator_servers'])
    assert any(s['OwningProcess'] == 45556 for s in observation['listeners'])
    state['process_observation'] = observation
    async with httpx.AsyncClient(trust_env=False, timeout=10) as client:
        catalog = await client.get('http://127.0.0.1:8080/v1/models')
        catalog.raise_for_status()
        props = await client.get('http://127.0.0.1:8080/props')
        props.raise_for_status()
    values = props.json()
    template = str(values.get('chat_template') or '').encode()
    canonical = subprocess.check_output(['git', 'show', COMMIT + ':orket/runtime/config/qwen38_text_chatml.jinja'])
    assert template == canonical and values['model_alias'] == p.MODEL
    assert p.MODEL in [model['id'] for model in catalog.json()['data']]
    state['provider_observation'] = dict(provider='llama_cpp', model=p.MODEL,
        endpoint='http://127.0.0.1:8080/v1', template_sha256=hashlib.sha256(template).hexdigest(),
        proof='live read-only catalog/template; not new inference proof')
    assert p.sha(p.ROOT / p.OPERATOR) == state['operator_sha256'] == '14724f69f6712ba8c49370855646e55f5f8cf0c06c3e06e07d24dd259b8252ab'
    assert git('ls-files', '-v', p.OPERATOR).startswith('S ')
    row = await p.command(directory, state, ['git', 'worktree', 'list', '--porcelain'], 'worktrees')
    previous = read(p.BASE / 'closeout/state.json')['commands'][1]['stdout']['path']
    assert row.stdout == Path(previous).read_bytes()
    state['operator_override_and_worktrees_preserved'] = True


async def main():
    directory, state = p.new_state('reconciliation')
    result = 'failure'
    try:
        publication = read(p.BASE / 'publication/state.json')
        closeout = read(p.BASE / 'closeout/state.json')
        assert publication['observed_result'] == closeout['observed_result'] == 'success'
        assert closeout['required_progress'] == '3/3'
        assert closeout['publication_receipt_sha256'] == p.sha(p.BASE / 'publication/state.json')
        state['historical_receipts'] = {name: p.sha(p.BASE / name / 'state.json') for name in ('publication', 'closeout')}
        await releases(directory, state, publication)
        historical_evidence(state)
        await environment(directory, state)
        state.update(observed_path='primary', required_progress='3/3', next_action='documentation reconciliation only')
        result = 'success'
    finally:
        p.finish(directory, state, result)
    print(json.dumps({k: state[k] for k in ('observed_result', 'main_at_observation', 'later_main_commits', 'sealed_evidence_files_exact')}))


asyncio.run(main())
